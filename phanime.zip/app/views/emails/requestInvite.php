<body>

	<h1><?php echo $tagline; ?></h1>

	<p>We've created a closed beta account for you that you can use by visiting the <a href="phanime.com/login">login</a> page.</p>

	<p>Username: <?php echo $username; ?></p>
	<p>Password: <?php echo $password; ?></p>
	<br>
	<p>Sincerely,</p>
	<p>The Phanime Team</p>

</body>