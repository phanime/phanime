(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['alisalaah:moment-tz-data'] = {};

})();

//# sourceMappingURL=alisalaah:moment-tz-data.js.map
