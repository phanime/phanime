(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var AWS;

(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/rosh93:aws-sdk/aws-sdk.js                                //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
AWS = Npm.require('aws-sdk');                                        // 1
                                                                     // 2
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rosh93:aws-sdk'] = {
  AWS: AWS
};

})();

//# sourceMappingURL=rosh93:aws-sdk.js.map
