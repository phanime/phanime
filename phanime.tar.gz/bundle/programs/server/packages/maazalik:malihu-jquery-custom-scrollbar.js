(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['maazalik:malihu-jquery-custom-scrollbar'] = {};

})();

//# sourceMappingURL=maazalik:malihu-jquery-custom-scrollbar.js.map
