(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var DDP = Package.livedata.DDP;
var DDPServer = Package.livedata.DDPServer;
var MongoInternals = Package['mongo-livedata'].MongoInternals;
var _ = Package.underscore._;

/* Package-scope variables */
var Autoupdate, ClientVersions;

(function () {

//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
// packages/autoupdate/autoupdate_server.js                                     //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////
                                                                                //
// Publish the current client versions to the client.  When a client            // 1
// sees the subscription change and that there is a new version of the          // 2
// client available on the server, it can reload.                               // 3
//                                                                              // 4
// By default there are two current client versions. The refreshable client     // 5
// version is identified by a hash of the client resources seen by the browser  // 6
// that are refreshable, such as CSS, while the non refreshable client version  // 7
// is identified by a hash of the rest of the client assets                     // 8
// (the HTML, code, and static files in the `public` directory).                // 9
//                                                                              // 10
// If the environment variable `AUTOUPDATE_VERSION` is set it will be           // 11
// used as the client id instead.  You can use this to control when             // 12
// the client reloads.  For example, if you want to only force a                // 13
// reload on major changes, you can use a custom AUTOUPDATE_VERSION             // 14
// which you only change when something worth pushing to clients                // 15
// immediately happens.                                                         // 16
//                                                                              // 17
// For backwards compatibility, SERVER_ID can be used instead of                // 18
// AUTOUPDATE_VERSION.                                                          // 19
//                                                                              // 20
// The server publishes a `meteor_autoupdate_clientVersions`                    // 21
// collection.  The contract of this collection is that each document           // 22
// in the collection represents an acceptable client version, with the          // 23
// `_id` field of the document set to the client id.                            // 24
//                                                                              // 25
// An "unacceptable" client version, for example, might be a version            // 26
// of the client code which has a severe UI bug, or is incompatible             // 27
// with the server.  An "acceptable" client version could be one that           // 28
// is older than the latest client code available on the server but             // 29
// still works.                                                                 // 30
//                                                                              // 31
// One of the published documents in the collection will have its               // 32
// `current` field set to `true`.  This is the version of the client            // 33
// code that the browser will receive from the server if it reloads.            // 34
//                                                                              // 35
// In this implementation only two documents are present in the collection      // 36
// the current refreshable client version and the current nonRefreshable client // 37
// version.  Developers can easily experiment with different versioning and     // 38
// updating models by forking this package.                                     // 39
                                                                                // 40
Autoupdate = {};                                                                // 41
                                                                                // 42
// The collection of acceptable client versions.                                // 43
ClientVersions = new Meteor.Collection("meteor_autoupdate_clientVersions",      // 44
  { connection: null });                                                        // 45
                                                                                // 46
// The client hash includes __meteor_runtime_config__, so wait until            // 47
// all packages have loaded and have had a chance to populate the               // 48
// runtime config before using the client hash as our default auto              // 49
// update version id.                                                           // 50
                                                                                // 51
Autoupdate.autoupdateVersion = null;                                            // 52
Autoupdate.autoupdateVersionRefreshable = null;                                 // 53
                                                                                // 54
var syncQueue = new Meteor._SynchronousQueue();                                 // 55
var startupVersion = null;                                                      // 56
                                                                                // 57
// updateVersions can only be called after the server has fully loaded.         // 58
var updateVersions = function (shouldReloadClientProgram) {                     // 59
  syncQueue.runTask(function () {                                               // 60
    // Step 1: load the current client program on the server and update the     // 61
    // hash values in __meteor_runtime_config__.                                // 62
    if (shouldReloadClientProgram) {                                            // 63
      WebAppInternals.reloadClientProgram();                                    // 64
    }                                                                           // 65
                                                                                // 66
    if (startupVersion === null) {                                              // 67
      Autoupdate.autoupdateVersion =                                            // 68
        __meteor_runtime_config__.autoupdateVersion =                           // 69
          process.env.AUTOUPDATE_VERSION ||                                     // 70
          process.env.SERVER_ID || // XXX COMPAT 0.6.6                          // 71
          WebApp.calculateClientHashNonRefreshable();                           // 72
    }                                                                           // 73
                                                                                // 74
    Autoupdate.autoupdateVersionRefreshable =                                   // 75
      __meteor_runtime_config__.autoupdateVersionRefreshable =                  // 76
        process.env.AUTOUPDATE_VERSION ||                                       // 77
        process.env.SERVER_ID || // XXX COMPAT 0.6.6                            // 78
        WebApp.calculateClientHashRefreshable();                                // 79
                                                                                // 80
    // Step 2: form the new client boilerplate which contains the updated       // 81
    // assets and __meteor_runtime_config__.                                    // 82
    if (shouldReloadClientProgram) {                                            // 83
      WebAppInternals.generateBoilerplate();                                    // 84
    }                                                                           // 85
                                                                                // 86
    if (! ClientVersions.findOne({_id: "version"})) {                           // 87
      ClientVersions.insert({                                                   // 88
        _id: "version",                                                         // 89
        version: Autoupdate.autoupdateVersion,                                  // 90
      });                                                                       // 91
    } else {                                                                    // 92
      ClientVersions.update("version", { $set: {                                // 93
        version: Autoupdate.autoupdateVersion,                                  // 94
      }});                                                                      // 95
    }                                                                           // 96
                                                                                // 97
    if (! ClientVersions.findOne({_id: "version-refreshable"})) {               // 98
      ClientVersions.insert({                                                   // 99
        _id: "version-refreshable",                                             // 100
        version: Autoupdate.autoupdateVersionRefreshable,                       // 101
        assets: WebAppInternals.refreshableAssets                               // 102
      });                                                                       // 103
    } else {                                                                    // 104
      ClientVersions.update("version-refreshable", { $set: {                    // 105
        version: Autoupdate.autoupdateVersionRefreshable,                       // 106
        assets: WebAppInternals.refreshableAssets                               // 107
      }});                                                                      // 108
    }                                                                           // 109
  });                                                                           // 110
};                                                                              // 111
                                                                                // 112
Meteor.startup(function () {                                                    // 113
  // Allow people to override Autoupdate.autoupdateVersion before startup.      // 114
  // Tests do this.                                                             // 115
  startupVersion = Autoupdate.autoupdateVersion;                                // 116
  updateVersions(false);                                                        // 117
});                                                                             // 118
                                                                                // 119
Meteor.publish(                                                                 // 120
  "meteor_autoupdate_clientVersions",                                           // 121
  function () {                                                                 // 122
    return ClientVersions.find();                                               // 123
  },                                                                            // 124
  {is_auto: true}                                                               // 125
);                                                                              // 126
                                                                                // 127
// Listen for SIGUSR2, which signals that a client asset has changed.           // 128
process.on('SIGUSR2', Meteor.bindEnvironment(function () {                      // 129
  updateVersions(true);                                                         // 130
}));                                                                            // 131
                                                                                // 132
//////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.autoupdate = {
  Autoupdate: Autoupdate
};

})();

//# sourceMappingURL=autoupdate.js.map
