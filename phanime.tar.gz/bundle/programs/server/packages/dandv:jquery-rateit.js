(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['dandv:jquery-rateit'] = {};

})();

//# sourceMappingURL=dandv:jquery-rateit.js.map
