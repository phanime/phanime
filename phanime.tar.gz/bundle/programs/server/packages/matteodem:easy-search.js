(function () {

/* Imports */
var _ = Package.underscore._;
var DDP = Package.ddp.DDP;
var DDPServer = Package.ddp.DDPServer;
var Meteor = Package.meteor.Meteor;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var Log = Package.logging.Log;
var Tracker = Package.deps.Tracker;
var Deps = Package.deps.Deps;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var EasySearch;

(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/matteodem:easy-search/lib/easy-search-common.js                                                    //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
EasySearch = (function () {                                                                                    // 1
  'use strict';                                                                                                // 2
                                                                                                               // 3
  var Searchers,                                                                                               // 4
    indexes = {/** @see defaultOptions */},                                                                    // 5
    defaultOptions = {                                                                                         // 6
      'format' : 'mongo',                                                                                      // 7
      'limit' : 10,                                                                                            // 8
      'use' : 'minimongo',                                                                                     // 9
      'sort' : function () {                                                                                   // 10
        return Searchers[this.use].defaultSort(this);                                                          // 11
      },                                                                                                       // 12
      'permission' : function () {                                                                             // 13
        return true;                                                                                           // 14
      },                                                                                                       // 15
      /**                                                                                                      // 16
       * When using elastic-search it's the query object,                                                      // 17
       * while using with mongo-db it's the selector object.                                                   // 18
       *                                                                                                       // 19
       * @param {String} searchString                                                                          // 20
       * @return {Object}                                                                                      // 21
       */                                                                                                      // 22
      'query' : function (searchString) {                                                                      // 23
        return Searchers[this.use].defaultQuery(this, searchString);                                           // 24
      }                                                                                                        // 25
    };                                                                                                         // 26
                                                                                                               // 27
  /**                                                                                                          // 28
   * Searchers which contain all engines which can be used to search content, until now:                       // 29
   *                                                                                                           // 30
   * minimongo (client): Client side collection for reactive search                                            // 31
   * elastic-search (server): Elastic search server to search with (fast)                                      // 32
   * mongo-db (server): MongoDB on the server to search (more convenient)                                      // 33
   *                                                                                                           // 34
   */                                                                                                          // 35
  Searchers = {};                                                                                              // 36
                                                                                                               // 37
  return {                                                                                                     // 38
    /**                                                                                                        // 39
     * Placeholder config method.                                                                              // 40
     *                                                                                                         // 41
     * @param {object} newConfig                                                                               // 42
     */                                                                                                        // 43
    'config' : function (newConfig) {                                                                          // 44
      return {};                                                                                               // 45
    },                                                                                                         // 46
    /**                                                                                                        // 47
     * Create a search index.                                                                                  // 48
     *                                                                                                         // 49
     * @param {String} name                                                                                    // 50
     * @param {Object} options                                                                                 // 51
     */                                                                                                        // 52
    'createSearchIndex' : function (name, options) {                                                           // 53
      check(name, Match.OneOf(String, null));                                                                  // 54
      check(options, Object);                                                                                  // 55
                                                                                                               // 56
      options.field = _.isArray(options.field) ? options.field : [options.field];                              // 57
      indexes[name] = _.extend(_.clone(defaultOptions), options);                                              // 58
                                                                                                               // 59
      Searchers[options.use] &&  Searchers[options.use].createSearchIndex(name, options);                      // 60
    },                                                                                                         // 61
    /**                                                                                                        // 62
     * Perform a search.                                                                                       // 63
     *                                                                                                         // 64
     * @param {String} name             the search index                                                       // 65
     * @param {String} searchString     the string to be searched                                              // 66
     * @param {Object} options          defined with createSearchIndex                                         // 67
     * @param {Function} callback       optional callback to be used                                           // 68
     */                                                                                                        // 69
    'search' : function (name, searchString, options, callback) {                                              // 70
      var searcherType = indexes[name].use;                                                                    // 71
                                                                                                               // 72
      check(name, String);                                                                                     // 73
      check(searchString, String);                                                                             // 74
      check(options, Object);                                                                                  // 75
      check(callback, Match.Optional(Function));                                                               // 76
                                                                                                               // 77
      if ("undefined" === typeof Searchers[searcherType]) {                                                    // 78
        throw new Meteor.Error(500, "Couldnt search with the type: '" + searcherType + "'");                   // 79
      }                                                                                                        // 80
                                                                                                               // 81
      // If custom permission check fails                                                                      // 82
      if (!indexes[name].permission(searchString)) {                                                           // 83
        return { 'results' : [], 'total' : 0 };                                                                // 84
      } else {                                                                                                 // 85
        return Searchers[searcherType].search(name, searchString, _.extend(indexes[name], options), callback); // 86
      }                                                                                                        // 87
    },                                                                                                         // 88
    /**                                                                                                        // 89
     * Retrieve a specific index configuration.                                                                // 90
     *                                                                                                         // 91
     * @param {String} name                                                                                    // 92
     * @return {Object}                                                                                        // 93
     * @api public                                                                                             // 94
     */                                                                                                        // 95
    'getIndex' : function (name) {                                                                             // 96
      return indexes[name];                                                                                    // 97
    },                                                                                                         // 98
    /**                                                                                                        // 99
     * Retrieve all index configurations                                                                       // 100
     */                                                                                                        // 101
    'getIndexes' : function () {                                                                               // 102
      return indexes;                                                                                          // 103
    },                                                                                                         // 104
    /**                                                                                                        // 105
     * Retrieve a specific Seacher.                                                                            // 106
     *                                                                                                         // 107
     * @param {String} name                                                                                    // 108
     * @return {Object}                                                                                        // 109
     * @api public                                                                                             // 110
     */                                                                                                        // 111
    'getSearcher' : function (name) {                                                                          // 112
      return Searchers[name];                                                                                  // 113
    },                                                                                                         // 114
    /**                                                                                                        // 115
     * Retrieve all Searchers                                                                                  // 116
     */                                                                                                        // 117
    'getSearchers' : function () {                                                                             // 118
      return Searchers;                                                                                        // 119
    },                                                                                                         // 120
    /**                                                                                                        // 121
     * Makes it possible to override or extend the different                                                   // 122
     * types of search to use with EasySearch (the "use" property)                                             // 123
     * when using EasySearch.createSearchIndex()                                                               // 124
     *                                                                                                         // 125
     * @param {String} key      Type, e.g. mongo-db, elastic-search                                            // 126
     * @param {Object} methods  Methods to be used, only 2 are required:                                       // 127
     *                          - createSearchIndex (name, options)                                            // 128
     *                          - search (name, searchString, [options, callback])                             // 129
     *                          - defaultQuery (options, searchString)                                         // 130
     *                          - defaultSort (options)                                                        // 131
     */                                                                                                        // 132
    'createSearcher' : function (key, methods) {                                                               // 133
      check(key, String);                                                                                      // 134
      check(methods.search, Function);                                                                         // 135
      check(methods.createSearchIndex, Function);                                                              // 136
      check(methods.defaultQuery, Function);                                                                   // 137
      check(methods.defaultSort, Function);                                                                    // 138
                                                                                                               // 139
      Searchers[key] = methods;                                                                                // 140
    }                                                                                                          // 141
  };                                                                                                           // 142
})();                                                                                                          // 143
                                                                                                               // 144
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/matteodem:easy-search/lib/easy-search-convenience.js                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
Meteor.Collection.prototype.initEasySearch = function (fields, options) {                                      // 1
  if (!_.isObject(options)) {                                                                                  // 2
    options = {};                                                                                              // 3
  }                                                                                                            // 4
                                                                                                               // 5
  EasySearch.createSearchIndex(this._name, _.extend(options, {                                                 // 6
    'collection' : this,                                                                                       // 7
    'field' : fields                                                                                           // 8
  }));                                                                                                         // 9
};                                                                                                             // 10
                                                                                                               // 11
if (Meteor.isClient) {                                                                                         // 12
  jQuery.fn.esAutosuggestData = function () {                                                                  // 13
    var id,                                                                                                    // 14
      input = $(this);                                                                                         // 15
                                                                                                               // 16
    if (input.prop("tagName") !== 'INPUT') {                                                                   // 17
      return [];                                                                                               // 18
    }                                                                                                          // 19
                                                                                                               // 20
    id = EasySearch.Components.generateId(input.parent().data('index'), input.parent().data('id'));            // 21
                                                                                                               // 22
    return EasySearch.Components.Variables.get(id, 'autosuggestSelected');                                     // 23
  }                                                                                                            // 24
}                                                                                                              // 25
                                                                                                               // 26
                                                                                                               // 27
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/matteodem:easy-search/lib/easy-search-server.js                                                    //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
'use strict';                                                                                                  // 1
var ElasticSearch = Npm.require('elasticsearch');                                                              // 2
                                                                                                               // 3
EasySearch._esDefaultConfig = {                                                                                // 4
  host : 'localhost:9200'                                                                                      // 5
};                                                                                                             // 6
                                                                                                               // 7
/**                                                                                                            // 8
 * Override the config for Elastic Search.                                                                     // 9
 *                                                                                                             // 10
 * @param {object} newConfig                                                                                   // 11
 */                                                                                                            // 12
EasySearch.config = function (newConfig) {                                                                     // 13
  if ("undefined" !== typeof newConfig) {                                                                      // 14
    check(newConfig, Object);                                                                                  // 15
    this._config = _.extend(this._esDefaultConfig, newConfig);                                                 // 16
    this.ElasticSearchClient = new ElasticSearch.Client(this._config);                                         // 17
  }                                                                                                            // 18
                                                                                                               // 19
  return this._config;                                                                                         // 20
};                                                                                                             // 21
                                                                                                               // 22
/**                                                                                                            // 23
 * Get the ElasticSearchClient                                                                                 // 24
 * @see http://www.elasticsearch.org/guide/en/elasticsearch/client/javascript-api/current                      // 25
 *                                                                                                             // 26
 * @return {ElasticSearch.Client}                                                                              // 27
 */                                                                                                            // 28
EasySearch.getElasticSearchClient = function () {                                                              // 29
  return this.ElasticSearchClient;                                                                             // 30
};                                                                                                             // 31
                                                                                                               // 32
Meteor.methods({                                                                                               // 33
  /**                                                                                                          // 34
   * Make server side search possible on the client.                                                           // 35
   *                                                                                                           // 36
   * @param {String} name                                                                                      // 37
   * @param {String} searchString                                                                              // 38
   * @param {Object} options                                                                                   // 39
   */                                                                                                          // 40
  easySearch: function (name, searchString, options) {                                                         // 41
    check(name, String);                                                                                       // 42
    check(searchString, String);                                                                               // 43
    check(options, Object);                                                                                    // 44
    return EasySearch.search(name, searchString, options);                                                     // 45
  }                                                                                                            // 46
});                                                                                                            // 47
                                                                                                               // 48
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/matteodem:easy-search/lib/searchers/mongo.js                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
'use strict';                                                                                                  // 1
var methods = {                                                                                                // 2
  /**                                                                                                          // 3
   * Set up a search index.                                                                                    // 4
   *                                                                                                           // 5
   * @param name                                                                                               // 6
   * @param options                                                                                            // 7
   * @returns {void}                                                                                           // 8
   */                                                                                                          // 9
  'createSearchIndex' : function (name, options) {},                                                           // 10
  /**                                                                                                          // 11
   *                                                                                                           // 12
   * Perform a really simple search with mongo db.                                                             // 13
   *                                                                                                           // 14
   * @param {String} name                                                                                      // 15
   * @param {String} searchString                                                                              // 16
   * @param {Object} options                                                                                   // 17
   * @param {Function} callback                                                                                // 18
   * @returns {Array}                                                                                          // 19
   */                                                                                                          // 20
  'search' : function (name, searchString, options, callback) {                                                // 21
    var cursor,                                                                                                // 22
      results,                                                                                                 // 23
      selector,                                                                                                // 24
      index = EasySearch.getIndex(name);                                                                       // 25
                                                                                                               // 26
    if (!_.isObject(index)) {                                                                                  // 27
      return;                                                                                                  // 28
    }                                                                                                          // 29
                                                                                                               // 30
    options.limit = options.limit || 10;                                                                       // 31
                                                                                                               // 32
    // if several, fields do an $or search, otherwise only over the field                                      // 33
    selector = index.query(searchString);                                                                      // 34
                                                                                                               // 35
    cursor = index.collection.find(selector, {                                                                 // 36
      sort : index.sort(searchString),                                                                         // 37
      limit: options.limit                                                                                     // 38
    });                                                                                                        // 39
                                                                                                               // 40
    results = {                                                                                                // 41
      'results' : cursor.fetch(),                                                                              // 42
      'total' : cursor.count()                                                                                 // 43
    };                                                                                                         // 44
                                                                                                               // 45
    if (_.isFunction(callback)) {                                                                              // 46
      callback(results);                                                                                       // 47
    }                                                                                                          // 48
                                                                                                               // 49
    return results;                                                                                            // 50
  },                                                                                                           // 51
  /**                                                                                                          // 52
   * The default mongo-db query - selector used for searching.                                                 // 53
   *                                                                                                           // 54
   * @param {Object} options                                                                                   // 55
   * @param {String} searchString                                                                              // 56
   * @returns {Object}                                                                                         // 57
   */                                                                                                          // 58
  'defaultQuery' : function (options, searchString) {                                                          // 59
    var orSelector,                                                                                            // 60
      selector = {},                                                                                           // 61
      field = options.field,                                                                                   // 62
      stringSelector = { '$regex' : '.*' + searchString + '.*', '$options' : 'i' };                            // 63
                                                                                                               // 64
    if (_.isString(field)) {                                                                                   // 65
      selector[field] = stringSelector;                                                                        // 66
      return selector;                                                                                         // 67
    }                                                                                                          // 68
                                                                                                               // 69
    // Convert numbers if configured                                                                           // 70
    if (options.convertNumbers && parseInt(searchString, 10) == searchString) {                                // 71
      searchString = parseInt(searchString, 10);                                                               // 72
    }                                                                                                          // 73
                                                                                                               // 74
    // Should be an array                                                                                      // 75
    selector['$or'] = [];                                                                                      // 76
                                                                                                               // 77
    _.each(field, function (fieldString) {                                                                     // 78
      orSelector = {};                                                                                         // 79
                                                                                                               // 80
      if (_.isString(searchString)) {                                                                          // 81
        orSelector[fieldString] = stringSelector;                                                              // 82
      } else if (_.isNumber(searchString)) {                                                                   // 83
        orSelector[fieldString] = searchString;                                                                // 84
      }                                                                                                        // 85
                                                                                                               // 86
      selector['$or'].push(orSelector);                                                                        // 87
    });                                                                                                        // 88
                                                                                                               // 89
    return selector;                                                                                           // 90
  },                                                                                                           // 91
  /**                                                                                                          // 92
   * The default mongo-db sorting method used for sorting the results.                                         // 93
   *                                                                                                           // 94
   * @param {Object} options                                                                                   // 95
   * @return array                                                                                             // 96
   */                                                                                                          // 97
  'defaultSort' : function (options) {                                                                         // 98
    return options.field;                                                                                      // 99
  }                                                                                                            // 100
};                                                                                                             // 101
                                                                                                               // 102
if (Meteor.isServer) {                                                                                         // 103
  EasySearch.createSearcher('mongo-db', methods);                                                              // 104
} else if (Meteor.isClient) {                                                                                  // 105
  EasySearch.createSearcher('minimongo', methods);                                                             // 106
}                                                                                                              // 107
                                                                                                               // 108
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/matteodem:easy-search/lib/searchers/elastic-search.js                                              //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
'use strict';                                                                                                  // 1
                                                                                                               // 2
var ElasticSearchClient,                                                                                       // 3
  Future = Npm.require('fibers/future'),                                                                       // 4
  ElasticSearch = Npm.require('elasticsearch');                                                                // 5
                                                                                                               // 6
/**                                                                                                            // 7
 * Return Elastic Search indexable data.                                                                       // 8
 *                                                                                                             // 9
 * @param {Object} doc the document to get the values from                                                     // 10
 * @return {Object}                                                                                            // 11
 */                                                                                                            // 12
function getESFields(doc) {                                                                                    // 13
  var newDoc = {};                                                                                             // 14
                                                                                                               // 15
  _.each(doc, function (value, key) {                                                                          // 16
    newDoc[key] = "string" === typeof value ? value : JSON.stringify(value);                                   // 17
  });                                                                                                          // 18
                                                                                                               // 19
  return newDoc;                                                                                               // 20
}                                                                                                              // 21
                                                                                                               // 22
EasySearch.createSearcher('elastic-search', {                                                                  // 23
  /**                                                                                                          // 24
   * Write a document to a specified index.                                                                    // 25
   *                                                                                                           // 26
   * @param {String} name                                                                                      // 27
   * @param {Object} doc                                                                                       // 28
   * @param {String} id                                                                                        // 29
   */                                                                                                          // 30
  'writeToIndex' : function (name, doc, id) {                                                                  // 31
    // add to index                                                                                            // 32
    ElasticSearchClient.index({                                                                                // 33
      index : name,                                                                                            // 34
      type : 'default',                                                                                        // 35
      id : id,                                                                                                 // 36
      body : doc                                                                                               // 37
    }, function (err, data) {                                                                                  // 38
      if (err) {                                                                                               // 39
        console.log('Had error adding a document!');                                                           // 40
        console.log(err);                                                                                      // 41
      }                                                                                                        // 42
                                                                                                               // 43
      if (config.debug && console) {                                                                           // 44
        console.log('EasySearch: Added / Replaced document to Elastic Search:');                               // 45
        console.log('EasySearch: ' + data + "\n");                                                             // 46
      }                                                                                                        // 47
    });                                                                                                        // 48
  },                                                                                                           // 49
  /**                                                                                                          // 50
   * Setup some observers on the mongo db collection provided.                                                 // 51
   *                                                                                                           // 52
   * @param {String} name                                                                                      // 53
   * @param {Object} options                                                                                   // 54
   */                                                                                                          // 55
  'createSearchIndex' : function (name, options) {                                                             // 56
    var searcherScope = this;                                                                                  // 57
                                                                                                               // 58
    if ("undefined" === typeof ElasticSearchClient) {                                                          // 59
      ElasticSearchClient = new ElasticSearch.Client(this._esDefaultConfig);                                   // 60
    }                                                                                                          // 61
                                                                                                               // 62
    options.collection.find().observeChanges({                                                                 // 63
      added: function (id, fields) {                                                                           // 64
        searcherScope.writeToIndex(name, getESFields(fields), id);                                             // 65
      },                                                                                                       // 66
      changed: function (id, fields) {                                                                         // 67
        // Overwrites the current document with the new doc                                                    // 68
        searcherScope.writeToIndex(name, getESFields(options.collection.findOne(id)), id);                     // 69
      },                                                                                                       // 70
      removed: function (id) {                                                                                 // 71
        client.delete({                                                                                        // 72
          index: name,                                                                                         // 73
          type: 'default',                                                                                     // 74
          id: id                                                                                               // 75
        }, function (error, response) {                                                                        // 76
          console.log('Removed document with id ( ' +  id + ' )!');                                            // 77
          console.log(error);                                                                                  // 78
        });                                                                                                    // 79
      }                                                                                                        // 80
    });                                                                                                        // 81
  },                                                                                                           // 82
  /**                                                                                                          // 83
   * Get the data out of the JSON elastic search response.                                                     // 84
   *                                                                                                           // 85
   * @param {Object} data                                                                                      // 86
   * @returns {Array}                                                                                          // 87
   */                                                                                                          // 88
  'extractJSONData' : function (data) {                                                                        // 89
    data = _.isString(data) ? JSON.parse(data) : data;                                                         // 90
                                                                                                               // 91
    var results = _.map(data.hits.hits, function (resultSet) {                                                 // 92
      var mongoDbDocFake = resultSet['_source'];                                                               // 93
                                                                                                               // 94
      mongoDbDocFake['_id'] = resultSet['_id'];                                                                // 95
                                                                                                               // 96
      return resultSet['_source'];                                                                             // 97
    });                                                                                                        // 98
                                                                                                               // 99
    return {                                                                                                   // 100
      'results' : results,                                                                                     // 101
      'total' : data.hits.total                                                                                // 102
    };                                                                                                         // 103
  },                                                                                                           // 104
  /**                                                                                                          // 105
   * Perform a search with Elastic Search, using fibers.                                                       // 106
   *                                                                                                           // 107
   * @param {String} name                                                                                      // 108
   * @param {String} searchString                                                                              // 109
   * @param {Object} options                                                                                   // 110
   * @param {Function} callback                                                                                // 111
   * @returns {*}                                                                                              // 112
   */                                                                                                          // 113
  'search' : function (name, searchString, options, callback) {                                                // 114
    var bodyObj,                                                                                               // 115
      that = this,                                                                                             // 116
      fut = new Future(),                                                                                      // 117
      index = indexes[name],                                                                                   // 118
      searchFields = options.field;                                                                            // 119
                                                                                                               // 120
    if (!_.isObject(index)) {                                                                                  // 121
      return;                                                                                                  // 122
    }                                                                                                          // 123
                                                                                                               // 124
    bodyObj = {                                                                                                // 125
      "query" : index.query(searchString),                                                                     // 126
      "sort" : index.sort(searchString),                                                                       // 127
      "size" : options.limit                                                                                   // 128
    };                                                                                                         // 129
                                                                                                               // 130
    if ("function" === typeof callback) {                                                                      // 131
      ElasticSearchClient.search(name, queryObj, callback);                                                    // 132
      return;                                                                                                  // 133
    }                                                                                                          // 134
                                                                                                               // 135
    // Most likely client call, return data set                                                                // 136
    ElasticSearchClient.search({                                                                               // 137
      index : name,                                                                                            // 138
      body : bodyObj                                                                                           // 139
    }, function (error, data) {                                                                                // 140
      if (error) {                                                                                             // 141
        console.log('Had an error while searching!');                                                          // 142
        console.log(error);                                                                                    // 143
        return;                                                                                                // 144
      }                                                                                                        // 145
                                                                                                               // 146
      if ("raw" !== index.format) {                                                                            // 147
        data = that.extractJSONData(data);                                                                     // 148
      }                                                                                                        // 149
                                                                                                               // 150
      fut['return'](data);                                                                                     // 151
    });                                                                                                        // 152
                                                                                                               // 153
    return fut.wait();                                                                                         // 154
  },                                                                                                           // 155
  /**                                                                                                          // 156
   * The default ES query object used for searching the results.                                               // 157
   *                                                                                                           // 158
   * @param {Object} options                                                                                   // 159
   * @param {String} searchString                                                                              // 160
   * @return array                                                                                             // 161
   */                                                                                                          // 162
  'defaultQuery' : function (options, searchString) {                                                          // 163
    return {                                                                                                   // 164
      "fuzzy_like_this" : {                                                                                    // 165
        "fields" : options.field,                                                                              // 166
        "like_text" : searchString                                                                             // 167
      }                                                                                                        // 168
    };                                                                                                         // 169
  },                                                                                                           // 170
  /**                                                                                                          // 171
   * The default ES sorting method used for sorting the results.                                               // 172
   *                                                                                                           // 173
   * @param {Object} options                                                                                   // 174
   * @return array                                                                                             // 175
   */                                                                                                          // 176
  'defaultSort' : function (options) {                                                                         // 177
    return options.field;                                                                                      // 178
  }                                                                                                            // 179
});                                                                                                            // 180
                                                                                                               // 181
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['matteodem:easy-search'] = {
  EasySearch: EasySearch
};

})();

//# sourceMappingURL=matteodem:easy-search.js.map
