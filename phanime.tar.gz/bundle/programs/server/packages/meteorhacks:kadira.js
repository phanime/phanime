(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var KadiraBinaryDeps = Package['meteorhacks:kadira-binary-deps'].KadiraBinaryDeps;
var LocalCollection = Package.minimongo.LocalCollection;
var Minimongo = Package.minimongo.Minimongo;
var DDP = Package.ddp.DDP;
var DDPServer = Package.ddp.DDPServer;
var EJSON = Package.ejson.EJSON;
var _ = Package.underscore._;
var HTTP = Package.http.HTTP;
var Email = Package.email.Email;
var Random = Package.random.Random;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;

/* Package-scope variables */
var Kadira, Retry, HaveAsyncCallback, UniqueId, DefaultUniqueId, Ntp, KadiraModel, MethodsModel, PubsubModel, collectionName, SystemModel, ErrorModel, OplogCheck, TracerStore, wrapSession, wrapSubscription;

(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/meteorhacks:kadira/lib/retry.js                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
// Retry logic with an exponential backoff.                                                                           // 1
//                                                                                                                    // 2
// options:                                                                                                           // 3
//  baseTimeout: time for initial reconnect attempt (ms).                                                             // 4
//  exponent: exponential factor to increase timeout each attempt.                                                    // 5
//  maxTimeout: maximum time between retries (ms).                                                                    // 6
//  minCount: how many times to reconnect "instantly".                                                                // 7
//  minTimeout: time to wait for the first `minCount` retries (ms).                                                   // 8
//  fuzz: factor to randomize retry times by (to avoid retry storms).                                                 // 9
                                                                                                                      // 10
//TODO: remove this class and use Meteor Retry in a later version of meteor.                                          // 11
                                                                                                                      // 12
Retry = function (options) {                                                                                          // 13
  var self = this;                                                                                                    // 14
  _.extend(self, _.defaults(_.clone(options || {}), {                                                                 // 15
    baseTimeout: 1000, // 1 second                                                                                    // 16
    exponent: 2.2,                                                                                                    // 17
    // The default is high-ish to ensure a server can recover from a                                                  // 18
    // failure caused by load.                                                                                        // 19
    maxTimeout: 5 * 60000, // 5 minutes                                                                               // 20
    minTimeout: 10,                                                                                                   // 21
    minCount: 2,                                                                                                      // 22
    fuzz: 0.5 // +- 25%                                                                                               // 23
  }));                                                                                                                // 24
  self.retryTimer = null;                                                                                             // 25
};                                                                                                                    // 26
                                                                                                                      // 27
_.extend(Retry.prototype, {                                                                                           // 28
                                                                                                                      // 29
  // Reset a pending retry, if any.                                                                                   // 30
  clear: function () {                                                                                                // 31
    var self = this;                                                                                                  // 32
    if(self.retryTimer)                                                                                               // 33
      clearTimeout(self.retryTimer);                                                                                  // 34
    self.retryTimer = null;                                                                                           // 35
  },                                                                                                                  // 36
                                                                                                                      // 37
  // Calculate how long to wait in milliseconds to retry, based on the                                                // 38
  // `count` of which retry this is.                                                                                  // 39
  _timeout: function (count) {                                                                                        // 40
    var self = this;                                                                                                  // 41
                                                                                                                      // 42
    if(count < self.minCount)                                                                                         // 43
      return self.minTimeout;                                                                                         // 44
                                                                                                                      // 45
    var timeout = Math.min(                                                                                           // 46
      self.maxTimeout,                                                                                                // 47
      self.baseTimeout * Math.pow(self.exponent, count));                                                             // 48
    // fuzz the timeout randomly, to avoid reconnect storms when a                                                    // 49
    // server goes down.                                                                                              // 50
    timeout = timeout * ((Random.fraction() * self.fuzz) +                                                            // 51
                         (1 - self.fuzz/2));                                                                          // 52
    return Math.ceil(timeout);                                                                                        // 53
  },                                                                                                                  // 54
                                                                                                                      // 55
  // Call `fn` after a delay, based on the `count` of which retry this is.                                            // 56
  retryLater: function (count, fn) {                                                                                  // 57
    var self = this;                                                                                                  // 58
    var timeout = self._timeout(count);                                                                               // 59
    if(self.retryTimer)                                                                                               // 60
      clearTimeout(self.retryTimer);                                                                                  // 61
                                                                                                                      // 62
    self.retryTimer = setTimeout(fn, timeout);                                                                        // 63
    return timeout;                                                                                                   // 64
  }                                                                                                                   // 65
                                                                                                                      // 66
});                                                                                                                   // 67
                                                                                                                      // 68
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/meteorhacks:kadira/lib/utils.js                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Fiber = Npm.require('fibers');                                                                                    // 1
                                                                                                                      // 2
HaveAsyncCallback = function(args) {                                                                                  // 3
  var lastArg = args[args.length -1];                                                                                 // 4
  return (typeof lastArg) == 'function';                                                                              // 5
};                                                                                                                    // 6
                                                                                                                      // 7
UniqueId = function(start) {                                                                                          // 8
  this.id = 0;                                                                                                        // 9
}                                                                                                                     // 10
                                                                                                                      // 11
UniqueId.prototype.get = function() {                                                                                 // 12
  return "" + this.id++;                                                                                              // 13
};                                                                                                                    // 14
                                                                                                                      // 15
DefaultUniqueId = new UniqueId();                                                                                     // 16
                                                                                                                      // 17
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/meteorhacks:kadira/lib/ntp.js                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var logger = getLogger();                                                                                             // 1
                                                                                                                      // 2
Ntp = function (endpoint) {                                                                                           // 3
  this.endpoint = endpoint + '/simplentp/sync';                                                                       // 4
  this.diff = 0;                                                                                                      // 5
  this.synced = false;                                                                                                // 6
  this.reSyncCount = 0;                                                                                               // 7
  this.reSync = new Retry({                                                                                           // 8
    baseTimeout: 1000*60,                                                                                             // 9
    maxTimeout: 1000*60*10,                                                                                           // 10
    minCount: 0                                                                                                       // 11
  });                                                                                                                 // 12
}                                                                                                                     // 13
                                                                                                                      // 14
Ntp._now = function() {                                                                                               // 15
  var now = Date.now();                                                                                               // 16
  if(typeof now == 'number') {                                                                                        // 17
    return now;                                                                                                       // 18
  } else if(now instanceof Date) {                                                                                    // 19
    // some extenal JS libraries override Date.now and returns a Date object                                          // 20
    // which directly affect us. So we need to prepare for that                                                       // 21
    return now.getTime();                                                                                             // 22
  } else {                                                                                                            // 23
    // trust me. I've seen now === undefined                                                                          // 24
    return (new Date()).getTime();                                                                                    // 25
  }                                                                                                                   // 26
};                                                                                                                    // 27
                                                                                                                      // 28
Ntp.prototype.getTime = function() {                                                                                  // 29
  return Ntp._now() + Math.round(this.diff);                                                                          // 30
};                                                                                                                    // 31
                                                                                                                      // 32
Ntp.prototype.syncTime = function(localTime) {                                                                        // 33
  return localTime + Math.ceil(this.diff);                                                                            // 34
};                                                                                                                    // 35
                                                                                                                      // 36
Ntp.prototype.sync = function() {                                                                                     // 37
  logger('init sync');                                                                                                // 38
  var self = this;                                                                                                    // 39
  var retryCount = 0;                                                                                                 // 40
  var retry = new Retry({                                                                                             // 41
    baseTimeout: 1000*20,                                                                                             // 42
    maxTimeout: 1000*60,                                                                                              // 43
    minCount: 1,                                                                                                      // 44
    minTimeout: 0                                                                                                     // 45
  });                                                                                                                 // 46
  syncTime();                                                                                                         // 47
                                                                                                                      // 48
  function syncTime () {                                                                                              // 49
    if(retryCount<5) {                                                                                                // 50
      logger('attempt time sync with server', retryCount);                                                            // 51
      // if we send 0 to the retryLater, cacheDns will run immediately                                                // 52
      retry.retryLater(retryCount++, cacheDns);                                                                       // 53
    } else {                                                                                                          // 54
      logger('maximum retries reached');                                                                              // 55
      self.reSync.retryLater(self.reSyncCount++, function () {                                                        // 56
        var args = [].slice.call(arguments);                                                                          // 57
        self.sync.apply(self, args);                                                                                  // 58
      });                                                                                                             // 59
    }                                                                                                                 // 60
  }                                                                                                                   // 61
                                                                                                                      // 62
  // first attempt is to cache dns. So, calculation does not                                                          // 63
  // include DNS resolution time                                                                                      // 64
  function cacheDns () {                                                                                              // 65
    self.getServerTime(function(err) {                                                                                // 66
      if(!err) {                                                                                                      // 67
        calculateTimeDiff();                                                                                          // 68
      } else {                                                                                                        // 69
        syncTime();                                                                                                   // 70
      }                                                                                                               // 71
    });                                                                                                               // 72
  }                                                                                                                   // 73
                                                                                                                      // 74
  function calculateTimeDiff () {                                                                                     // 75
    var startTime = (new Date()).getTime();                                                                           // 76
    self.getServerTime(function(err, serverTime) {                                                                    // 77
      if(!err && serverTime) {                                                                                        // 78
        // (Date.now() + startTime)/2 : Midpoint between req and res                                                  // 79
        self.diff = serverTime - ((new Date()).getTime() + startTime)/2;                                              // 80
        self.synced = true;                                                                                           // 81
        // we need to send 1 into retryLater.                                                                         // 82
        self.reSync.retryLater(self.reSyncCount++, function () {                                                      // 83
          var args = [].slice.call(arguments);                                                                        // 84
          self.sync.apply(self, args);                                                                                // 85
        });                                                                                                           // 86
        logger('successfully updated diff value', self.diff);                                                         // 87
      } else {                                                                                                        // 88
        syncTime();                                                                                                   // 89
      }                                                                                                               // 90
    });                                                                                                               // 91
  }                                                                                                                   // 92
}                                                                                                                     // 93
                                                                                                                      // 94
Ntp.prototype.getServerTime = function(callback) {                                                                    // 95
  var self = this;                                                                                                    // 96
                                                                                                                      // 97
  if(Meteor.isServer) {                                                                                               // 98
    var Fiber = Npm.require('fibers');                                                                                // 99
    new Fiber(function() {                                                                                            // 100
      HTTP.get(self.endpoint, function (err, res) {                                                                   // 101
        if(err) {                                                                                                     // 102
          callback(err);                                                                                              // 103
        } else {                                                                                                      // 104
          var serverTime = parseInt(res.content)                                                                      // 105
          callback(null, serverTime);                                                                                 // 106
        }                                                                                                             // 107
      });                                                                                                             // 108
    }).run();                                                                                                         // 109
  } else {                                                                                                            // 110
    $.ajax({                                                                                                          // 111
      url: self.endpoint + '/jsonp',                                                                                  // 112
      jsonp: 'callback',                                                                                              // 113
      dataType: 'jsonp',                                                                                              // 114
      success: function(serverTime) {                                                                                 // 115
        callback(null, serverTime);                                                                                   // 116
      },                                                                                                              // 117
      error: function(err) {                                                                                          // 118
        callback(err);                                                                                                // 119
      }                                                                                                               // 120
    });                                                                                                               // 121
  }                                                                                                                   // 122
};                                                                                                                    // 123
                                                                                                                      // 124
function getLogger() {                                                                                                // 125
  if(Meteor.isServer) {                                                                                               // 126
    return Npm.require('debug')("kadira:ntp");                                                                        // 127
  } else {                                                                                                            // 128
    return function(message) {                                                                                        // 129
      var canLogKadira =                                                                                              // 130
        Meteor._localStorage.getItem('LOG_KADIRA') !== null                                                           // 131
        && typeof console !== 'undefined';                                                                            // 132
                                                                                                                      // 133
      if(canLogKadira) {                                                                                              // 134
        if(message) {                                                                                                 // 135
          message = "kadira:ntp " + message;                                                                          // 136
          arguments[0] = message;                                                                                     // 137
        }                                                                                                             // 138
        console.log.apply(console, arguments);                                                                        // 139
      }                                                                                                               // 140
    }                                                                                                                 // 141
  }                                                                                                                   // 142
}                                                                                                                     // 143
                                                                                                                      // 144
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/meteorhacks:kadira/lib/models/0model.js                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
KadiraModel = function() {                                                                                            // 1
                                                                                                                      // 2
};                                                                                                                    // 3
                                                                                                                      // 4
KadiraModel.prototype._getDateId = function(timestamp) {                                                              // 5
  var remainder = timestamp % (1000 * 60);                                                                            // 6
  var dateId = timestamp - remainder;                                                                                 // 7
  return dateId;                                                                                                      // 8
};                                                                                                                    // 9
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/meteorhacks:kadira/lib/models/methods.js                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var METHOD_METRICS_FIELDS = ['wait', 'db', 'http', 'email', 'async', 'compute', 'total'];                             // 1
                                                                                                                      // 2
MethodsModel = function (metricsThreshold) {                                                                          // 3
  var self = this;                                                                                                    // 4
                                                                                                                      // 5
  this.methodMetricsByMinute = {};                                                                                    // 6
  this.errorMap = {};                                                                                                 // 7
                                                                                                                      // 8
  this._metricsThreshold = _.extend({                                                                                 // 9
    "wait": 100,                                                                                                      // 10
    "db": 100,                                                                                                        // 11
    "http": 1000,                                                                                                     // 12
    "email": 100,                                                                                                     // 13
    "async": 100,                                                                                                     // 14
    "compute": 100,                                                                                                   // 15
    "total": 200                                                                                                      // 16
  }, metricsThreshold || {});                                                                                         // 17
                                                                                                                      // 18
  //store max time elapsed methods for each method, event(metrics-field)                                              // 19
  this.maxEventTimesForMethods = {};                                                                                  // 20
                                                                                                                      // 21
  this.tracerStore = new TracerStore({                                                                                // 22
    interval: 1000 * 60, //process traces every minute                                                                // 23
    maxTotalPoints: 30, //for 30 minutes                                                                              // 24
    archiveEvery: 5 //always trace for every 5 minutes,                                                               // 25
  });                                                                                                                 // 26
                                                                                                                      // 27
  this.tracerStore.start();                                                                                           // 28
};                                                                                                                    // 29
                                                                                                                      // 30
_.extend(MethodsModel.prototype, KadiraModel.prototype);                                                              // 31
                                                                                                                      // 32
MethodsModel.prototype.processMethod = function(methodTrace) {                                                        // 33
  var dateId = this._getDateId(methodTrace.at);                                                                       // 34
                                                                                                                      // 35
  //append metrics to previous values                                                                                 // 36
  this._appendMetrics(dateId, methodTrace);                                                                           // 37
  if(methodTrace.errored) {                                                                                           // 38
    this.methodMetricsByMinute[dateId].methods[methodTrace.name].errors ++                                            // 39
  }                                                                                                                   // 40
                                                                                                                      // 41
  this.tracerStore.addTrace(methodTrace);                                                                             // 42
};                                                                                                                    // 43
                                                                                                                      // 44
MethodsModel.prototype._appendMetrics = function(id, methodTrace) {                                                   // 45
  //initialize meteric for this time interval                                                                         // 46
  if(!this.methodMetricsByMinute[id]) {                                                                               // 47
    this.methodMetricsByMinute[id] = {                                                                                // 48
      // startTime needs to be converted into serverTime before sending                                               // 49
      startTime: methodTrace.at,                                                                                      // 50
      methods: {}                                                                                                     // 51
    };                                                                                                                // 52
  }                                                                                                                   // 53
                                                                                                                      // 54
  var methods = this.methodMetricsByMinute[id].methods;                                                               // 55
                                                                                                                      // 56
  //initialize method                                                                                                 // 57
  if(!methods[methodTrace.name]) {                                                                                    // 58
    methods[methodTrace.name] = {                                                                                     // 59
      count: 0,                                                                                                       // 60
      errors: 0                                                                                                       // 61
    };                                                                                                                // 62
                                                                                                                      // 63
    METHOD_METRICS_FIELDS.forEach(function(field) {                                                                   // 64
      methods[methodTrace.name][field] = 0;                                                                           // 65
    });                                                                                                               // 66
  }                                                                                                                   // 67
                                                                                                                      // 68
  //merge                                                                                                             // 69
  METHOD_METRICS_FIELDS.forEach(function(field) {                                                                     // 70
    var value = methodTrace.metrics[field];                                                                           // 71
    if(value > 0) {                                                                                                   // 72
      methods[methodTrace.name][field] += value;                                                                      // 73
    }                                                                                                                 // 74
  });                                                                                                                 // 75
                                                                                                                      // 76
  methods[methodTrace.name].count++;                                                                                  // 77
  this.methodMetricsByMinute[id].endTime = methodTrace.metrics.at;                                                    // 78
};                                                                                                                    // 79
                                                                                                                      // 80
/*                                                                                                                    // 81
  There are two types of data                                                                                         // 82
                                                                                                                      // 83
  1. methodMetrics - metrics about the methods (for every 10 secs)                                                    // 84
  2. methodRequests - raw method request. normally max, min for every 1 min and errors always                         // 85
*/                                                                                                                    // 86
MethodsModel.prototype.buildPayload = function(buildDetailedInfo) {                                                   // 87
  var payload = {                                                                                                     // 88
    methodMetrics: [],                                                                                                // 89
    methodRequests: []                                                                                                // 90
  };                                                                                                                  // 91
                                                                                                                      // 92
  //handling metrics                                                                                                  // 93
  var methodMetricsByMinute = this.methodMetricsByMinute;                                                             // 94
  this.methodMetricsByMinute = {};                                                                                    // 95
                                                                                                                      // 96
  //create final paylod for methodMetrics                                                                             // 97
  for(var key in methodMetricsByMinute) {                                                                             // 98
    var methodMetrics = methodMetricsByMinute[key];                                                                   // 99
    // converting startTime into the actual serverTime                                                                // 100
    var startTime = methodMetrics.startTime;                                                                          // 101
    methodMetrics.startTime = Kadira.syncedDate.syncTime(startTime);                                                  // 102
                                                                                                                      // 103
    for(var methodName in methodMetrics.methods) {                                                                    // 104
      METHOD_METRICS_FIELDS.forEach(function(field) {                                                                 // 105
        methodMetrics.methods[methodName][field] /=                                                                   // 106
          methodMetrics.methods[methodName].count;                                                                    // 107
      });                                                                                                             // 108
    }                                                                                                                 // 109
                                                                                                                      // 110
    payload.methodMetrics.push(methodMetricsByMinute[key]);                                                           // 111
  }                                                                                                                   // 112
                                                                                                                      // 113
  //collect traces and send them with the payload                                                                     // 114
  payload.methodRequests = this.tracerStore.collectTraces();                                                          // 115
                                                                                                                      // 116
  return payload;                                                                                                     // 117
};                                                                                                                    // 118
                                                                                                                      // 119
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/meteorhacks:kadira/lib/models/pubsub.js                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var logger = Npm.require('debug')('kadira:pubsub');                                                                   // 1
                                                                                                                      // 2
PubsubModel = function() {                                                                                            // 3
  this.metricsByMinute = {};                                                                                          // 4
  this.subscriptions = {};                                                                                            // 5
                                                                                                                      // 6
  this.tracerStore = new TracerStore({                                                                                // 7
    interval: 1000 * 60, //process traces every minute                                                                // 8
    maxTotalPoints: 30, //for 30 minutes                                                                              // 9
    archiveEvery: 5 //always trace for every 5 minutes,                                                               // 10
  });                                                                                                                 // 11
                                                                                                                      // 12
  this.tracerStore.start();                                                                                           // 13
}                                                                                                                     // 14
                                                                                                                      // 15
PubsubModel.prototype._trackSub = function(session, msg) {                                                            // 16
  logger('SUB:', session.id, msg.id, msg.name, msg.params, msg.route);                                                // 17
  var publication = this._getPublicationName(msg.name);                                                               // 18
  var subscriptionId = msg.id;                                                                                        // 19
  var timestamp = Ntp._now();                                                                                         // 20
  var metrics = this._getMetrics(timestamp, publication);                                                             // 21
                                                                                                                      // 22
  metrics.subs++;                                                                                                     // 23
                                                                                                                      // 24
  var route = msg.route;                                                                                              // 25
  if(route !== undefined){                                                                                            // 26
    metrics.subRoutes = metrics.subRoutes || {};                                                                      // 27
    metrics.subRoutes[route] = metrics.subRoutes[route] || 0;                                                         // 28
    metrics.subRoutes[route]++;                                                                                       // 29
  }                                                                                                                   // 30
                                                                                                                      // 31
  this.subscriptions[msg.id] = {                                                                                      // 32
    // We use localTime here, because when we used synedTime we might get                                             // 33
    // minus or more than we've expected                                                                              // 34
    //   (before serverTime diff changed overtime)                                                                    // 35
    startTime: timestamp,                                                                                             // 36
    publication: publication,                                                                                         // 37
    params: msg.params,                                                                                               // 38
    route: msg.route,                                                                                                 // 39
    id: msg.id                                                                                                        // 40
  };                                                                                                                  // 41
                                                                                                                      // 42
  //set session startedTime                                                                                           // 43
  session._startTime = session._startTime || timestamp;                                                               // 44
};                                                                                                                    // 45
                                                                                                                      // 46
_.extend(PubsubModel.prototype, KadiraModel.prototype);                                                               // 47
                                                                                                                      // 48
PubsubModel.prototype._trackUnsub = function(session, sub) {                                                          // 49
  logger('UNSUB:', session.id, sub._subscriptionId);                                                                  // 50
  var publication = this._getPublicationName(sub._name);                                                              // 51
  var subscriptionId = sub._subscriptionId;                                                                           // 52
  var subscriptionState = this.subscriptions[subscriptionId];                                                         // 53
                                                                                                                      // 54
  var startTime = null;                                                                                               // 55
  var route = null;                                                                                                   // 56
  //sometime, we don't have these states                                                                              // 57
  if(subscriptionState) {                                                                                             // 58
    startTime = subscriptionState.startTime;                                                                          // 59
    route = subscriptionState.route;                                                                                  // 60
  } else {                                                                                                            // 61
    //if this is null subscription, which is started automatically                                                    // 62
    //hence, we don't have a state                                                                                    // 63
    startTime = session._startTime;                                                                                   // 64
  }                                                                                                                   // 65
                                                                                                                      // 66
  //in case, we can't get the startTime                                                                               // 67
  if(startTime) {                                                                                                     // 68
    var timestamp = Ntp._now();                                                                                       // 69
    var metrics = this._getMetrics(timestamp, publication);                                                           // 70
    //track the count                                                                                                 // 71
    metrics.unsubs++;                                                                                                 // 72
    //use the current date to get the lifeTime of the subscription                                                    // 73
    metrics.lifeTime += timestamp - startTime;                                                                        // 74
                                                                                                                      // 75
    if(route){                                                                                                        // 76
      metrics.unsubRoutes = metrics.unsubRoutes || {};                                                                // 77
      metrics.unsubRoutes[route] = metrics.unsubRoutes[route] || 0;                                                   // 78
      metrics.unsubRoutes[route]++;                                                                                   // 79
    }                                                                                                                 // 80
                                                                                                                      // 81
    //this is place we can clean the subscriptionState if exists                                                      // 82
    delete this.subscriptions[subscriptionId];                                                                        // 83
  }                                                                                                                   // 84
};                                                                                                                    // 85
                                                                                                                      // 86
PubsubModel.prototype._trackReady = function(session, sub, trace) {                                                   // 87
  logger('READY:', session.id, sub._subscriptionId);                                                                  // 88
  //use the current time to track the response time                                                                   // 89
  var publication = this._getPublicationName(sub._name);                                                              // 90
  var subscriptionId = sub._subscriptionId;                                                                           // 91
  var timestamp = Ntp._now();                                                                                         // 92
  var metrics = this._getMetrics(timestamp, publication);                                                             // 93
                                                                                                                      // 94
  var subscriptionState = this.subscriptions[subscriptionId];                                                         // 95
  if(subscriptionState && !subscriptionState.readyTracked) {                                                          // 96
    metrics.resTime += timestamp - subscriptionState.startTime;                                                       // 97
    subscriptionState.readyTracked = true;                                                                            // 98
  }                                                                                                                   // 99
                                                                                                                      // 100
  if(trace) {                                                                                                         // 101
    this.tracerStore.addTrace(trace);                                                                                 // 102
  }                                                                                                                   // 103
};                                                                                                                    // 104
                                                                                                                      // 105
PubsubModel.prototype._trackError = function(session, sub, trace) {                                                   // 106
  logger('ERROR:', session.id, sub._subscriptionId);                                                                  // 107
  //use the current time to track the response time                                                                   // 108
  var publication = this._getPublicationName(sub._name);                                                              // 109
  var subscriptionId = sub._subscriptionId;                                                                           // 110
  var timestamp = Ntp._now();                                                                                         // 111
  var metrics = this._getMetrics(timestamp, publication);                                                             // 112
                                                                                                                      // 113
  metrics.errors++;                                                                                                   // 114
                                                                                                                      // 115
  if(trace) {                                                                                                         // 116
    this.tracerStore.addTrace(trace);                                                                                 // 117
  }                                                                                                                   // 118
};                                                                                                                    // 119
                                                                                                                      // 120
PubsubModel.prototype._trackNetworkImpact = function(session, sub, event, collection, id, fields) {                   // 121
  logger('DI:' + event, session.id, sub._subscriptionId, collection, id);                                             // 122
  if(event != 'removed' && _.keys(fields).length > 0) {                                                               // 123
    var subscriptionId = sub._subscriptionId;                                                                         // 124
    var subscriptionState = this.subscriptions[subscriptionId];                                                       // 125
                                                                                                                      // 126
    var publication = this._getPublicationName(sub._name);                                                            // 127
    var timestamp = Ntp._now();                                                                                       // 128
    var metrics = this._getMetrics(timestamp, publication);                                                           // 129
                                                                                                                      // 130
    if(subscriptionState) {                                                                                           // 131
      var sendingDataSize = Buffer.byteLength(JSON.stringify(fields));                                                // 132
      sub._totalDocsSent = sub._totalDocsSent || 0;                                                                   // 133
      sub._totalDocsSent++;                                                                                           // 134
      sub._totalDataSent = sub._totalDataSent || 0;                                                                   // 135
      sub._totalDataSent += sendingDataSize;                                                                          // 136
      if(subscriptionState.readyTracked) {                                                                            // 137
        //using JSON instead of EJSON to save the CPU usage                                                           // 138
        if(event == 'added') {                                                                                        // 139
          metrics.bytesAddedAfterReady += sendingDataSize;                                                            // 140
        } else if(event == 'changed') {                                                                               // 141
          metrics.bytesChangedAfterReady += sendingDataSize;                                                          // 142
        };                                                                                                            // 143
      } else {                                                                                                        // 144
        metrics.bytesBeforeReady += Buffer.byteLength(JSON.stringify(fields));                                        // 145
      }                                                                                                               // 146
    }                                                                                                                 // 147
  }                                                                                                                   // 148
};                                                                                                                    // 149
                                                                                                                      // 150
PubsubModel.prototype._getMetrics = function(timestamp, publication) {                                                // 151
  var dateId = this._getDateId(timestamp);                                                                            // 152
                                                                                                                      // 153
  this.metricsByMinute[dateId] = this.metricsByMinute[dateId] || {                                                    // 154
    // startTime needs to be convert to serverTime before sending to the server                                       // 155
    startTime: timestamp,                                                                                             // 156
    pubs: {}                                                                                                          // 157
  };                                                                                                                  // 158
                                                                                                                      // 159
  this.metricsByMinute[dateId].pubs[publication] = this.metricsByMinute[dateId].pubs[publication] || {                // 160
    subs: 0,                                                                                                          // 161
    unsubs: 0,                                                                                                        // 162
    resTime: 0,                                                                                                       // 163
    bytesBeforeReady: 0,                                                                                              // 164
    bytesAddedAfterReady: 0,                                                                                          // 165
    bytesChangedAfterReady: 0,                                                                                        // 166
    activeSubs: 0,                                                                                                    // 167
    activeDocs: 0,                                                                                                    // 168
    lifeTime: 0,                                                                                                      // 169
    totalObservers: 0,                                                                                                // 170
    cachedObservers: 0,                                                                                               // 171
    avgDocSize: 0,                                                                                                    // 172
    errors: 0                                                                                                         // 173
  };                                                                                                                  // 174
                                                                                                                      // 175
  return this.metricsByMinute[dateId].pubs[publication];                                                              // 176
};                                                                                                                    // 177
                                                                                                                      // 178
PubsubModel.prototype._getPublicationName = function(name) {                                                          // 179
  return name || "null(autopublish)";                                                                                 // 180
};                                                                                                                    // 181
                                                                                                                      // 182
PubsubModel.prototype._getSubscriptionInfo = function() {                                                             // 183
  var self = this;                                                                                                    // 184
  var activeSubs = {};                                                                                                // 185
  var activeDocs = {};                                                                                                // 186
  var totalDocsSent = {};                                                                                             // 187
  var totalDataSent = {};                                                                                             // 188
  var totalObservers = {};                                                                                            // 189
  var cachedObservers = {};                                                                                           // 190
                                                                                                                      // 191
  for(var sessionId in Meteor.default_server.sessions) {                                                              // 192
    var session = Meteor.default_server.sessions[sessionId];                                                          // 193
    _.each(session._namedSubs, countSubData);                                                                         // 194
    _.each(session._universalSubs, countSubData);                                                                     // 195
  }                                                                                                                   // 196
                                                                                                                      // 197
  var avgDocSize = {};                                                                                                // 198
  _.each(totalDataSent, function(value, publication) {                                                                // 199
    avgDocSize[publication] = totalDataSent[publication] / totalDocsSent[publication];                                // 200
  });                                                                                                                 // 201
                                                                                                                      // 202
  var avgObserverReuse = {};                                                                                          // 203
  _.each(totalObservers, function(value, publication) {                                                               // 204
    avgObserverReuse[publication] = cachedObservers[publication] / totalObservers[publication];                       // 205
  });                                                                                                                 // 206
                                                                                                                      // 207
  return {                                                                                                            // 208
    activeSubs: activeSubs,                                                                                           // 209
    activeDocs: activeDocs,                                                                                           // 210
    avgDocSize: avgDocSize,                                                                                           // 211
    avgObserverReuse: avgObserverReuse                                                                                // 212
  };                                                                                                                  // 213
                                                                                                                      // 214
  function countSubData (sub) {                                                                                       // 215
    var publication = self._getPublicationName(sub._name);                                                            // 216
    countSubscriptions(sub, publication);                                                                             // 217
    countDocuments(sub, publication);                                                                                 // 218
    countTotalDocsSent(sub, publication);                                                                             // 219
    countTotalDataSent(sub, publication);                                                                             // 220
    countObservers(sub, publication);                                                                                 // 221
  }                                                                                                                   // 222
                                                                                                                      // 223
  function countSubscriptions (sub, publication) {                                                                    // 224
    activeSubs[publication] = activeSubs[publication] || 0;                                                           // 225
    activeSubs[publication]++;                                                                                        // 226
  }                                                                                                                   // 227
                                                                                                                      // 228
  function countDocuments (sub, publication) {                                                                        // 229
    activeDocs[publication] = activeDocs[publication] || 0;                                                           // 230
    for(collectionName in sub._documents) {                                                                           // 231
      activeDocs[publication] += _.keys(sub._documents[collectionName]).length;                                       // 232
    }                                                                                                                 // 233
  }                                                                                                                   // 234
                                                                                                                      // 235
  function countTotalDocsSent (sub, publication) {                                                                    // 236
    totalDocsSent[publication] = totalDocsSent[publication] || 0;                                                     // 237
    totalDocsSent[publication] += sub._totalDocsSent;                                                                 // 238
  }                                                                                                                   // 239
                                                                                                                      // 240
  function countTotalDataSent (sub, publication) {                                                                    // 241
    totalDataSent[publication] = totalDataSent[publication] || 0;                                                     // 242
    totalDataSent[publication] += sub._totalDataSent;                                                                 // 243
  }                                                                                                                   // 244
                                                                                                                      // 245
  function countObservers(sub, publication) {                                                                         // 246
    totalObservers[publication] = totalObservers[publication] || 0;                                                   // 247
    cachedObservers[publication] = cachedObservers[publication] || 0;                                                 // 248
                                                                                                                      // 249
    totalObservers[publication] += sub._totalObservers;                                                               // 250
    cachedObservers[publication] += sub._cachedObservers;                                                             // 251
  }                                                                                                                   // 252
}                                                                                                                     // 253
                                                                                                                      // 254
PubsubModel.prototype.buildPayload = function(buildDetailInfo) {                                                      // 255
  var metricsByMinute = this.metricsByMinute;                                                                         // 256
  this.metricsByMinute = {};                                                                                          // 257
                                                                                                                      // 258
  var payload = {                                                                                                     // 259
    pubMetrics: []                                                                                                    // 260
  };                                                                                                                  // 261
                                                                                                                      // 262
  var subscriptionData = this._getSubscriptionInfo();                                                                 // 263
  var activeSubs = subscriptionData.activeSubs;                                                                       // 264
  var activeDocs = subscriptionData.activeDocs;                                                                       // 265
  var avgDocSize = subscriptionData.avgDocSize;                                                                       // 266
  var avgObserverReuse = subscriptionData.avgObserverReuse;                                                           // 267
                                                                                                                      // 268
  //to the averaging                                                                                                  // 269
  for(var dateId in metricsByMinute) {                                                                                // 270
    var dateMetrics = metricsByMinute[dateId];                                                                        // 271
    // We need to convert startTime into actual serverTime                                                            // 272
    dateMetrics.startTime = Kadira.syncedDate.syncTime(dateMetrics.startTime);                                        // 273
                                                                                                                      // 274
    for(var publication in metricsByMinute[dateId].pubs) {                                                            // 275
      var singlePubMetrics = metricsByMinute[dateId].pubs[publication];                                               // 276
      // We only calculate resTime for new subscriptions                                                              // 277
      singlePubMetrics.resTime /= singlePubMetrics.subs;                                                              // 278
      singlePubMetrics.resTime = singlePubMetrics.resTime || 0;                                                       // 279
      // We only track lifeTime in the unsubs                                                                         // 280
      singlePubMetrics.lifeTime /= singlePubMetrics.unsubs;                                                           // 281
      singlePubMetrics.lifeTime = singlePubMetrics.lifeTime || 0;                                                     // 282
                                                                                                                      // 283
      // This is a very efficient solution. We can come up with another solution                                      // 284
      // which maintains the count inside the API.                                                                    // 285
      // But for now, this is the most reliable method.                                                               // 286
                                                                                                                      // 287
      // If there are two ore more dateIds, we will be using the currentCount for all of them.                        // 288
      // We can come up with a better solution later on.                                                              // 289
      singlePubMetrics.activeSubs = activeSubs[publication] || 0;                                                     // 290
      singlePubMetrics.activeDocs = activeDocs[publication] || 0;                                                     // 291
      singlePubMetrics.avgDocSize = avgDocSize[publication] || 0;                                                     // 292
      singlePubMetrics.avgObserverReuse = avgObserverReuse[publication] || 0;                                         // 293
    }                                                                                                                 // 294
    payload.pubMetrics.push(metricsByMinute[dateId]);                                                                 // 295
  }                                                                                                                   // 296
                                                                                                                      // 297
  //collect traces and send them with the payload                                                                     // 298
  payload.pubRequests = this.tracerStore.collectTraces();                                                             // 299
                                                                                                                      // 300
  return payload;                                                                                                     // 301
};                                                                                                                    // 302
                                                                                                                      // 303
PubsubModel.prototype.incrementHandleCount = function(trace, isCached) {                                              // 304
  var publicationName = trace.name;                                                                                   // 305
  var timestamp = Ntp._now();                                                                                         // 306
  var publication = this._getMetrics(timestamp, publicationName);                                                     // 307
                                                                                                                      // 308
  var session = Meteor.default_server.sessions[trace.session];                                                        // 309
  if(session) {                                                                                                       // 310
    var sub = session._namedSubs[trace.id];                                                                           // 311
    sub._totalObservers = sub._totalObservers || 0;                                                                   // 312
    sub._cachedObservers = sub._cachedObservers || 0;                                                                 // 313
  }                                                                                                                   // 314
  // not sure, we need to do this? But I don't need to break the however                                              // 315
  sub = sub || {_totalObservers:0 , _cachedObservers: 0};                                                             // 316
                                                                                                                      // 317
  publication.totalObservers++;                                                                                       // 318
  sub._totalObservers++;                                                                                              // 319
  if(isCached) {                                                                                                      // 320
    publication.cachedObservers++;                                                                                    // 321
    sub._cachedObservers++;                                                                                           // 322
  }                                                                                                                   // 323
}                                                                                                                     // 324
                                                                                                                      // 325
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/meteorhacks:kadira/lib/models/system.js                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var os = Npm.require('os');                                                                                           // 1
                                                                                                                      // 2
SystemModel = function () {                                                                                           // 3
  var self = this;                                                                                                    // 4
  this.startTime = Ntp._now();                                                                                        // 5
  try {                                                                                                               // 6
    var usage = (typeof KadiraBinaryDeps != 'undefined')?                                                             // 7
      KadiraBinaryDeps.usage: Npm.require('usage');                                                                   // 8
    this.usageLookup = Meteor._wrapAsync(usage.lookup.bind(usage));                                                   // 9
  } catch(ex) {                                                                                                       // 10
    console.error('Kadira: usage npm module loading failed - ', ex.message);                                          // 11
  }                                                                                                                   // 12
}                                                                                                                     // 13
                                                                                                                      // 14
_.extend(SystemModel.prototype, KadiraModel.prototype);                                                               // 15
                                                                                                                      // 16
SystemModel.prototype.buildPayload = function() {                                                                     // 17
  var metrics = {};                                                                                                   // 18
  var now = Ntp._now();                                                                                               // 19
  metrics.startTime = Kadira.syncedDate.syncTime(this.startTime);                                                     // 20
  metrics.endTime = Kadira.syncedDate.syncTime(now);                                                                  // 21
                                                                                                                      // 22
  metrics.sessions = _.keys(Meteor.default_server.sessions).length;                                                   // 23
  metrics.memory = process.memoryUsage().rss / (1024*1024);                                                           // 24
                                                                                                                      // 25
  if(this.usageLookup && !this._dontTrackUsage) {                                                                     // 26
    try {                                                                                                             // 27
      metrics.pcpu = this.usageLookup(process.pid, {keepHistory: true}).cpu;                                          // 28
      // this metric will be added soon. So we just need to make it reserved                                          // 29
      metrics.cputime = -1;                                                                                           // 30
    } catch(ex) {                                                                                                     // 31
      if(/Unsupported OS/.test(ex.message)) {                                                                         // 32
        this._dontTrackUsage = true;                                                                                  // 33
        var message =                                                                                                 // 34
          "kadira: we can't track CPU usage in this OS. " +                                                           // 35
          "But it will work when you deploy your app!"                                                                // 36
        console.warn(message);                                                                                        // 37
      } else {                                                                                                        // 38
        throw ex;                                                                                                     // 39
      }                                                                                                               // 40
    }                                                                                                                 // 41
  }                                                                                                                   // 42
                                                                                                                      // 43
  this.startTime = now;                                                                                               // 44
  return {systemMetrics: [metrics]};                                                                                  // 45
};                                                                                                                    // 46
                                                                                                                      // 47
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/meteorhacks:kadira/lib/models/errors.js                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
ErrorModel = function (appId) {                                                                                       // 2
  var self = this;                                                                                                    // 3
  this.appId = appId;                                                                                                 // 4
  this.errors = {};                                                                                                   // 5
  this.startTime = Date.now();                                                                                        // 6
  this.maxErrors = 10;                                                                                                // 7
}                                                                                                                     // 8
                                                                                                                      // 9
_.extend(ErrorModel.prototype, KadiraModel.prototype);                                                                // 10
                                                                                                                      // 11
ErrorModel.prototype.buildPayload = function() {                                                                      // 12
  var metrics = _.values(this.errors);                                                                                // 13
  this.startTime = Date.now();                                                                                        // 14
  this.errors = {};                                                                                                   // 15
  return {errors: metrics};                                                                                           // 16
};                                                                                                                    // 17
                                                                                                                      // 18
ErrorModel.prototype.errorCount = function () {                                                                       // 19
  return _.values(this.errors).length;                                                                                // 20
};                                                                                                                    // 21
                                                                                                                      // 22
ErrorModel.prototype.trackError = function(ex, trace) {                                                               // 23
  var key = trace.type + ':' + ex.message;                                                                            // 24
  if(this.errors[key]) {                                                                                              // 25
    this.errors[key].count++;                                                                                         // 26
  } else if (this.errorCount() < this.maxErrors) {                                                                    // 27
    this.errors[key] = this._formatError(ex, trace);                                                                  // 28
  }                                                                                                                   // 29
};                                                                                                                    // 30
                                                                                                                      // 31
ErrorModel.prototype._formatError = function(ex, trace) {                                                             // 32
  var time = Date.now();                                                                                              // 33
  return {                                                                                                            // 34
    appId: this.appId,                                                                                                // 35
    name: ex.message,                                                                                                 // 36
    type: trace.type,                                                                                                 // 37
    startTime: time,                                                                                                  // 38
    subType: trace.subType || trace.name,                                                                             // 39
    trace: trace,                                                                                                     // 40
    stacks: [{stack: ex.stack}],                                                                                      // 41
    count: 1,                                                                                                         // 42
  }                                                                                                                   // 43
};                                                                                                                    // 44
                                                                                                                      // 45
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/meteorhacks:kadira/lib/kadira.js                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var http = Npm.require('http');                                                                                       // 1
var hostname = Npm.require('os').hostname();                                                                          // 2
var logger = Npm.require('debug')('kadira:apm');                                                                      // 3
var Fibers = Npm.require('fibers');                                                                                   // 4
                                                                                                                      // 5
Kadira = {};                                                                                                          // 6
Kadira.models = {};                                                                                                   // 7
Kadira.options = {};                                                                                                  // 8
Kadira.env = {                                                                                                        // 9
  currentSub: new Meteor.EnvironmentVariable(),                                                                       // 10
  kadiraInfo: new Meteor.EnvironmentVariable(),                                                                       // 11
};                                                                                                                    // 12
                                                                                                                      // 13
Kadira.connect = function(appId, appSecret, options) {                                                                // 14
  options = options || {};                                                                                            // 15
  options.appId = appId;                                                                                              // 16
  options.payloadTimeout = options.payloadTimeout || 1000 * 20;                                                       // 17
  options.endpoint = options.endpoint || "https://engine.kadira.io";                                                  // 18
  options.thresholds = options.thresholds || {};                                                                      // 19
                                                                                                                      // 20
  Kadira.options = options;                                                                                           // 21
  Kadira.syncedDate = new Ntp(options.endpoint);                                                                      // 22
  Kadira.syncedDate.sync();                                                                                           // 23
  Kadira.models.methods = new MethodsModel(options.thresholds.methods);                                               // 24
  Kadira.models.pubsub = new PubsubModel();                                                                           // 25
  Kadira.models.system = new SystemModel();                                                                           // 26
  Kadira.models.error = new ErrorModel(appId);                                                                        // 27
  Kadira.sendPayload = sendPayload;                                                                                   // 28
                                                                                                                      // 29
  // setting runtime info, which will be sent to kadira                                                               // 30
  __meteor_runtime_config__.kadira = {                                                                                // 31
    appId: appId,                                                                                                     // 32
    endpoint: options.endpoint                                                                                        // 33
  };                                                                                                                  // 34
                                                                                                                      // 35
  if(canTrackErrors()) {                                                                                              // 36
    Kadira.enableErrorTracking();                                                                                     // 37
  } else {                                                                                                            // 38
    Kadira.disableErrorTracking();                                                                                    // 39
  }                                                                                                                   // 40
                                                                                                                      // 41
  //track how many times we've sent the data                                                                          // 42
  var countDataSent = 0;                                                                                              // 43
  var detailInfoSentInterval = Math.ceil((1000 * 60) / options.payloadTimeout); //once per min                        // 44
                                                                                                                      // 45
  if(appId && appSecret) {                                                                                            // 46
    appId = appId.trim();                                                                                             // 47
    appSecret = appSecret.trim();                                                                                     // 48
                                                                                                                      // 49
    pingToCheckAuth(function(){                                                                                       // 50
      schedulePayloadSend();                                                                                          // 51
    });                                                                                                               // 52
    logger('connected to app: ', appId);                                                                              // 53
  } else {                                                                                                            // 54
    throw new Error('Kadira: required appId and appSecret');                                                          // 55
  }                                                                                                                   // 56
                                                                                                                      // 57
  //start wrapping Meteor's internal methods                                                                          // 58
  Kadira._startInstrumenting(function() {                                                                             // 59
    console.log('Kadira: completed instrumenting the app')                                                            // 60
    Kadira.connected = true;                                                                                          // 61
  });                                                                                                                 // 62
                                                                                                                      // 63
  var payloadRetries = 0;                                                                                             // 64
  var payloadRetry = new Retry({                                                                                      // 65
      minCount: 0, // don't do any immediate payloadRetries                                                           // 66
      baseTimeout: 5*1000,                                                                                            // 67
      maxTimeout: 60000                                                                                               // 68
  });                                                                                                                 // 69
                                                                                                                      // 70
  function sendPayload(callback) {                                                                                    // 71
                                                                                                                      // 72
    callHTTP();                                                                                                       // 73
                                                                                                                      // 74
    function callHTTP() {                                                                                             // 75
      new Fibers(function() {                                                                                         // 76
        var payload = buildPayload();                                                                                 // 77
        var headers = buildHeaders();                                                                                 // 78
        var httpOptions = {headers: headers, data: payload};                                                          // 79
                                                                                                                      // 80
        try {                                                                                                         // 81
          var response = HTTP.call('POST', options.endpoint, httpOptions);                                            // 82
          processResponse(response);                                                                                  // 83
        } catch(err) {                                                                                                // 84
          tryAgain(err);                                                                                              // 85
        }                                                                                                             // 86
      }).run();                                                                                                       // 87
    }                                                                                                                 // 88
                                                                                                                      // 89
    function processResponse(response) {                                                                              // 90
      if(response.statusCode == '401') {                                                                              // 91
        throw new Error('Kadira: AppId, AppSecret combination is invalid');                                           // 92
      } else if(response.statusCode == '200') {                                                                       // 93
        //success send again in 10 secs                                                                               // 94
        schedulePayloadSend();                                                                                        // 95
        if(payloadRetries > 0) {                                                                                      // 96
          logger('connected again and payload sent.')                                                                 // 97
        }                                                                                                             // 98
        cleaPayloadRetry();                                                                                           // 99
        callback && callback();                                                                                       // 100
      } else {                                                                                                        // 101
        tryAgain();                                                                                                   // 102
      }                                                                                                               // 103
    }                                                                                                                 // 104
                                                                                                                      // 105
    function tryAgain(err) {                                                                                          // 106
      err = err || {};                                                                                                // 107
      logger('retrying to send payload to server')                                                                    // 108
      if(++payloadRetries < 5) {                                                                                      // 109
        payloadRetry.retryLater(payloadRetries, callHTTP);                                                            // 110
      } else {                                                                                                        // 111
        console.error('Kadira: Error sending payload(dropped after 5 tries) ', err.message);                          // 112
        cleaPayloadRetry();                                                                                           // 113
        schedulePayloadSend();                                                                                        // 114
      }                                                                                                               // 115
    }                                                                                                                 // 116
                                                                                                                      // 117
  }                                                                                                                   // 118
                                                                                                                      // 119
  function cleaPayloadRetry() {                                                                                       // 120
    payloadRetries = 0;                                                                                               // 121
    payloadRetry.clear();                                                                                             // 122
  }                                                                                                                   // 123
                                                                                                                      // 124
  function buildHeaders(){                                                                                            // 125
    return {'APM-APP-ID': appId, 'APM-APP-SECRET': appSecret}                                                         // 126
  }                                                                                                                   // 127
                                                                                                                      // 128
  function schedulePayloadSend() {                                                                                    // 129
    setTimeout(sendPayload, options.payloadTimeout);                                                                  // 130
  }                                                                                                                   // 131
                                                                                                                      // 132
  function canTrackErrors () {                                                                                        // 133
    if(Kadira.options.enableErrorTracking === undefined) {                                                            // 134
      return true;                                                                                                    // 135
    } else {                                                                                                          // 136
      return Kadira.options.enableErrorTracking;                                                                      // 137
    }                                                                                                                 // 138
  }                                                                                                                   // 139
                                                                                                                      // 140
                                                                                                                      // 141
  var authCheckFailures = 0;                                                                                          // 142
  function pingToCheckAuth(callback){                                                                                 // 143
    var httpOptions = {headers: buildHeaders(), data: {}};                                                            // 144
    var endpoint = options.endpoint + '/ping'                                                                         // 145
                                                                                                                      // 146
    new Fibers(function() {                                                                                           // 147
      HTTP.call('POST', endpoint, httpOptions, function(err, response){                                               // 148
        if(response) {                                                                                                // 149
          if(response.statusCode == 200) {                                                                            // 150
            console.log('Kadira: successfully authenticated');                                                        // 151
            authRetry.clear();                                                                                        // 152
            callback();                                                                                               // 153
          } else if(response.statusCode == 401) {                                                                     // 154
            console.error('Kadira: authenticatation failed - check your appId & appSecret')                           // 155
          } else {                                                                                                    // 156
            retryPingToCheckAuth(callback);                                                                           // 157
          }                                                                                                           // 158
        } else {                                                                                                      // 159
          retryPingToCheckAuth();                                                                                     // 160
        }                                                                                                             // 161
      });                                                                                                             // 162
    }).run();                                                                                                         // 163
                                                                                                                      // 164
    var authRetry = new Retry({                                                                                       // 165
      minCount: 0, // don't do any immediate retries                                                                  // 166
      baseTimeout: 5*1000 // start with 30s                                                                           // 167
    });                                                                                                               // 168
                                                                                                                      // 169
    function retryPingToCheckAuth(){                                                                                  // 170
      console.log('Kadira: retrying to authenticate');                                                                // 171
      authRetry.retryLater(authCheckFailures, function(){                                                             // 172
        pingToCheckAuth(callback)                                                                                     // 173
      });                                                                                                             // 174
    }                                                                                                                 // 175
  }                                                                                                                   // 176
                                                                                                                      // 177
  function buildPayload() {                                                                                           // 178
    var payload = {host: hostname};                                                                                   // 179
    var buildDetailedInfo = (countDataSent++ % detailInfoSentInterval) == 0;                                          // 180
    _.extend(payload, Kadira.models.methods.buildPayload(buildDetailedInfo));                                         // 181
    _.extend(payload, Kadira.models.pubsub.buildPayload(buildDetailedInfo));                                          // 182
    _.extend(payload, Kadira.models.system.buildPayload());                                                           // 183
    if(options.enableErrorTracking) {                                                                                 // 184
      _.extend(payload, Kadira.models.error.buildPayload());                                                          // 185
    }                                                                                                                 // 186
                                                                                                                      // 187
    return payload;                                                                                                   // 188
  }                                                                                                                   // 189
};                                                                                                                    // 190
                                                                                                                      // 191
// this return the __kadiraInfo from the current Fiber by default                                                     // 192
// if called with 2nd argument as true, it will get the kadira info from                                              // 193
// Meteor.EnvironmentVariable                                                                                         // 194
//                                                                                                                    // 195
// WARNNING: retunred info object is the reference object.                                                            // 196
//  Changing it might cause issues when building traces. So use with care                                             // 197
Kadira._getInfo = function(currentFiber, useEnvironmentVariable) {                                                    // 198
  currentFiber = currentFiber || Fibers.current;                                                                      // 199
  if(currentFiber) {                                                                                                  // 200
    if(useEnvironmentVariable) {                                                                                      // 201
      return Kadira.env.kadiraInfo.get();                                                                             // 202
    }                                                                                                                 // 203
    return currentFiber.__kadiraInfo;                                                                                 // 204
  }                                                                                                                   // 205
};                                                                                                                    // 206
                                                                                                                      // 207
// this does not clone the info object. So, use with care                                                             // 208
Kadira._setInfo = function(info) {                                                                                    // 209
  Fibers.current.__kadiraInfo = info;                                                                                 // 210
  var kadiraInfo = Kadira.env.kadiraInfo.get();                                                                       // 211
};                                                                                                                    // 212
                                                                                                                      // 213
Kadira.enableErrorTracking = function () {                                                                            // 214
  __meteor_runtime_config__.kadira.enableErrorTracking = true;                                                        // 215
  Kadira.options.enableErrorTracking = true;                                                                          // 216
};                                                                                                                    // 217
                                                                                                                      // 218
Kadira.disableErrorTracking = function () {                                                                           // 219
  __meteor_runtime_config__.kadira.enableErrorTracking = false;                                                       // 220
  Kadira.options.enableErrorTracking = false;                                                                         // 221
};                                                                                                                    // 222
                                                                                                                      // 223
Kadira.trackError = function (type, message, options) {                                                               // 224
  if(Kadira.options.enableErrorTracking && type && message) {                                                         // 225
    options = options || {};                                                                                          // 226
    options.subType = options.subType || 'server';                                                                    // 227
    options.stacks = options.stacks || '';                                                                            // 228
    var error = {message: message, stack: options.stacks};                                                            // 229
    var trace = {                                                                                                     // 230
      type: type,                                                                                                     // 231
      subType: options.subType,                                                                                       // 232
      name: message,                                                                                                  // 233
      errored: true,                                                                                                  // 234
      at: Kadira.syncedDate.getTime(),                                                                                // 235
      events: [['start', 0, {}], ['error', 0, {error: error}]],                                                       // 236
      metrics: {total: 0}                                                                                             // 237
    };                                                                                                                // 238
    Kadira.models.error.trackError(error, trace);                                                                     // 239
  }                                                                                                                   // 240
}                                                                                                                     // 241
                                                                                                                      // 242
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/meteorhacks:kadira/lib/check_for_oplog.js                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
// expose for testing purpose                                                                                         // 1
OplogCheck = {};                                                                                                      // 2
                                                                                                                      // 3
OplogCheck._070 = function(cursorDescription) {                                                                       // 4
  var options = cursorDescription.options;                                                                            // 5
  if (options.limit) {                                                                                                // 6
    return {                                                                                                          // 7
      code: "070_LIMIT_NOT_SUPPORTED",                                                                                // 8
      reason: "Meteor 0.7.0 does not support limit with oplog.",                                                      // 9
      solution: "Upgrade your app to Meteor version 0.7.2 or later."                                                  // 10
    }                                                                                                                 // 11
  };                                                                                                                  // 12
                                                                                                                      // 13
  var exists$ = _.any(cursorDescription.selector, function (value, field) {                                           // 14
    if (field.substr(0, 1) === '$')                                                                                   // 15
      return true;                                                                                                    // 16
  });                                                                                                                 // 17
                                                                                                                      // 18
  if(exists$) {                                                                                                       // 19
    return {                                                                                                          // 20
      code: "070_$_NOT_SUPPORTED",                                                                                    // 21
      reason: "Meteor 0.7.0 supports only equal checks with oplog.",                                                  // 22
      solution: "Upgrade your app to Meteor version 0.7.2 or later."                                                  // 23
    }                                                                                                                 // 24
  };                                                                                                                  // 25
                                                                                                                      // 26
  var onlyScalers = _.all(cursorDescription.selector, function (value, field) {                                       // 27
    return typeof value === "string" ||                                                                               // 28
      typeof value === "number" ||                                                                                    // 29
      typeof value === "boolean" ||                                                                                   // 30
      value === null ||                                                                                               // 31
      value instanceof Meteor.Collection.ObjectID;                                                                    // 32
  });                                                                                                                 // 33
                                                                                                                      // 34
  if(!onlyScalers) {                                                                                                  // 35
    return {                                                                                                          // 36
      code: "070_ONLY_SCALERS",                                                                                       // 37
      reason: "Meteor 0.7.0 only supports scalers as comparators.",                                                   // 38
      solution: "Upgrade your app to Meteor version 0.7.2 or later."                                                  // 39
    }                                                                                                                 // 40
  }                                                                                                                   // 41
                                                                                                                      // 42
  return true;                                                                                                        // 43
};                                                                                                                    // 44
                                                                                                                      // 45
OplogCheck._071 = function(cursorDescription) {                                                                       // 46
  var options = cursorDescription.options;                                                                            // 47
  var matcher = new Minimongo.Matcher(cursorDescription.selector);                                                    // 48
  if (options.limit) {                                                                                                // 49
    return {                                                                                                          // 50
      code: "071_LIMIT_NOT_SUPPORTED",                                                                                // 51
      reason: "Meteor 0.7.1 does not support limit with oplog.",                                                      // 52
      solution: "Upgrade your app to Meteor version 0.7.2 or later."                                                  // 53
    }                                                                                                                 // 54
  };                                                                                                                  // 55
                                                                                                                      // 56
  return true;                                                                                                        // 57
};                                                                                                                    // 58
                                                                                                                      // 59
                                                                                                                      // 60
OplogCheck.env = function() {                                                                                         // 61
  if(!process.env.MONGO_OPLOG_URL) {                                                                                  // 62
    return {                                                                                                          // 63
      code: "NO_ENV",                                                                                                 // 64
      reason: "You haven't added oplog support for your the Meteor app.",                                             // 65
      solution: "Add oplog support for your Meteor app. see: http://goo.gl/Co1jJc"                                    // 66
    }                                                                                                                 // 67
  } else {                                                                                                            // 68
    return true;                                                                                                      // 69
  }                                                                                                                   // 70
};                                                                                                                    // 71
                                                                                                                      // 72
OplogCheck.disableOplog = function(cursorDescription) {                                                               // 73
  if(cursorDescription.options._disableOplog) {                                                                       // 74
    return {                                                                                                          // 75
      code: "DISABLE_OPLOG",                                                                                          // 76
      reason: "You've disable oplog for this cursor explicitly with _disableOplog option."                            // 77
    };                                                                                                                // 78
  } else {                                                                                                            // 79
    return true;                                                                                                      // 80
  }                                                                                                                   // 81
};                                                                                                                    // 82
                                                                                                                      // 83
// when creating Minimongo.Matcher object, if that's throws an exception                                              // 84
// meteor won't do the oplog support                                                                                  // 85
OplogCheck.miniMongoMatcher = function(cursorDescription) {                                                           // 86
  if(Minimongo.Matcher) {                                                                                             // 87
    try {                                                                                                             // 88
      var matcher = new Minimongo.Matcher(cursorDescription.selector);                                                // 89
      return true;                                                                                                    // 90
    } catch(ex) {                                                                                                     // 91
      return {                                                                                                        // 92
        code: "MINIMONGO_MATCHER_ERROR",                                                                              // 93
        reason: "There's something wrong in your mongo query: " +  ex.message,                                        // 94
        solution: "Check your selector and change it accordingly."                                                    // 95
      };                                                                                                              // 96
    }                                                                                                                 // 97
  } else {                                                                                                            // 98
    // If there is no Minimongo.Matcher, we don't need to check this                                                  // 99
    return true;                                                                                                      // 100
  }                                                                                                                   // 101
};                                                                                                                    // 102
                                                                                                                      // 103
OplogCheck.miniMongoSorter = function(cursorDescription) {                                                            // 104
  var matcher = new Minimongo.Matcher(cursorDescription.selector);                                                    // 105
  if(Minimongo.Sorter && cursorDescription.options.sort) {                                                            // 106
    try {                                                                                                             // 107
      var sorter = new Minimongo.Sorter(                                                                              // 108
        cursorDescription.options.sort,                                                                               // 109
        { matcher: matcher }                                                                                          // 110
      );                                                                                                              // 111
      return true;                                                                                                    // 112
    } catch(ex) {                                                                                                     // 113
      return {                                                                                                        // 114
        code: "MINIMONGO_SORTER_ERROR",                                                                               // 115
        reason: "Some of your sort specifiers are not supported: " + ex.message,                                      // 116
        solution: "Check your sort specifiers and chage them accordingly."                                            // 117
      }                                                                                                               // 118
    }                                                                                                                 // 119
  } else {                                                                                                            // 120
    return true;                                                                                                      // 121
  }                                                                                                                   // 122
};                                                                                                                    // 123
                                                                                                                      // 124
OplogCheck.fields = function(cursorDescription) {                                                                     // 125
  var options = cursorDescription.options;                                                                            // 126
  if(options.fields) {                                                                                                // 127
    try {                                                                                                             // 128
      LocalCollection._checkSupportedProjection(options.fields);                                                      // 129
      return true;                                                                                                    // 130
    } catch (e) {                                                                                                     // 131
      if (e.name === "MinimongoError") {                                                                              // 132
        return {                                                                                                      // 133
          code: "NOT_SUPPORTED_FIELDS",                                                                               // 134
          reason: "Some of the field filters are not supported: " + e.message,                                        // 135
          solution: "Try removing those field filters."                                                               // 136
        };                                                                                                            // 137
      } else {                                                                                                        // 138
        throw e;                                                                                                      // 139
      }                                                                                                               // 140
    }                                                                                                                 // 141
  }                                                                                                                   // 142
  return true;                                                                                                        // 143
};                                                                                                                    // 144
                                                                                                                      // 145
OplogCheck.skip = function(cursorDescription) {                                                                       // 146
  if(cursorDescription.options.skip) {                                                                                // 147
    return {                                                                                                          // 148
      code: "SKIP_NOT_SUPPORTED",                                                                                     // 149
      reason: "Skip does not support with oplog.",                                                                    // 150
      solution: "Try to avoid using skip. Use range queries instead: http://goo.gl/b522Av"                            // 151
    };                                                                                                                // 152
  }                                                                                                                   // 153
                                                                                                                      // 154
  return true;                                                                                                        // 155
};                                                                                                                    // 156
                                                                                                                      // 157
OplogCheck.where = function(cursorDescription) {                                                                      // 158
  var matcher = new Minimongo.Matcher(cursorDescription.selector);                                                    // 159
  if(matcher.hasWhere()) {                                                                                            // 160
    return {                                                                                                          // 161
      code: "WHERE_NOT_SUPPORTED",                                                                                    // 162
      reason: "Meteor does not support queries with $where.",                                                         // 163
      solution: "Try to remove $where from your query. Use some alternative."                                         // 164
    }                                                                                                                 // 165
  };                                                                                                                  // 166
                                                                                                                      // 167
  return true;                                                                                                        // 168
};                                                                                                                    // 169
                                                                                                                      // 170
OplogCheck.geo = function(cursorDescription) {                                                                        // 171
  var matcher = new Minimongo.Matcher(cursorDescription.selector);                                                    // 172
                                                                                                                      // 173
  if(matcher.hasGeoQuery()) {                                                                                         // 174
    return {                                                                                                          // 175
      code: "GEO_NOT_SUPPORTED",                                                                                      // 176
      reason: "Meteor does not support queries with geo partial operators.",                                          // 177
      solution: "Try to remove geo partial operators from your query if possible."                                    // 178
    }                                                                                                                 // 179
  };                                                                                                                  // 180
                                                                                                                      // 181
  return true;                                                                                                        // 182
};                                                                                                                    // 183
                                                                                                                      // 184
OplogCheck.limitButNoSort = function(cursorDescription) {                                                             // 185
  var options = cursorDescription.options;                                                                            // 186
                                                                                                                      // 187
  if((options.limit && !options.sort)) {                                                                              // 188
    return {                                                                                                          // 189
      code: "LIMIT_NO_SORT",                                                                                          // 190
      reason: "Meteor oplog implementation does not support limit without a sort specifier.",                         // 191
      solution: "Try adding a sort specifier."                                                                        // 192
    }                                                                                                                 // 193
  };                                                                                                                  // 194
                                                                                                                      // 195
  return true;                                                                                                        // 196
};                                                                                                                    // 197
                                                                                                                      // 198
OplogCheck.olderVersion = function(cursorDescription, driver) {                                                       // 199
  if(driver && !driver.constructor.cursorSupported) {                                                                 // 200
    return {                                                                                                          // 201
      code: "OLDER_VERSION",                                                                                          // 202
      reason: "Your Meteor version does not have oplog support.",                                                     // 203
      solution: "Upgrade your app to Meteor version 0.7.2 or later."                                                  // 204
    };                                                                                                                // 205
  }                                                                                                                   // 206
  return true;                                                                                                        // 207
};                                                                                                                    // 208
                                                                                                                      // 209
OplogCheck.gitCheckout = function(cursorDescription, driver) {                                                        // 210
  if(!Meteor.release) {                                                                                               // 211
    return {                                                                                                          // 212
      code: "GIT_CHECKOUT",                                                                                           // 213
      reason: "Seems like your Meteor version is based on a Git checkout and it doesn't have the oplog support.",     // 214
      solution: "Try to upgrade your Meteor version."                                                                 // 215
    };                                                                                                                // 216
  }                                                                                                                   // 217
  return true;                                                                                                        // 218
};                                                                                                                    // 219
                                                                                                                      // 220
var preRunningMatchers = [                                                                                            // 221
  OplogCheck.env,                                                                                                     // 222
  OplogCheck.disableOplog,                                                                                            // 223
  OplogCheck.miniMongoMatcher                                                                                         // 224
];                                                                                                                    // 225
                                                                                                                      // 226
var globalMatchers = [                                                                                                // 227
  OplogCheck.fields,                                                                                                  // 228
  OplogCheck.skip,                                                                                                    // 229
  OplogCheck.where,                                                                                                   // 230
  OplogCheck.geo,                                                                                                     // 231
  OplogCheck.limitButNoSort,                                                                                          // 232
  OplogCheck.miniMongoSorter,                                                                                         // 233
  OplogCheck.olderVersion,                                                                                            // 234
  OplogCheck.gitCheckout                                                                                              // 235
];                                                                                                                    // 236
                                                                                                                      // 237
var versionMatchers = [                                                                                               // 238
  [/^0\.7\.1/, OplogCheck._071],                                                                                      // 239
  [/^0\.7\.0/, OplogCheck._070],                                                                                      // 240
];                                                                                                                    // 241
                                                                                                                      // 242
Kadira.checkWhyNoOplog = function(cursorDescription, observerDriver) {                                                // 243
  var result = runMatchers(preRunningMatchers, cursorDescription, observerDriver);                                    // 244
  if(result !== true) {                                                                                               // 245
    return result;                                                                                                    // 246
  }                                                                                                                   // 247
                                                                                                                      // 248
  var meteorVersion = Meteor.release;                                                                                 // 249
  for(var lc=0; lc<versionMatchers.length; lc++) {                                                                    // 250
    var matcherInfo = versionMatchers[lc];                                                                            // 251
    if(matcherInfo[0].test(meteorVersion)) {                                                                          // 252
      var matched = matcherInfo[1](cursorDescription, observerDriver);                                                // 253
      if(matched !== true) {                                                                                          // 254
        return matched;                                                                                               // 255
      }                                                                                                               // 256
    }                                                                                                                 // 257
  }                                                                                                                   // 258
                                                                                                                      // 259
  result = runMatchers(globalMatchers, cursorDescription, observerDriver);                                            // 260
  if(result !== true) {                                                                                               // 261
    return result;                                                                                                    // 262
  }                                                                                                                   // 263
                                                                                                                      // 264
  return {                                                                                                            // 265
    code: "OPLOG_SUPPORTED",                                                                                          // 266
    reason: "This query should support oplog. It's weird if it's not.",                                               // 267
    solution: "Please contact Kadira support and let's discuss."                                                      // 268
  };                                                                                                                  // 269
};                                                                                                                    // 270
                                                                                                                      // 271
function runMatchers(matcherList, cursorDescription, observerDriver) {                                                // 272
  for(var lc=0; lc<matcherList.length; lc++) {                                                                        // 273
    var matcher = matcherList[lc];                                                                                    // 274
    var matched = matcher(cursorDescription, observerDriver);                                                         // 275
    if(matched !== true) {                                                                                            // 276
      return matched;                                                                                                 // 277
    }                                                                                                                 // 278
  }                                                                                                                   // 279
  return true;                                                                                                        // 280
}                                                                                                                     // 281
                                                                                                                      // 282
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/meteorhacks:kadira/lib/tracer.js                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Fibers = Npm.require('fibers');                                                                                   // 1
var eventLogger = Npm.require('debug')('kadira:tracer');                                                              // 2
var REPITITIVE_EVENTS = {'db': true, 'http': true, 'email': true, 'wait': true, 'async': true};                       // 3
                                                                                                                      // 4
function Tracer() {                                                                                                   // 5
                                                                                                                      // 6
};                                                                                                                    // 7
                                                                                                                      // 8
//In the future, we might wan't to track inner fiber events too.                                                      // 9
//Then we can't serialize the object with methods                                                                     // 10
//That's why we use this method of returning the data                                                                 // 11
Tracer.prototype.start = function(session, msg) {                                                                     // 12
  var traceInfo = {                                                                                                   // 13
    _id: session.id + "::" + msg.id,                                                                                  // 14
    session: session.id,                                                                                              // 15
    userId: session.userId,                                                                                           // 16
    id: msg.id,                                                                                                       // 17
    events: []                                                                                                        // 18
  };                                                                                                                  // 19
                                                                                                                      // 20
  if(msg.msg == 'method') {                                                                                           // 21
    traceInfo.type = 'method';                                                                                        // 22
    traceInfo.name = msg.method;                                                                                      // 23
  } else if(msg.msg == 'sub') {                                                                                       // 24
    traceInfo.type = 'sub';                                                                                           // 25
    traceInfo.name = msg.name;                                                                                        // 26
  } else {                                                                                                            // 27
    return null;                                                                                                      // 28
  }                                                                                                                   // 29
                                                                                                                      // 30
  return traceInfo;                                                                                                   // 31
};                                                                                                                    // 32
                                                                                                                      // 33
Tracer.prototype.event = function(traceInfo, type, data) {                                                            // 34
  // do not allow to proceed, if already completed or errored                                                         // 35
  var lastEvent = this.getLastEvent(traceInfo);                                                                       // 36
  if(lastEvent && ['complete', 'error'].indexOf(lastEvent.type) >= 0) {                                               // 37
    return false;                                                                                                     // 38
  }                                                                                                                   // 39
                                                                                                                      // 40
  //expecting a end event                                                                                             // 41
  var eventId = true;                                                                                                 // 42
                                                                                                                      // 43
  //specially handling for repitivive events like db, http                                                            // 44
  if(REPITITIVE_EVENTS[type]) {                                                                                       // 45
    //can't accept a new start event                                                                                  // 46
    if(traceInfo._lastEventId) {                                                                                      // 47
      return false;                                                                                                   // 48
    }                                                                                                                 // 49
    eventId = traceInfo._lastEventId = DefaultUniqueId.get();                                                         // 50
  }                                                                                                                   // 51
                                                                                                                      // 52
  var event = {type: type, at: Ntp._now()};                                                                           // 53
  if(data) {                                                                                                          // 54
    event.data = data;                                                                                                // 55
  }                                                                                                                   // 56
                                                                                                                      // 57
  traceInfo.events.push(event);                                                                                       // 58
                                                                                                                      // 59
  eventLogger("%s %s", type, traceInfo._id);                                                                          // 60
  return eventId;                                                                                                     // 61
};                                                                                                                    // 62
                                                                                                                      // 63
Tracer.prototype.eventEnd = function(traceInfo, eventId, data) {                                                      // 64
  if(traceInfo._lastEventId && traceInfo._lastEventId == eventId) {                                                   // 65
    var lastEvent = this.getLastEvent(traceInfo);                                                                     // 66
    var type = lastEvent.type + 'end';                                                                                // 67
    var event = {type: type, at: Ntp._now()};                                                                         // 68
    if(data) {                                                                                                        // 69
      event.data = data;                                                                                              // 70
    }                                                                                                                 // 71
    traceInfo.events.push(event);                                                                                     // 72
    eventLogger("%s %s", type, traceInfo._id);                                                                        // 73
                                                                                                                      // 74
    traceInfo._lastEventId = null;                                                                                    // 75
    return true;                                                                                                      // 76
  } else {                                                                                                            // 77
    return false;                                                                                                     // 78
  }                                                                                                                   // 79
};                                                                                                                    // 80
                                                                                                                      // 81
Tracer.prototype.getLastEvent = function(traceInfo) {                                                                 // 82
  return traceInfo.events[traceInfo.events.length -1]                                                                 // 83
};                                                                                                                    // 84
                                                                                                                      // 85
Tracer.prototype.endLastEvent = function(traceInfo) {                                                                 // 86
  var lastEvent = this.getLastEvent(traceInfo);                                                                       // 87
  if(lastEvent && !/end$/.test(lastEvent.type)) {                                                                     // 88
    traceInfo.events.push({                                                                                           // 89
      type: lastEvent.type + 'end',                                                                                   // 90
      at: Ntp._now()                                                                                                  // 91
    });                                                                                                               // 92
    return true;                                                                                                      // 93
  }                                                                                                                   // 94
  return false;                                                                                                       // 95
};                                                                                                                    // 96
                                                                                                                      // 97
Tracer.prototype.buildTrace = function(traceInfo) {                                                                   // 98
  var firstEvent = traceInfo.events[0];                                                                               // 99
  var lastEvent = traceInfo.events[traceInfo.events.length - 1];                                                      // 100
  var processedEvents = [];                                                                                           // 101
                                                                                                                      // 102
  if(firstEvent.type != 'start') {                                                                                    // 103
    console.warn('Kadira: trace is not started yet');                                                                 // 104
    return null;                                                                                                      // 105
  } else if(lastEvent.type != 'complete' && lastEvent.type != 'error') {                                              // 106
    //trace is not completed or errored yet                                                                           // 107
    console.warn('Kadira: trace is not completed or errored yet');                                                    // 108
    return null;                                                                                                      // 109
  } else {                                                                                                            // 110
    //build the metrics                                                                                               // 111
    traceInfo.errored = lastEvent.type == 'error';                                                                    // 112
    traceInfo.at = firstEvent.at;                                                                                     // 113
                                                                                                                      // 114
    var metrics = {                                                                                                   // 115
      total: lastEvent.at - firstEvent.at,                                                                            // 116
    };                                                                                                                // 117
                                                                                                                      // 118
    var totalNonCompute = 0;                                                                                          // 119
                                                                                                                      // 120
    firstEvent = ['start', 0];                                                                                        // 121
    if(traceInfo.events[0].data) firstEvent.push(traceInfo.events[0].data);                                           // 122
    processedEvents.push(firstEvent);                                                                                 // 123
                                                                                                                      // 124
    for(var lc=1; lc < traceInfo.events.length - 1; lc += 2) {                                                        // 125
      var prevEventEnd = traceInfo.events[lc-1];                                                                      // 126
      var startEvent = traceInfo.events[lc];                                                                          // 127
      var endEvent = traceInfo.events[lc+1];                                                                          // 128
      var computeTime = startEvent.at - prevEventEnd.at;                                                              // 129
      if(computeTime > 0) processedEvents.push(['compute', computeTime]);                                             // 130
      if(!endEvent) {                                                                                                 // 131
        console.error('Kadira: no end event for type: ', startEvent.type);                                            // 132
        return null;                                                                                                  // 133
      } else if(endEvent.type != startEvent.type + 'end') {                                                           // 134
        console.error('Kadira: endevent type mismatch: ', startEvent.type, endEvent.type, JSON.stringify(traceInfo)); // 135
        return null;                                                                                                  // 136
      } else {                                                                                                        // 137
        var elapsedTimeForEvent = endEvent.at - startEvent.at                                                         // 138
        var currentEvent = [startEvent.type, elapsedTimeForEvent];                                                    // 139
        currentEvent.push(_.extend({}, startEvent.data, endEvent.data));                                              // 140
        processedEvents.push(currentEvent);                                                                           // 141
        metrics[startEvent.type] = metrics[startEvent.type] || 0;                                                     // 142
        metrics[startEvent.type] += elapsedTimeForEvent;                                                              // 143
        totalNonCompute += elapsedTimeForEvent;                                                                       // 144
      }                                                                                                               // 145
    }                                                                                                                 // 146
                                                                                                                      // 147
    computeTime = lastEvent.at - traceInfo.events[traceInfo.events.length - 2];                                       // 148
    if(computeTime > 0) processedEvents.push(['compute', computeTime]);                                               // 149
                                                                                                                      // 150
    var lastEventData = [lastEvent.type, 0];                                                                          // 151
    if(lastEvent.data) lastEventData.push(lastEvent.data);                                                            // 152
    processedEvents.push(lastEventData);                                                                              // 153
                                                                                                                      // 154
    metrics.compute = metrics.total - totalNonCompute;                                                                // 155
    traceInfo.metrics = metrics;                                                                                      // 156
    traceInfo.events = processedEvents;                                                                               // 157
    traceInfo.isEventsProcessed = true;                                                                               // 158
    return traceInfo;                                                                                                 // 159
  }                                                                                                                   // 160
};                                                                                                                    // 161
                                                                                                                      // 162
Kadira.tracer = new Tracer();                                                                                         // 163
                                                                                                                      // 164
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/meteorhacks:kadira/lib/tracer_store.js                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var logger = Npm.require('debug')('kadira:ts');                                                                       // 1
                                                                                                                      // 2
TracerStore = function TracerStore(options) {                                                                         // 3
  options = options || {};                                                                                            // 4
                                                                                                                      // 5
  this.maxTotalPoints = options.maxTotalPoints || 30;                                                                 // 6
  this.interval = options.interval || 1000 * 60;                                                                      // 7
  this.archiveEvery = options.archiveEvery || this.maxTotalPoints / 6;                                                // 8
                                                                                                                      // 9
  //store max total on the past 30 minutes (or past 30 items)                                                         // 10
  this.maxTotals = {};                                                                                                // 11
  //store the max trace of the current interval                                                                       // 12
  this.currentMaxTrace = {};                                                                                          // 13
  //archive for the traces                                                                                            // 14
  this.traceArchive = [];                                                                                             // 15
                                                                                                                      // 16
  this.processedCnt = {};                                                                                             // 17
                                                                                                                      // 18
  //group errors by messages between an interval                                                                      // 19
  this.errorMap = {};                                                                                                 // 20
};                                                                                                                    // 21
                                                                                                                      // 22
TracerStore.prototype.addTrace = function(trace) {                                                                    // 23
  var kind = [trace.type, trace.name].join('::');                                                                     // 24
  if(!this.currentMaxTrace[kind]) {                                                                                   // 25
    this.currentMaxTrace[kind] = EJSON.clone(trace);                                                                  // 26
  } else if(this.currentMaxTrace[kind].metrics.total < trace.metrics.total) {                                         // 27
    this.currentMaxTrace[kind] = EJSON.clone(trace);                                                                  // 28
  } else if(trace.errored) {                                                                                          // 29
    this._handleErrors(trace);                                                                                        // 30
  }                                                                                                                   // 31
};                                                                                                                    // 32
                                                                                                                      // 33
TracerStore.prototype.collectTraces = function() {                                                                    // 34
  var traces = this.traceArchive;                                                                                     // 35
  this.traceArchive = [];                                                                                             // 36
                                                                                                                      // 37
  // convert at(timestamp) into the actual serverTime                                                                 // 38
  traces.forEach(function(trace) {                                                                                    // 39
    trace.at = Kadira.syncedDate.syncTime(trace.at);                                                                  // 40
  });                                                                                                                 // 41
  return traces;                                                                                                      // 42
};                                                                                                                    // 43
                                                                                                                      // 44
TracerStore.prototype.start = function() {                                                                            // 45
  this._timeoutHandler = setInterval(this.processTraces.bind(this), this.interval);                                   // 46
};                                                                                                                    // 47
                                                                                                                      // 48
TracerStore.prototype.stop = function() {                                                                             // 49
  if(this._timeoutHandler) {                                                                                          // 50
    clearInterval(this._timeoutHandler);                                                                              // 51
  }                                                                                                                   // 52
};                                                                                                                    // 53
                                                                                                                      // 54
TracerStore.prototype._handleErrors = function(trace) {                                                               // 55
  // sending error requests as it is                                                                                  // 56
  var lastEvent = trace.events[trace.events.length -1];                                                               // 57
  if(lastEvent && lastEvent[2]) {                                                                                     // 58
    var error = lastEvent[2].error;                                                                                   // 59
                                                                                                                      // 60
    // grouping errors occured (reset after processTraces)                                                            // 61
    var errorKey = [trace.type, trace.name, error.message].join("::");                                                // 62
    if(!this.errorMap[errorKey]) {                                                                                    // 63
      var erroredTrace = EJSON.clone(trace);                                                                          // 64
      this.errorMap[errorKey] = erroredTrace;                                                                         // 65
                                                                                                                      // 66
      this.traceArchive.push(erroredTrace);                                                                           // 67
    }                                                                                                                 // 68
  } else {                                                                                                            // 69
    logger('last events is not an error: ', JSON.stringify(trace.events));                                            // 70
  }                                                                                                                   // 71
};                                                                                                                    // 72
                                                                                                                      // 73
TracerStore.prototype.processTraces = function() {                                                                    // 74
  var self = this;                                                                                                    // 75
  var kinds = _.union(                                                                                                // 76
    _.keys(this.maxTotals),                                                                                           // 77
    _.keys(this.currentMaxTrace)                                                                                      // 78
  );                                                                                                                  // 79
                                                                                                                      // 80
  kinds.forEach(function(kind) {                                                                                      // 81
    self.processedCnt[kind] = self.processedCnt[kind] || 0;                                                           // 82
    var currentMaxTrace = self.currentMaxTrace[kind];                                                                 // 83
    var currentMaxTotal = currentMaxTrace? currentMaxTrace.metrics.total : 0;                                         // 84
                                                                                                                      // 85
    self.maxTotals[kind] = self.maxTotals[kind] || [];                                                                // 86
    //add the current maxPoint                                                                                        // 87
    self.maxTotals[kind].push(currentMaxTotal);                                                                       // 88
    var exceedingPoints = self.maxTotals[kind].length - self.maxTotalPoints;                                          // 89
    if(exceedingPoints > 0) {                                                                                         // 90
      self.maxTotals[kind].splice(0, exceedingPoints);                                                                // 91
    }                                                                                                                 // 92
                                                                                                                      // 93
    var archiveDefault = (self.processedCnt[kind] % self.archiveEvery) == 0;                                          // 94
    self.processedCnt[kind]++;                                                                                        // 95
                                                                                                                      // 96
    var canArchive = archiveDefault                                                                                   // 97
      || self._isTraceOutlier(kind, currentMaxTrace);                                                                 // 98
                                                                                                                      // 99
    if(canArchive && currentMaxTrace) {                                                                               // 100
      self.traceArchive.push(currentMaxTrace);                                                                        // 101
    }                                                                                                                 // 102
                                                                                                                      // 103
    //reset currentMaxTrace                                                                                           // 104
    self.currentMaxTrace[kind] = null;                                                                                // 105
  });                                                                                                                 // 106
                                                                                                                      // 107
  //reset the errorMap                                                                                                // 108
  self.errorMap = {};                                                                                                 // 109
};                                                                                                                    // 110
                                                                                                                      // 111
TracerStore.prototype._isTraceOutlier = function(kind, trace) {                                                       // 112
  if(trace) {                                                                                                         // 113
    var dataSet = this.maxTotals[kind];                                                                               // 114
    return this._isOutlier(dataSet, trace.metrics.total, 3);                                                          // 115
  } else {                                                                                                            // 116
    return false;                                                                                                     // 117
  }                                                                                                                   // 118
};                                                                                                                    // 119
                                                                                                                      // 120
/*                                                                                                                    // 121
  Data point must exists in the dataSet                                                                               // 122
*/                                                                                                                    // 123
TracerStore.prototype._isOutlier = function(dataSet, dataPoint, maxMadZ) {                                            // 124
  var median = this._getMedian(dataSet);                                                                              // 125
  var mad = this._calculateMad(dataSet, median);                                                                      // 126
  var madZ = this._funcMedianDeviation(median)(dataPoint) / mad;                                                      // 127
                                                                                                                      // 128
  return madZ > maxMadZ;                                                                                              // 129
};                                                                                                                    // 130
                                                                                                                      // 131
TracerStore.prototype._getMedian = function(dataSet) {                                                                // 132
  var sortedDataSet = _.clone(dataSet).sort(function(a, b) {                                                          // 133
    return a-b;                                                                                                       // 134
  });                                                                                                                 // 135
  return this._pickQuartile(sortedDataSet, 2);                                                                        // 136
};                                                                                                                    // 137
                                                                                                                      // 138
TracerStore.prototype._pickQuartile = function(dataSet, num) {                                                        // 139
  var pos = ((dataSet.length + 1) * num) / 4;                                                                         // 140
  if(pos % 1 == 0) {                                                                                                  // 141
    return dataSet[pos -1];                                                                                           // 142
  } else {                                                                                                            // 143
    pos = pos - (pos % 1);                                                                                            // 144
    return (dataSet[pos -1] + dataSet[pos])/2                                                                         // 145
  }                                                                                                                   // 146
};                                                                                                                    // 147
                                                                                                                      // 148
TracerStore.prototype._calculateMad = function(dataSet, median) {                                                     // 149
  var medianDeviations = _.map(dataSet, this._funcMedianDeviation(median));                                           // 150
  var mad = this._getMedian(medianDeviations);                                                                        // 151
                                                                                                                      // 152
  return mad;                                                                                                         // 153
};                                                                                                                    // 154
                                                                                                                      // 155
TracerStore.prototype._funcMedianDeviation = function(median) {                                                       // 156
  return function(x) {                                                                                                // 157
    return Math.abs(median - x);                                                                                      // 158
  };                                                                                                                  // 159
};                                                                                                                    // 160
                                                                                                                      // 161
TracerStore.prototype._getMean = function(dataPoints) {                                                               // 162
  if(dataPoints.length > 0) {                                                                                         // 163
    var total = 0;                                                                                                    // 164
    dataPoints.forEach(function(point) {                                                                              // 165
      total += point;                                                                                                 // 166
    });                                                                                                               // 167
    return total/dataPoints.length;                                                                                   // 168
  } else {                                                                                                            // 169
    return 0;                                                                                                         // 170
  }                                                                                                                   // 171
};                                                                                                                    // 172
                                                                                                                      // 173
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/meteorhacks:kadira/lib/hijack/wrap_session.js                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
//only method, sub and unsub are valid messages                                                                       // 1
//so following fields would only required                                                                             // 2
var WAITON_MESSAGE_FIELDS = ['msg', 'id', 'method', 'name'];                                                          // 3
                                                                                                                      // 4
wrapSession = function(sessionProto) {                                                                                // 5
                                                                                                                      // 6
  //store the currently running DDP message per session                                                               // 7
  //we have to add this to the top of the waiting message                                                             // 8
  var currentlyProcessingDDPMessage = {};                                                                             // 9
                                                                                                                      // 10
  var originalProcessMessage = sessionProto.processMessage;                                                           // 11
  sessionProto.processMessage = function(msg) {                                                                       // 12
    if(Kadira.connected) {                                                                                            // 13
      //only add kadiraInfo if it is connected                                                                        // 14
      var kadiraInfo = {                                                                                              // 15
        session: this.id,                                                                                             // 16
        userId: this.userId                                                                                           // 17
      };                                                                                                              // 18
                                                                                                                      // 19
      if(msg.msg == 'method' || msg.msg == 'sub') {                                                                   // 20
        kadiraInfo.trace = Kadira.tracer.start(this, msg);                                                            // 21
                                                                                                                      // 22
        var waitOnMessages = this.inQueue.map(function(msg) {                                                         // 23
          return _.pick(msg, WAITON_MESSAGE_FIELDS);                                                                  // 24
        });                                                                                                           // 25
                                                                                                                      // 26
        //add currently processing ddp message if exists                                                              // 27
        if(this.workerRunning) {                                                                                      // 28
          waitOnMessages.unshift(_.pick(currentlyProcessingDDPMessage[this.id], WAITON_MESSAGE_FIELDS));              // 29
        }                                                                                                             // 30
                                                                                                                      // 31
        //use JSON stringify to save the CPU                                                                          // 32
        var startData = { userId: this.userId, params: JSON.stringify(msg.params) };                                  // 33
        Kadira.tracer.event(kadiraInfo.trace, 'start', startData);                                                    // 34
        var waitEventId = Kadira.tracer.event(kadiraInfo.trace, 'wait', {waitOn: waitOnMessages}, kadiraInfo);        // 35
        msg._waitEventId = waitEventId;                                                                               // 36
        msg.__kadiraInfo = kadiraInfo;                                                                                // 37
                                                                                                                      // 38
        if(msg.msg == 'sub') {                                                                                        // 39
          // start tracking inside processMessage allows us to indicate                                               // 40
          // wait time as well                                                                                        // 41
          Kadira.models.pubsub._trackSub(this, msg);                                                                  // 42
        }                                                                                                             // 43
      }                                                                                                               // 44
    }                                                                                                                 // 45
                                                                                                                      // 46
    return originalProcessMessage.call(this, msg);                                                                    // 47
  };                                                                                                                  // 48
                                                                                                                      // 49
  //adding the method context to the current fiber                                                                    // 50
  var originalMethodHandler = sessionProto.protocol_handlers.method;                                                  // 51
  sessionProto.protocol_handlers.method = function(msg, unblock) {                                                    // 52
    var self = this;                                                                                                  // 53
    currentlyProcessingDDPMessage[this.id] = msg;                                                                     // 54
    //add context                                                                                                     // 55
    var kadiraInfo = msg.__kadiraInfo;                                                                                // 56
    Kadira._setInfo(kadiraInfo);                                                                                      // 57
                                                                                                                      // 58
    Kadira.tracer.eventEnd(kadiraInfo.trace, msg._waitEventId);                                                       // 59
                                                                                                                      // 60
    return Kadira.env.kadiraInfo.withValue(kadiraInfo, function () {                                                  // 61
      return originalMethodHandler.call(self, msg, unblock);                                                          // 62
    });                                                                                                               // 63
  };                                                                                                                  // 64
                                                                                                                      // 65
  //to capture the currently processing message                                                                       // 66
  var orginalSubHandler = sessionProto.protocol_handlers.sub;                                                         // 67
  sessionProto.protocol_handlers.sub = function(msg, unblock) {                                                       // 68
    var self = this;                                                                                                  // 69
    currentlyProcessingDDPMessage[this.id] = msg;                                                                     // 70
                                                                                                                      // 71
    //add context                                                                                                     // 72
    var kadiraInfo = msg.__kadiraInfo;                                                                                // 73
    Kadira._setInfo(kadiraInfo);                                                                                      // 74
                                                                                                                      // 75
    Kadira.tracer.eventEnd(kadiraInfo.trace, msg._waitEventId);                                                       // 76
                                                                                                                      // 77
    return Kadira.env.kadiraInfo.withValue(kadiraInfo, function () {                                                  // 78
      return orginalSubHandler.call(self, msg, unblock);                                                              // 79
    });                                                                                                               // 80
  };                                                                                                                  // 81
                                                                                                                      // 82
  //to capture the currently processing message                                                                       // 83
  var orginalUnSubHandler = sessionProto.protocol_handlers.unsub;                                                     // 84
  sessionProto.protocol_handlers.unsub = function(msg, unblock) {                                                     // 85
    currentlyProcessingDDPMessage[this.id] = msg;                                                                     // 86
    return orginalUnSubHandler.call(this, msg, unblock);                                                              // 87
  };                                                                                                                  // 88
                                                                                                                      // 89
  //we need to clear currentlyProcessingDDPMessage just after the session destroyed                                   // 90
  //otherwise, it will leads to a potential memory leaks                                                              // 91
  var originalDestroy = sessionProto.destroy;                                                                         // 92
  sessionProto.destroy = function() {                                                                                 // 93
    delete currentlyProcessingDDPMessage[this.id];                                                                    // 94
    return originalDestroy.call(this);                                                                                // 95
  };                                                                                                                  // 96
                                                                                                                      // 97
  //track method ending (to get the result of error)                                                                  // 98
  var originalSend = sessionProto.send;                                                                               // 99
  sessionProto.send = function(msg) {                                                                                 // 100
    if(msg.msg == 'result') {                                                                                         // 101
      var kadiraInfo = Kadira._getInfo();                                                                             // 102
      if(msg.error) {                                                                                                 // 103
        var error = _.pick(msg.error, ['message', 'stack']);                                                          // 104
                                                                                                                      // 105
        // pick the error from the wrapped method handler                                                             // 106
        if(kadiraInfo && kadiraInfo.currentError) {                                                                   // 107
          // the error stack is wrapped so Meteor._debug can identify                                                 // 108
          // this as a method error.                                                                                  // 109
          error = {                                                                                                   // 110
            message: kadiraInfo.currentError.message,                                                                 // 111
            stack: kadiraInfo.currentError.stack.stack                                                                // 112
          };                                                                                                          // 113
        }                                                                                                             // 114
                                                                                                                      // 115
        Kadira.tracer.endLastEvent(kadiraInfo.trace);                                                                 // 116
        Kadira.tracer.event(kadiraInfo.trace, 'error', {error: error});                                               // 117
      } else {                                                                                                        // 118
        var isForced = Kadira.tracer.endLastEvent(kadiraInfo.trace);                                                  // 119
        if (isForced) {                                                                                               // 120
          console.warn('Kadira endevent forced complete', JSON.stringify(kadiraInfo.trace.events));                   // 121
        };                                                                                                            // 122
        Kadira.tracer.event(kadiraInfo.trace, 'complete');                                                            // 123
      }                                                                                                               // 124
                                                                                                                      // 125
      if(kadiraInfo) {                                                                                                // 126
        //processing the message                                                                                      // 127
        var trace = Kadira.tracer.buildTrace(kadiraInfo.trace);                                                       // 128
        Kadira.models.methods.processMethod(trace);                                                                   // 129
                                                                                                                      // 130
        // error may or may not exist and error tracking can be disabled                                              // 131
        if(error && Kadira.options.enableErrorTracking) {                                                             // 132
          Kadira.models.error.trackError(error, trace);                                                               // 133
        }                                                                                                             // 134
                                                                                                                      // 135
        //clean and make sure, fiber is clean                                                                         // 136
        //not sure we need to do this, but a preventive measure                                                       // 137
        Kadira._setInfo(null);                                                                                        // 138
      }                                                                                                               // 139
    }                                                                                                                 // 140
                                                                                                                      // 141
    return originalSend.call(this, msg);                                                                              // 142
  };                                                                                                                  // 143
                                                                                                                      // 144
  //for the pub/sub data-impact calculation                                                                           // 145
  ['sendAdded', 'sendChanged', 'sendRemoved'].forEach(function(funcName) {                                            // 146
    var originalFunc = sessionProto[funcName];                                                                        // 147
    sessionProto[funcName] = function(collectionName, id, fields) {                                                   // 148
      //fields is not relevant for `sendRemoved`, but does make any harm                                              // 149
      var eventName = funcName.substring(4).toLowerCase();                                                            // 150
      var subscription = Kadira.env.currentSub.get();                                                                 // 151
                                                                                                                      // 152
      if(subscription) {                                                                                              // 153
        var session = this;                                                                                           // 154
        Kadira.models.pubsub._trackNetworkImpact(session, subscription, eventName, collectionName, id, fields);       // 155
      }                                                                                                               // 156
                                                                                                                      // 157
      return originalFunc.call(this, collectionName, id, fields);                                                     // 158
    };                                                                                                                // 159
  });                                                                                                                 // 160
};                                                                                                                    // 161
                                                                                                                      // 162
// wrap existing method handlers for capturing errors                                                                 // 163
_.each(Meteor.default_server.method_handlers, function(handler, name) {                                               // 164
  wrapMethodHanderForErrors(name, handler, Meteor.default_server.method_handlers);                                    // 165
});                                                                                                                   // 166
                                                                                                                      // 167
// wrap future method handlers for capturing errors                                                                   // 168
var originalMeteorMethods = Meteor.methods;                                                                           // 169
Meteor.methods = function(methodMap) {                                                                                // 170
  _.each(methodMap, function(handler, name) {                                                                         // 171
    wrapMethodHanderForErrors(name, handler, methodMap);                                                              // 172
  });                                                                                                                 // 173
  originalMeteorMethods(methodMap);                                                                                   // 174
};                                                                                                                    // 175
                                                                                                                      // 176
                                                                                                                      // 177
function wrapMethodHanderForErrors(name, originalHandler, methodMap) {                                                // 178
  methodMap[name] = function() {                                                                                      // 179
    try{                                                                                                              // 180
      return originalHandler.apply(this, arguments);                                                                  // 181
    } catch(ex) {                                                                                                     // 182
                                                                                                                      // 183
      if(Kadira._getInfo()) {                                                                                         // 184
        // wrap error stack so Meteor._debug can identify and ignore it                                               // 185
        ex.stack = {stack: ex.stack, source: 'method'};                                                               // 186
        Kadira._getInfo().currentError = ex;                                                                          // 187
      }                                                                                                               // 188
      throw ex;                                                                                                       // 189
    }                                                                                                                 // 190
  }                                                                                                                   // 191
}                                                                                                                     // 192
                                                                                                                      // 193
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/meteorhacks:kadira/lib/hijack/wrap_subscription.js                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Fiber = Npm.require('fibers');                                                                                    // 1
                                                                                                                      // 2
wrapSubscription = function(subscriptionProto) {                                                                      // 3
  // If the ready event runs outside the Fiber, Kadira._getInfo() doesn't work.                                       // 4
  // we need some other way to store kadiraInfo so we can use it at ready hijack.                                     // 5
  var originalRunHandler = subscriptionProto._runHandler;                                                             // 6
  subscriptionProto._runHandler = function() {                                                                        // 7
    var kadiraInfo = Kadira._getInfo();                                                                               // 8
    if (kadiraInfo) {                                                                                                 // 9
      this.__kadiraInfo = kadiraInfo;                                                                                 // 10
    };                                                                                                                // 11
    originalRunHandler.call(this);                                                                                    // 12
  }                                                                                                                   // 13
                                                                                                                      // 14
  var originalReady = subscriptionProto.ready;                                                                        // 15
  subscriptionProto.ready = function() {                                                                              // 16
    // meteor has a field called `_ready` which tracks this                                                           // 17
    // but we need to make it future proof                                                                            // 18
    if(!this._apmReadyTracked) {                                                                                      // 19
      var kadiraInfo = Kadira._getInfo() || this.__kadiraInfo;                                                        // 20
      delete this.__kadiraInfo;                                                                                       // 21
      //sometime .ready can be called in the context of the method                                                    // 22
      //then we have some problems, that's why we are checking this                                                   // 23
      //eg:- Accounts.createUser                                                                                      // 24
      if(kadiraInfo && this._subscriptionId == kadiraInfo.trace.id) {                                                 // 25
        var isForced = Kadira.tracer.endLastEvent(kadiraInfo.trace);                                                  // 26
        if (isForced) {                                                                                               // 27
          console.warn('Kadira endevent forced complete', JSON.stringify(kadiraInfo.trace.events));                   // 28
        };                                                                                                            // 29
        Kadira.tracer.event(kadiraInfo.trace, 'complete');                                                            // 30
        var trace = Kadira.tracer.buildTrace(kadiraInfo.trace);                                                       // 31
      }                                                                                                               // 32
                                                                                                                      // 33
      Kadira.models.pubsub._trackReady(this._session, this, trace);                                                   // 34
      this._apmReadyTracked = true;                                                                                   // 35
    }                                                                                                                 // 36
                                                                                                                      // 37
    // we still pass the control to the original implementation                                                       // 38
    // since multiple ready calls are handled by itself                                                               // 39
    originalReady.call(this);                                                                                         // 40
  };                                                                                                                  // 41
                                                                                                                      // 42
  var originalError = subscriptionProto.error;                                                                        // 43
  subscriptionProto.error = function(err) {                                                                           // 44
    var kadiraInfo = Kadira._getInfo();                                                                               // 45
                                                                                                                      // 46
    if(kadiraInfo && this._subscriptionId == kadiraInfo.trace.id) {                                                   // 47
      Kadira.tracer.endLastEvent(kadiraInfo.trace);                                                                   // 48
                                                                                                                      // 49
      var errorForApm = _.pick(err, 'message', 'stack');                                                              // 50
      Kadira.tracer.event(kadiraInfo.trace, 'error', {error: errorForApm});                                           // 51
      var trace = Kadira.tracer.buildTrace(kadiraInfo.trace);                                                         // 52
    }                                                                                                                 // 53
                                                                                                                      // 54
    Kadira.models.pubsub._trackError(this._session, this, trace);                                                     // 55
                                                                                                                      // 56
    // error tracking can be disabled                                                                                 // 57
    if(Kadira.options.enableErrorTracking) {                                                                          // 58
      Kadira.models.error.trackError(err, trace);                                                                     // 59
    }                                                                                                                 // 60
                                                                                                                      // 61
    // wrap error stack so Meteor._debug can identify and ignore it                                                   // 62
    err.stack = {stack: err.stack, source: 'subscription'};                                                           // 63
    originalError.call(this, err);                                                                                    // 64
  };                                                                                                                  // 65
                                                                                                                      // 66
  var originalDeactivate = subscriptionProto._deactivate;                                                             // 67
  subscriptionProto._deactivate = function() {                                                                        // 68
    Kadira.models.pubsub._trackUnsub(this._session, this);                                                            // 69
    originalDeactivate.call(this);                                                                                    // 70
  };                                                                                                                  // 71
                                                                                                                      // 72
  //adding the currenSub env variable                                                                                 // 73
  ['added', 'changed', 'removed'].forEach(function(funcName) {                                                        // 74
    var originalFunc = subscriptionProto[funcName];                                                                   // 75
    subscriptionProto[funcName] = function(collectionName, id, fields) {                                              // 76
      var self = this;                                                                                                // 77
                                                                                                                      // 78
      //we need to run this code in a fiber and that's how we track                                                   // 79
      //subscription info. May be we can figure out, some other way to do this                                        // 80
      if(Fiber.current) {                                                                                             // 81
        doCall();                                                                                                     // 82
      } else {                                                                                                        // 83
        Fiber(doCall).run();                                                                                          // 84
      }                                                                                                               // 85
                                                                                                                      // 86
      function doCall() {                                                                                             // 87
        Kadira.env.currentSub.withValue(self, function() {                                                            // 88
          return originalFunc.call(self, collectionName, id, fields);                                                 // 89
        });                                                                                                           // 90
      }                                                                                                               // 91
    };                                                                                                                // 92
  });                                                                                                                 // 93
};                                                                                                                    // 94
                                                                                                                      // 95
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/meteorhacks:kadira/lib/hijack/session.js                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var logger = Npm.require('debug')('kadira:hijack:session');                                                           // 1
                                                                                                                      // 2
Kadira._startInstrumenting = function(callback) {                                                                     // 3
  //instrumenting session                                                                                             // 4
  var fakeSocket = {send: function() {}, close: function() {}, headers: []};                                          // 5
  var ddpConnectMessage = {msg: 'connect', version: 'pre1', support: ['pre1']};                                       // 6
  Meteor.default_server._handleConnect(fakeSocket, ddpConnectMessage);                                                // 7
                                                                                                                      // 8
  if(fakeSocket._meteorSession) { //for newer meteor versions                                                         // 9
    wrapSession(fakeSocket._meteorSession.constructor.prototype);                                                     // 10
                                                                                                                      // 11
    //instrumenting subscription                                                                                      // 12
    instrumentSubscription(fakeSocket._meteorSession);                                                                // 13
                                                                                                                      // 14
    if(Meteor.default_server._removeSession) {                                                                        // 15
      //0.8.x                                                                                                         // 16
      fakeSocket._meteorSession.close();                                                                              // 17
    } else if(Meteor.default_server._closeSession) {                                                                  // 18
      //0.7.x                                                                                                         // 19
      Meteor.default_server._closeSession(fakeSocket._meteorSession);                                                 // 20
    } else if(Meteor.default_server._destroySession) {                                                                // 21
      //0.6.6.x                                                                                                       // 22
      Meteor.default_server._destroySession(fakeSocket._meteorSession);                                               // 23
    }                                                                                                                 // 24
    callback();                                                                                                       // 25
  } else if(fakeSocket.meteor_session) { //support for 0.6.5.x                                                        // 26
    wrapSession(fakeSocket.meteor_session.constructor.prototype);                                                     // 27
                                                                                                                      // 28
    //instrumenting subscription                                                                                      // 29
    instrumentSubscription(fakeSocket.meteor_session);                                                                // 30
                                                                                                                      // 31
    fakeSocket.meteor_session.detach(fakeSocket);                                                                     // 32
    callback();                                                                                                       // 33
  } else {                                                                                                            // 34
    console.error('Kadira: session instrumenting failed');                                                            // 35
  }                                                                                                                   // 36
};                                                                                                                    // 37
                                                                                                                      // 38
function instrumentSubscription(session) {                                                                            // 39
  var subId = Random.id();                                                                                            // 40
  var publicationHandler = function() {this.ready()};                                                                 // 41
  var pubName = '__kadira_pub';                                                                                       // 42
                                                                                                                      // 43
  session._startSubscription(publicationHandler, subId, [], pubName);                                                 // 44
  var subscription = session._namedSubs[subId];                                                                       // 45
  wrapSubscription(subscription.constructor.prototype);                                                               // 46
                                                                                                                      // 47
  //cleaning up                                                                                                       // 48
  session._stopSubscription(subId);                                                                                   // 49
}                                                                                                                     // 50
                                                                                                                      // 51
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/meteorhacks:kadira/lib/hijack/db.js                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var mongoConnectionProto = getMongoConnectionProto();                                                                 // 1
                                                                                                                      // 2
//findOne is handled by find - so no need to track it                                                                 // 3
//upsert is handles by update                                                                                         // 4
['find', 'update', 'remove', 'insert', '_ensureIndex', '_dropIndex'].forEach(function(func) {                         // 5
  var originalFunc = mongoConnectionProto[func];                                                                      // 6
  mongoConnectionProto[func] = function(collName, selector, mod, options) {                                           // 7
    var payload = {                                                                                                   // 8
      coll: collName,                                                                                                 // 9
      func: func,                                                                                                     // 10
    };                                                                                                                // 11
                                                                                                                      // 12
    if(func == 'insert') {                                                                                            // 13
      //add nothing more to the payload                                                                               // 14
    } else if(func == '_ensureIndex' || func == '_dropIndex') {                                                       // 15
      //add index                                                                                                     // 16
      payload.index = JSON.stringify(selector);                                                                       // 17
    } else if(func == 'update' && options.upsert) {                                                                   // 18
      payload.func = 'upsert';                                                                                        // 19
      payload.selector = JSON.stringify(selector);                                                                    // 20
    } else {                                                                                                          // 21
      //all the other functions have selectors                                                                        // 22
      payload.selector = JSON.stringify(selector);                                                                    // 23
    }                                                                                                                 // 24
                                                                                                                      // 25
    var kadiraInfo = Kadira._getInfo();                                                                               // 26
    if(kadiraInfo) {                                                                                                  // 27
      var eventId = Kadira.tracer.event(kadiraInfo.trace, 'db', payload);                                             // 28
    }                                                                                                                 // 29
                                                                                                                      // 30
    //this cause V8 to avoid any performance optimizations, but this is must to use                                   // 31
    //otherwise, if the error adds try catch block our logs get messy and didn't work                                 // 32
    //see: issue #6                                                                                                   // 33
    try{                                                                                                              // 34
      var ret = originalFunc.apply(this, arguments);                                                                  // 35
      //handling functions which can be triggered with an asyncCallback                                               // 36
      var endOptions = {};                                                                                            // 37
                                                                                                                      // 38
      if(HaveAsyncCallback(arguments)) {                                                                              // 39
        endOptions.async = true;                                                                                      // 40
      }                                                                                                               // 41
                                                                                                                      // 42
      if(func == 'update') {                                                                                          // 43
        // upsert only returns an object when called `upsert` directly                                                // 44
        // otherwise it only act an update command                                                                    // 45
        if(options.upsert && typeof ret == 'object') {                                                                // 46
          endOptions.updatedDocs = ret.numberAffected;                                                                // 47
          endOptions.insertedId = ret.insertedId;                                                                     // 48
        } else {                                                                                                      // 49
          endOptions.updatedDocs = ret;                                                                               // 50
        }                                                                                                             // 51
      } else if(func == 'remove') {                                                                                   // 52
        endOptions.removedDocs = ret;                                                                                 // 53
      }                                                                                                               // 54
                                                                                                                      // 55
      if(eventId) {                                                                                                   // 56
        Kadira.tracer.eventEnd(kadiraInfo.trace, eventId, endOptions);                                                // 57
      }                                                                                                               // 58
                                                                                                                      // 59
      if(func == 'find' && !ret.constructor.prototype._ampOk) {                                                       // 60
        hijackCursor(ret.constructor.prototype);                                                                      // 61
      }                                                                                                               // 62
    } catch(ex) {                                                                                                     // 63
      if(eventId) {                                                                                                   // 64
        Kadira.tracer.eventEnd(kadiraInfo.trace, eventId, {err: ex.message});                                         // 65
      }                                                                                                               // 66
      throw ex;                                                                                                       // 67
    }                                                                                                                 // 68
                                                                                                                      // 69
    return ret;                                                                                                       // 70
  };                                                                                                                  // 71
});                                                                                                                   // 72
                                                                                                                      // 73
function hijackCursor(cursorProto) {                                                                                  // 74
  ['forEach', 'map', 'fetch', 'count', 'observeChanges', 'observe', 'rewind'].forEach(function(type) {                // 75
    var originalFunc = cursorProto[type];                                                                             // 76
    cursorProto[type] = function() {                                                                                  // 77
      var cursorDescription = this._cursorDescription;                                                                // 78
      var payload = {                                                                                                 // 79
        coll: cursorDescription.collectionName,                                                                       // 80
        selector: JSON.stringify(cursorDescription.selector),                                                         // 81
        func: type,                                                                                                   // 82
        cursor: true                                                                                                  // 83
      };                                                                                                              // 84
                                                                                                                      // 85
      if(cursorDescription.options) {                                                                                 // 86
        var options = _.pick(cursorDescription.options, ['fields', 'sort', 'limit']);                                 // 87
        for(var field in options) {                                                                                   // 88
          var value = options[field]                                                                                  // 89
          if(typeof value == 'object') {                                                                              // 90
            value = JSON.stringify(value);                                                                            // 91
          }                                                                                                           // 92
          payload[field] = value;                                                                                     // 93
        }                                                                                                             // 94
      };                                                                                                              // 95
                                                                                                                      // 96
      var kadiraInfo = Kadira._getInfo();                                                                             // 97
      if(kadiraInfo) {                                                                                                // 98
        var eventId = Kadira.tracer.event(kadiraInfo.trace, 'db', payload);                                           // 99
      }                                                                                                               // 100
                                                                                                                      // 101
      try{                                                                                                            // 102
        var ret = originalFunc.apply(this, arguments);                                                                // 103
                                                                                                                      // 104
        var endData = {};                                                                                             // 105
        if(type == 'observeChanges' || type == 'observe') {                                                           // 106
          var observerDriver;                                                                                         // 107
          endData.oplog = false;                                                                                      // 108
          if(ret._multiplexer) {                                                                                      // 109
            endData.noOfHandles = Object.keys(ret._multiplexer._handles).length;                                      // 110
            // track the cache handlers                                                                               // 111
            if(kadiraInfo && kadiraInfo.trace.type == 'sub') {                                                        // 112
              var isCachedHandle = endData.noOfHandles > 1;                                                           // 113
              Kadira.models.pubsub.incrementHandleCount(kadiraInfo.trace, isCachedHandle);                            // 114
            }                                                                                                         // 115
                                                                                                                      // 116
            // older meteor versions done not have an _multiplexer value                                              // 117
            observerDriver = ret._multiplexer._observeDriver;                                                         // 118
            if(observerDriver) {                                                                                      // 119
              observerDriver = ret._multiplexer._observeDriver;                                                       // 120
              var observerDriverClass = observerDriver.constructor;                                                   // 121
              var usesOplog = typeof observerDriverClass.cursorSupported == 'function';                               // 122
              endData.oplog = usesOplog;                                                                              // 123
              var size = 0;                                                                                           // 124
              ret._multiplexer._cache.docs.forEach(function() {size++});                                              // 125
              endData.noOfCachedDocs = size;                                                                          // 126
            }                                                                                                         // 127
          }                                                                                                           // 128
                                                                                                                      // 129
          if(!endData.oplog) {                                                                                        // 130
            // let's try to find the reason                                                                           // 131
            var reasonInfo = Kadira.checkWhyNoOplog(cursorDescription, observerDriver);                               // 132
            endData.noOplogCode = reasonInfo.code;                                                                    // 133
            endData.noOplogReason = reasonInfo.reason;                                                                // 134
            endData.noOplogSolution = reasonInfo.solution;                                                            // 135
          }                                                                                                           // 136
        } else if(type == 'fetch' || type == 'map'){                                                                  // 137
          //for other cursor operation                                                                                // 138
          endData.docsFetched = ret.length;                                                                           // 139
        }                                                                                                             // 140
                                                                                                                      // 141
        if(eventId) {                                                                                                 // 142
          Kadira.tracer.eventEnd(kadiraInfo.trace, eventId, endData);                                                 // 143
        }                                                                                                             // 144
        return ret;                                                                                                   // 145
      } catch(ex) {                                                                                                   // 146
        if(eventId) {                                                                                                 // 147
          Kadira.tracer.eventEnd(kadiraInfo.trace, eventId, {err: ex.message});                                       // 148
        }                                                                                                             // 149
        throw ex;                                                                                                     // 150
      }                                                                                                               // 151
    };                                                                                                                // 152
  });                                                                                                                 // 153
                                                                                                                      // 154
  cursorProto._ampOk = true;                                                                                          // 155
}                                                                                                                     // 156
                                                                                                                      // 157
function getMongoConnectionProto() {                                                                                  // 158
  var coll = new Meteor.Collection('__kadira_dummy_collection__');                                                    // 159
  //we need wait until db get connected with meteor, .findOne() does that                                             // 160
  coll.findOne();                                                                                                     // 161
  return MongoInternals.defaultRemoteCollectionDriver().mongo.constructor.prototype;                                  // 162
}                                                                                                                     // 163
                                                                                                                      // 164
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/meteorhacks:kadira/lib/hijack/http.js                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var originalCall = HTTP.call;                                                                                         // 1
                                                                                                                      // 2
HTTP.call = function(method, url) {                                                                                   // 3
  var kadiraInfo = Kadira._getInfo();                                                                                 // 4
  if(kadiraInfo) {                                                                                                    // 5
    var eventId = Kadira.tracer.event(kadiraInfo.trace, 'http', {method: method, url: url});                          // 6
  }                                                                                                                   // 7
                                                                                                                      // 8
  try {                                                                                                               // 9
    var response = originalCall.apply(this, arguments);                                                               // 10
                                                                                                                      // 11
    //if the user supplied an asynCallback, we don't have a response object and it handled asynchronously             // 12
    //we need to track it down to prevent issues like: #3                                                             // 13
    var endOptions = HaveAsyncCallback(arguments)? {async: true}: {statusCode: response.statusCode};                  // 14
    if(eventId) {                                                                                                     // 15
      Kadira.tracer.eventEnd(kadiraInfo.trace, eventId, endOptions);                                                  // 16
    }                                                                                                                 // 17
    return response;                                                                                                  // 18
  } catch(ex) {                                                                                                       // 19
    if(eventId) {                                                                                                     // 20
      Kadira.tracer.eventEnd(kadiraInfo.trace, eventId, {err: ex.message});                                           // 21
    }                                                                                                                 // 22
    throw ex;                                                                                                         // 23
  }                                                                                                                   // 24
};                                                                                                                    // 25
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/meteorhacks:kadira/lib/hijack/email.js                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var originalSend = Email.send;                                                                                        // 1
                                                                                                                      // 2
Email.send = function(options) {                                                                                      // 3
  var kadiraInfo = Kadira._getInfo();                                                                                 // 4
  if(kadiraInfo) {                                                                                                    // 5
    var eventId = Kadira.tracer.event(kadiraInfo.trace, 'email');                                                     // 6
  }                                                                                                                   // 7
  try {                                                                                                               // 8
    var ret = originalSend.call(this, options);                                                                       // 9
    if(eventId) {                                                                                                     // 10
      Kadira.tracer.eventEnd(kadiraInfo.trace, eventId);                                                              // 11
    }                                                                                                                 // 12
    return ret;                                                                                                       // 13
  } catch(ex) {                                                                                                       // 14
    if(eventId) {                                                                                                     // 15
      Kadira.tracer.eventEnd(kadiraInfo.trace, eventId, {err: ex.message});                                           // 16
    }                                                                                                                 // 17
    throw ex;                                                                                                         // 18
  }                                                                                                                   // 19
};                                                                                                                    // 20
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/meteorhacks:kadira/lib/hijack/async.js                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Fibers = Npm.require('fibers');                                                                                   // 1
                                                                                                                      // 2
var originalYield = Fibers.yield;                                                                                     // 3
Fibers.yield = function() {                                                                                           // 4
  var kadiraInfo = Kadira._getInfo();                                                                                 // 5
  if(kadiraInfo) {                                                                                                    // 6
    var eventId = Kadira.tracer.event(kadiraInfo.trace, 'async');;                                                    // 7
    if(eventId) {                                                                                                     // 8
      Fibers.current._apmEventId = eventId;                                                                           // 9
    }                                                                                                                 // 10
  }                                                                                                                   // 11
                                                                                                                      // 12
  originalYield();                                                                                                    // 13
};                                                                                                                    // 14
                                                                                                                      // 15
var originalRun = Fibers.prototype.run;                                                                               // 16
Fibers.prototype.run = function(val) {                                                                                // 17
  if(this._apmEventId) {                                                                                              // 18
    var kadiraInfo = Kadira._getInfo(this);                                                                           // 19
    Kadira.tracer.eventEnd(kadiraInfo.trace, this._apmEventId);                                                       // 20
    this._apmEventId = null;                                                                                          // 21
  }                                                                                                                   // 22
  originalRun.call(this, val);                                                                                        // 23
};                                                                                                                    // 24
                                                                                                                      // 25
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/meteorhacks:kadira/lib/hijack/error.js                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
process.on('uncaughtException', function (err) {                                                                      // 1
  // let the server crash normally if error tracking is disabled                                                      // 2
  if(!Kadira.options.enableErrorTracking) {                                                                           // 3
    throw err;                                                                                                        // 4
  }                                                                                                                   // 5
                                                                                                                      // 6
  // looking for already tracked errors and throw them immediately                                                    // 7
  // throw error immediately if kadira is not ready                                                                   // 8
  if(err._tracked || !Kadira.connected) {                                                                             // 9
    throw err;                                                                                                        // 10
  }                                                                                                                   // 11
                                                                                                                      // 12
  var trace = getTrace(err, 'server-crash', 'uncaughtException');                                                     // 13
  Kadira.models.error.trackError(err, trace);                                                                         // 14
  Kadira.sendPayload(function () {                                                                                    // 15
    clearTimeout(timer);                                                                                              // 16
    throwError(err);                                                                                                  // 17
  });                                                                                                                 // 18
                                                                                                                      // 19
  var timer = setTimeout(function () {                                                                                // 20
    throwError(err);                                                                                                  // 21
  }, 1000*10);                                                                                                        // 22
                                                                                                                      // 23
  function throwError(err) {                                                                                          // 24
    // sometimes error came back from a fiber.                                                                        // 25
    // But we don't fibers to track that error for us                                                                 // 26
    // That's why we throw the error on the nextTick                                                                  // 27
    process.nextTick(function() {                                                                                     // 28
      // we need to mark this error where we really need to throw                                                     // 29
      err._tracked = true;                                                                                            // 30
      throw err;                                                                                                      // 31
    });                                                                                                               // 32
  }                                                                                                                   // 33
});                                                                                                                   // 34
                                                                                                                      // 35
var originalMeteorDebug = Meteor._debug;                                                                              // 36
Meteor._debug = function (message, stack) {                                                                           // 37
  if(!Kadira.options.enableErrorTracking) {                                                                           // 38
    return originalMeteorDebug.call(this, message, stack);                                                            // 39
  }                                                                                                                   // 40
                                                                                                                      // 41
  // We've changed `stack` into an object at method and sub handlers so we can                                        // 42
  // ignore them here. These errors are already tracked so don't track again.                                         // 43
  if(stack && stack.stack) {                                                                                          // 44
    stack = stack.stack                                                                                               // 45
  } else {                                                                                                            // 46
    // only send to the server, if only connected to kadira                                                           // 47
    if(Kadira.connected) {                                                                                            // 48
      var error = new Error(message);                                                                                 // 49
      error.stack = stack;                                                                                            // 50
      var trace = getTrace(error, 'server-internal', 'Meteor._debug');                                                // 51
      Kadira.models.error.trackError(error, trace);                                                                   // 52
    }                                                                                                                 // 53
  }                                                                                                                   // 54
                                                                                                                      // 55
  return originalMeteorDebug.call(this, message, stack);                                                              // 56
}                                                                                                                     // 57
                                                                                                                      // 58
function getTrace(err, type, subType) {                                                                               // 59
  return {                                                                                                            // 60
    type: type,                                                                                                       // 61
    subType: subType,                                                                                                 // 62
    name: err.message,                                                                                                // 63
    errored: true,                                                                                                    // 64
    at: Kadira.syncedDate.getTime(),                                                                                  // 65
    events: [                                                                                                         // 66
      ['start', 0, {}],                                                                                               // 67
      ['error', 0, {error: {message: err.message, stack: err.stack}}]                                                 // 68
    ],                                                                                                                // 69
    metrics: {                                                                                                        // 70
      total: 0                                                                                                        // 71
    }                                                                                                                 // 72
  };                                                                                                                  // 73
}                                                                                                                     // 74
                                                                                                                      // 75
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/meteorhacks:kadira/lib/auto_connect.js                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
// AutoConnect using Environment Variables                                                                            // 1
if(process.env.KADIRA_APP_ID && process.env.KADIRA_APP_SECRET) {                                                      // 2
  Kadira.connect(                                                                                                     // 3
    process.env.KADIRA_APP_ID,                                                                                        // 4
    process.env.KADIRA_APP_SECRET                                                                                     // 5
  );                                                                                                                  // 6
                                                                                                                      // 7
  Kadira.connect = function() {                                                                                       // 8
    throw new Error('Kadira has been already connected using credentials from Environment Variables');                // 9
  };                                                                                                                  // 10
}                                                                                                                     // 11
                                                                                                                      // 12
// AutoConnect using Meteor.settings                                                                                  // 13
if(Meteor.settings.kadira) {                                                                                          // 14
  Kadira.connect(                                                                                                     // 15
    Meteor.settings.kadira.appId,                                                                                     // 16
    Meteor.settings.kadira.appSecret,                                                                                 // 17
    Meteor.settings.kadira.options || {}                                                                              // 18
  );                                                                                                                  // 19
                                                                                                                      // 20
  Kadira.connect = function() {                                                                                       // 21
    throw new Error('Kadira has been already connected using credentials from Meteor.settings');                      // 22
  };                                                                                                                  // 23
}                                                                                                                     // 24
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['meteorhacks:kadira'] = {
  Kadira: Kadira
};

})();

//# sourceMappingURL=meteorhacks:kadira.js.map
