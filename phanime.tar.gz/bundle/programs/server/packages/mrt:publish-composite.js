(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;

(function () {

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// packages/mrt:publish-composite/publish_composite.js                                    //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
Meteor.publishComposite = function(name, options) {                                       // 1
    return Meteor.publish(name, function() {                                              // 2
        var subscription = new Subscription(this),                                        // 3
            instanceOptions = options,                                                    // 4
            args = Array.prototype.slice.apply(arguments);                                // 5
                                                                                          // 6
        if (typeof instanceOptions === 'function') {                                      // 7
            instanceOptions = instanceOptions.apply(this, args);                          // 8
        }                                                                                 // 9
                                                                                          // 10
        var pub = new Publication(subscription, instanceOptions);                         // 11
        pub.publish();                                                                    // 12
                                                                                          // 13
        this.onStop(function() {                                                          // 14
            pub.unpublish();                                                              // 15
        });                                                                               // 16
                                                                                          // 17
        this.ready();                                                                     // 18
    });                                                                                   // 19
};                                                                                        // 20
                                                                                          // 21
                                                                                          // 22
var Subscription = function(meteorSub) {                                                  // 23
    this.meteorSub = meteorSub;                                                           // 24
    this.refCounter = new DocumentRefCounter({                                            // 25
        onChange: function(collectionName, doc, refCount) {                               // 26
            if (refCount <= 0) {                                                          // 27
                meteorSub.removed(collectionName, doc._id);                               // 28
            }                                                                             // 29
        }                                                                                 // 30
    });                                                                                   // 31
};                                                                                        // 32
                                                                                          // 33
Subscription.prototype.added = function(collectionName, doc) {                            // 34
    this.refCounter.increment(collectionName, doc);                                       // 35
    this.meteorSub.added(collectionName, doc._id, doc);                                   // 36
};                                                                                        // 37
                                                                                          // 38
Subscription.prototype.changed = function(collectionName, doc) {                          // 39
    this.meteorSub.changed(collectionName, doc._id, doc);                                 // 40
};                                                                                        // 41
                                                                                          // 42
Subscription.prototype.removed = function(collectionName, doc) {                          // 43
    this.refCounter.decrement(collectionName, doc);                                       // 44
};                                                                                        // 45
                                                                                          // 46
                                                                                          // 47
                                                                                          // 48
var Publication = function(subscription, options, args) {                                 // 49
    this.subscription = subscription;                                                     // 50
    this.options = options;                                                               // 51
    this.args = args || [];                                                               // 52
    this.children = options.children || [];                                               // 53
    this.childPublications = [];                                                          // 54
};                                                                                        // 55
                                                                                          // 56
Publication.prototype.publish = function() {                                              // 57
    this.cursor = this.options.find.apply(this.subscription.meteorSub, this.args);        // 58
                                                                                          // 59
    if (!this.cursor) { return; }                                                         // 60
                                                                                          // 61
    this.collectionName = this.cursor._getCollectionName();                               // 62
    var self = this;                                                                      // 63
                                                                                          // 64
    this.observeHandle = this.cursor.observe({                                            // 65
        added: function(doc) {                                                            // 66
            self.subscription.added(self.collectionName, doc);                            // 67
            self._publishChildrenOf(doc);                                                 // 68
        },                                                                                // 69
        changed: function(doc) {                                                          // 70
            self._unpublishChildrenOf(doc._id);                                           // 71
            self._publishChildrenOf(doc);                                                 // 72
            self.subscription.changed(self.collectionName, doc);                          // 73
        },                                                                                // 74
        removed: function(doc) {                                                          // 75
            self._unpublishChildrenOf(doc._id);                                           // 76
            self.subscription.removed(self.collectionName, doc);                          // 77
        }                                                                                 // 78
    });                                                                                   // 79
};                                                                                        // 80
                                                                                          // 81
Publication.prototype.unpublish = function() {                                            // 82
    if (this.observeHandle) {                                                             // 83
        this.observeHandle.stop();                                                        // 84
    }                                                                                     // 85
                                                                                          // 86
    this._removeAllCursorDocuments();                                                     // 87
    this._unpublishChildPublications();                                                   // 88
};                                                                                        // 89
                                                                                          // 90
Publication.prototype._publishChildrenOf = function(doc) {                                // 91
    this.childPublications[doc._id] = [];                                                 // 92
                                                                                          // 93
    _.each(this.children, function(options) {                                             // 94
        var pub = new Publication(this.subscription, options, [ doc ].concat(this.args)); // 95
        this.childPublications[doc._id].push(pub);                                        // 96
        pub.publish();                                                                    // 97
    }, this);                                                                             // 98
};                                                                                        // 99
                                                                                          // 100
Publication.prototype._unpublishChildrenOf = function(docId) {                            // 101
    if (this.childPublications[docId]) {                                                  // 102
        _.each(this.childPublications[docId], function(pub) {                             // 103
            pub.unpublish();                                                              // 104
        });                                                                               // 105
    }                                                                                     // 106
    delete this.childPublications[docId];                                                 // 107
};                                                                                        // 108
                                                                                          // 109
Publication.prototype._removeAllCursorDocuments = function() {                            // 110
    if (!this.cursor) { return; }                                                         // 111
                                                                                          // 112
    this.cursor.rewind();                                                                 // 113
    this.cursor.forEach(function(doc) {                                                   // 114
        this.subscription.removed(this.collectionName, doc);                              // 115
    }, this);                                                                             // 116
};                                                                                        // 117
                                                                                          // 118
Publication.prototype._unpublishChildPublications = function() {                          // 119
    for (var i in this.childPublications) {                                               // 120
        this._unpublishChildrenOf(i);                                                     // 121
        delete this.childPublications[i];                                                 // 122
    }                                                                                     // 123
};                                                                                        // 124
                                                                                          // 125
                                                                                          // 126
var DocumentRefCounter = function(observer) {                                             // 127
    this.heap = {};                                                                       // 128
    this.observer = observer;                                                             // 129
};                                                                                        // 130
                                                                                          // 131
DocumentRefCounter.prototype.increment = function(collectionName, doc) {                  // 132
    var key = collectionName + ":" + doc._id;                                             // 133
    if (!this.heap[key]) {                                                                // 134
        this.heap[key] = 0;                                                               // 135
    }                                                                                     // 136
    this.heap[key]++;                                                                     // 137
};                                                                                        // 138
                                                                                          // 139
DocumentRefCounter.prototype.decrement = function(collectionName, doc) {                  // 140
    var key = collectionName + ":" + doc._id;                                             // 141
    if (this.heap[key]) {                                                                 // 142
        this.heap[key]--;                                                                 // 143
                                                                                          // 144
        this.observer.onChange(collectionName, doc, this.heap[key]);                      // 145
    }                                                                                     // 146
};                                                                                        // 147
                                                                                          // 148
////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mrt:publish-composite'] = {};

})();

//# sourceMappingURL=mrt:publish-composite.js.map
