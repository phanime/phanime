(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;

(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/reywood:publish-composite/publish_composite.js                                                          //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
Meteor.publishComposite = function(name, options) {                                                                 // 1
    return Meteor.publish(name, function() {                                                                        // 2
        var subscription = new Subscription(this),                                                                  // 3
            instanceOptions = options,                                                                              // 4
            args = Array.prototype.slice.apply(arguments);                                                          // 5
                                                                                                                    // 6
        if (typeof instanceOptions === "function") {                                                                // 7
            instanceOptions = instanceOptions.apply(this, args);                                                    // 8
        }                                                                                                           // 9
                                                                                                                    // 10
        var pub = new Publication(subscription, instanceOptions);                                                   // 11
        pub.publish();                                                                                              // 12
                                                                                                                    // 13
        this.onStop(function() {                                                                                    // 14
            pub.unpublish();                                                                                        // 15
        });                                                                                                         // 16
                                                                                                                    // 17
        this.ready();                                                                                               // 18
    });                                                                                                             // 19
};                                                                                                                  // 20
                                                                                                                    // 21
                                                                                                                    // 22
var Subscription = function(meteorSub) {                                                                            // 23
    var self = this;                                                                                                // 24
    this.meteorSub = meteorSub;                                                                                     // 25
    this.docHash = {};                                                                                              // 26
    this.refCounter = new DocumentRefCounter({                                                                      // 27
        onChange: function(collectionName, docId, refCount) {                                                       // 28
            debugLog("Subscription.refCounter.onChange", collectionName + ":" + docId.valueOf() + " " + refCount);  // 29
            if (refCount <= 0) {                                                                                    // 30
                meteorSub.removed(collectionName, docId);                                                           // 31
                self._removeDocHash(docId);                                                                         // 32
            }                                                                                                       // 33
        }                                                                                                           // 34
    });                                                                                                             // 35
};                                                                                                                  // 36
                                                                                                                    // 37
Subscription.prototype.added = function(collectionName, doc) {                                                      // 38
    this.refCounter.increment(collectionName, doc._id);                                                             // 39
                                                                                                                    // 40
    if (this._hasDocChanged(doc)) {                                                                                 // 41
        debugLog("Subscription.added", collectionName + ":" + doc._id);                                             // 42
        this.meteorSub.added(collectionName, doc._id, doc);                                                         // 43
        this._addDocHash(doc);                                                                                      // 44
    }                                                                                                               // 45
};                                                                                                                  // 46
                                                                                                                    // 47
Subscription.prototype.changed = function(collectionName, doc) {                                                    // 48
    if (this._hasDocChanged(doc)) {                                                                                 // 49
        debugLog("Subscription.changed", collectionName + ":" + doc._id);                                           // 50
        this.meteorSub.changed(collectionName, doc._id, doc);                                                       // 51
        this._addDocHash(doc);                                                                                      // 52
    }                                                                                                               // 53
};                                                                                                                  // 54
                                                                                                                    // 55
Subscription.prototype.removed = function(collectionName, docId) {                                                  // 56
    debugLog("Subscription.removed", collectionName + ":" + docId.valueOf());                                       // 57
    this.refCounter.decrement(collectionName, docId);                                                               // 58
};                                                                                                                  // 59
                                                                                                                    // 60
Subscription.prototype._addDocHash = function(doc) {                                                                // 61
    this.docHash[doc._id.valueOf()] = doc;                                                                          // 62
};                                                                                                                  // 63
                                                                                                                    // 64
Subscription.prototype._hasDocChanged = function(doc) {                                                             // 65
    var existingDoc = this.docHash[doc._id.valueOf()];                                                              // 66
                                                                                                                    // 67
    if (!existingDoc) { return true; }                                                                              // 68
                                                                                                                    // 69
    return !_.isEqual(doc, existingDoc);                                                                            // 70
};                                                                                                                  // 71
                                                                                                                    // 72
Subscription.prototype._removeDocHash = function(docId) {                                                           // 73
    delete this.docHash[docId.valueOf()];                                                                           // 74
};                                                                                                                  // 75
                                                                                                                    // 76
                                                                                                                    // 77
                                                                                                                    // 78
var Publication = function(subscription, options, args) {                                                           // 79
    this.subscription = subscription;                                                                               // 80
    this.options = options;                                                                                         // 81
    this.args = args || [];                                                                                         // 82
    this.children = options.children || [];                                                                         // 83
    this.childPublications = [];                                                                                    // 84
    this.collectionName = options.collectionName;                                                                   // 85
};                                                                                                                  // 86
                                                                                                                    // 87
Publication.prototype.publish = function() {                                                                        // 88
    this.cursor = this._getCursor();                                                                                // 89
                                                                                                                    // 90
    if (!this.cursor) { return; }                                                                                   // 91
                                                                                                                    // 92
    var collectionName = this._getCollectionName();                                                                 // 93
    var self = this;                                                                                                // 94
                                                                                                                    // 95
    this.observeHandle = this.cursor.observe({                                                                      // 96
        added: function(doc) {                                                                                      // 97
            var alreadyPublished = !!self.childPublications[doc._id];                                               // 98
                                                                                                                    // 99
            if (alreadyPublished) {                                                                                 // 100
                debugLog("Publication.observeHandle.added", collectionName + ":" + doc._id + " already published"); // 101
                self.subscription.changed(collectionName, doc);                                                     // 102
                self._republishChildrenOf(doc);                                                                     // 103
            } else {                                                                                                // 104
                self.subscription.added(collectionName, doc);                                                       // 105
                self._publishChildrenOf(doc);                                                                       // 106
            }                                                                                                       // 107
        },                                                                                                          // 108
        changed: function(doc) {                                                                                    // 109
            debugLog("Publication.observeHandle.changed", collectionName + ":" + doc._id);                          // 110
            self.subscription.changed(collectionName, doc);                                                         // 111
            self._republishChildrenOf(doc);                                                                         // 112
        },                                                                                                          // 113
        removed: function(doc) {                                                                                    // 114
            debugLog("Publication.observeHandle.removed", collectionName + ":" + doc._id);                          // 115
            self._unpublishChildrenOf(doc._id);                                                                     // 116
            self.subscription.removed(collectionName, doc._id);                                                     // 117
        }                                                                                                           // 118
    });                                                                                                             // 119
};                                                                                                                  // 120
                                                                                                                    // 121
Publication.prototype.unpublish = function() {                                                                      // 122
    if (this.observeHandle) {                                                                                       // 123
        this.observeHandle.stop();                                                                                  // 124
    }                                                                                                               // 125
                                                                                                                    // 126
    this._removeAllCursorDocuments();                                                                               // 127
    this._unpublishChildPublications();                                                                             // 128
};                                                                                                                  // 129
                                                                                                                    // 130
Publication.prototype.republish = function() {                                                                      // 131
    var self = this;                                                                                                // 132
    var collectionName = this._getCollectionName();                                                                 // 133
                                                                                                                    // 134
    var oldPublishedIds;                                                                                            // 135
    if (this.cursor) {                                                                                              // 136
        this.cursor.rewind();                                                                                       // 137
        oldPublishedIds = this.cursor.map(function(doc) { return doc._id; });                                       // 138
    } else {                                                                                                        // 139
        oldPublishedIds = [];                                                                                       // 140
    }                                                                                                               // 141
                                                                                                                    // 142
    debugLog("Publication.republish", "stop observing old cursor");                                                 // 143
    if (this.observeHandle) {                                                                                       // 144
        this.observeHandle.stop();                                                                                  // 145
        delete this.observeHandle;                                                                                  // 146
    }                                                                                                               // 147
                                                                                                                    // 148
    debugLog("Publication.republish", "run .publish again");                                                        // 149
    this.publish();                                                                                                 // 150
                                                                                                                    // 151
    var newPublishedIds;                                                                                            // 152
    if (this.cursor) {                                                                                              // 153
        this.cursor.rewind();                                                                                       // 154
        newPublishedIds = this.cursor.map(function(doc) { return doc._id.valueOf(); });                             // 155
    } else {                                                                                                        // 156
        newPublishedIds = [];                                                                                       // 157
    }                                                                                                               // 158
                                                                                                                    // 159
    var docsToRemove = _.filter(oldPublishedIds, function(oldId) {                                                  // 160
        oldId = oldId.valueOf();                                                                                    // 161
        return !_.any(newPublishedIds, function(newId) { return newId === oldId; });                                // 162
    });                                                                                                             // 163
                                                                                                                    // 164
    debugLog("Publication.republish", "unpublish docs from old cursor, " + JSON.stringify(docsToRemove));           // 165
    _.each(docsToRemove, function(docId) {                                                                          // 166
        self._unpublishChildrenOf(docId);                                                                           // 167
        self.subscription.removed(collectionName, docId);                                                           // 168
    });                                                                                                             // 169
};                                                                                                                  // 170
                                                                                                                    // 171
Publication.prototype._getCursor = function() {                                                                     // 172
    return this.options.find.apply(this.subscription.meteorSub, this.args);                                         // 173
};                                                                                                                  // 174
                                                                                                                    // 175
Publication.prototype._getCollectionName = function() {                                                             // 176
    return this.collectionName || (this.cursor && this.cursor._getCollectionName());                                // 177
};                                                                                                                  // 178
                                                                                                                    // 179
Publication.prototype._publishChildrenOf = function(doc) {                                                          // 180
    this.childPublications[doc._id] = [];                                                                           // 181
                                                                                                                    // 182
    _.each(this.children, function(options) {                                                                       // 183
        var pub = new Publication(this.subscription, options, [ doc ].concat(this.args));                           // 184
        this.childPublications[doc._id].push(pub);                                                                  // 185
        pub.publish();                                                                                              // 186
    }, this);                                                                                                       // 187
};                                                                                                                  // 188
                                                                                                                    // 189
Publication.prototype._republishChildrenOf = function(doc) {                                                        // 190
    if (this.childPublications[doc._id]) {                                                                          // 191
        _.each(this.childPublications[doc._id], function(pub) {                                                     // 192
            pub.args[0] = doc;                                                                                      // 193
            pub.republish();                                                                                        // 194
        });                                                                                                         // 195
    }                                                                                                               // 196
};                                                                                                                  // 197
                                                                                                                    // 198
Publication.prototype._unpublishChildrenOf = function(docId) {                                                      // 199
    docId = docId.valueOf();                                                                                        // 200
                                                                                                                    // 201
    debugLog("Publication._unpublishChildrenOf", "unpublishing children of " + this._getCollectionName() + ":" + docId);
    if (this.childPublications[docId]) {                                                                            // 203
        _.each(this.childPublications[docId], function(pub) {                                                       // 204
            pub.unpublish();                                                                                        // 205
        });                                                                                                         // 206
    }                                                                                                               // 207
    delete this.childPublications[docId];                                                                           // 208
};                                                                                                                  // 209
                                                                                                                    // 210
Publication.prototype._removeAllCursorDocuments = function() {                                                      // 211
    if (!this.cursor) { return; }                                                                                   // 212
                                                                                                                    // 213
    var collectionName = this._getCollectionName();                                                                 // 214
                                                                                                                    // 215
    this.cursor.rewind();                                                                                           // 216
    this.cursor.forEach(function(doc) {                                                                             // 217
        this.subscription.removed(collectionName, doc._id);                                                         // 218
    }, this);                                                                                                       // 219
};                                                                                                                  // 220
                                                                                                                    // 221
Publication.prototype._unpublishChildPublications = function() {                                                    // 222
    for (var docId in this.childPublications) {                                                                     // 223
        this._unpublishChildrenOf(docId);                                                                           // 224
        delete this.childPublications[docId];                                                                       // 225
    }                                                                                                               // 226
};                                                                                                                  // 227
                                                                                                                    // 228
                                                                                                                    // 229
var DocumentRefCounter = function(observer) {                                                                       // 230
    this.heap = {};                                                                                                 // 231
    this.observer = observer;                                                                                       // 232
};                                                                                                                  // 233
                                                                                                                    // 234
DocumentRefCounter.prototype.increment = function(collectionName, docId) {                                          // 235
    var key = collectionName + ":" + docId.valueOf();                                                               // 236
    if (!this.heap[key]) {                                                                                          // 237
        this.heap[key] = 0;                                                                                         // 238
    }                                                                                                               // 239
    this.heap[key]++;                                                                                               // 240
};                                                                                                                  // 241
                                                                                                                    // 242
DocumentRefCounter.prototype.decrement = function(collectionName, docId) {                                          // 243
    var key = collectionName + ":" + docId.valueOf();                                                               // 244
    if (this.heap[key]) {                                                                                           // 245
        this.heap[key]--;                                                                                           // 246
                                                                                                                    // 247
        this.observer.onChange(collectionName, docId, this.heap[key]);                                              // 248
    }                                                                                                               // 249
};                                                                                                                  // 250
                                                                                                                    // 251
                                                                                                                    // 252
var enableDebugLogging = false;                                                                                     // 253
var debugLog = enableDebugLogging ? function(source, message) {                                                     // 254
    while (source.length < 35) { source += " "; }                                                                   // 255
    console.log("[" + source + "] " + message);                                                                     // 256
} : function() { };                                                                                                 // 257
                                                                                                                    // 258
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['reywood:publish-composite'] = {};

})();

//# sourceMappingURL=reywood:publish-composite.js.map
