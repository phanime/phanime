(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Deps = Package.deps.Deps;

/* Package-scope variables */
var T9n, __coffeescriptShare;

(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/mrt:accounts-t9n/t9n.coffee.js                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var Handlebars;     

if (Meteor.isClient) {
  if (Package.ui) {
    Handlebars = Package.ui.Handlebars;
  }
  Handlebars.registerHelper('t9n', function(x) {
    return T9n.get(x);
  });
}

T9n = (function() {
  function T9n() {}

  T9n.maps = {};

  T9n.defaultLanguage = 'en';

  T9n.language = '';

  T9n.dep = new Deps.Dependency();

  T9n.depLanguage = new Deps.Dependency();

  T9n.missingPrefix = ">";

  T9n.missingPostfix = "<";

  T9n.map = function(language, map) {
    if (!this.maps[language]) {
      this.maps[language] = {};
    }
    this.registerMap(language, '', false, map);
    return this.dep.changed();
  };

  T9n.get = function(label, markIfMissing) {
    var _ref, _ref1;
    if (markIfMissing == null) {
      markIfMissing = true;
    }
    this.dep.depend();
    this.depLanguage.depend();
    if (typeof label !== 'string') {
      return '';
    }
    return ((_ref = this.maps[this.language]) != null ? _ref[label] : void 0) || ((_ref1 = this.maps[this.defaultLanguage]) != null ? _ref1[label] : void 0) || (markIfMissing ? this.missingPrefix + label + this.missingPostfix : label);
  };

  T9n.registerMap = function(language, prefix, dot, map) {
    var key, value, _results;
    if (typeof map === 'string') {
      return this.maps[language][prefix] = map;
    } else if (typeof map === 'object') {
      if (dot) {
        prefix = prefix + '.';
      }
      _results = [];
      for (key in map) {
        value = map[key];
        _results.push(this.registerMap(language, prefix + key, true, value));
      }
      return _results;
    }
  };

  T9n.getLanguage = function() {
    this.depLanguage.depend();
    return this.language;
  };

  T9n.getLanguages = function() {
    this.dep.depend();
    return Object.keys(this.maps).sort();
  };

  T9n.setLanguage = function(language) {
    if (!this.maps[language] || this.language === language) {
      return;
    }
    this.language = language;
    return this.depLanguage.changed();
  };

  return T9n;

})();

this.T9n = T9n;

this.t9n = function(x) {
  return T9n.get(x);
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/mrt:accounts-t9n/t9n/ar.coffee.js                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var ar;

ar = {
  and: "و",
  clickAgree: "بفتح حسابك انت توافق على",
  configure: "تعديل",
  createAccount: "افتح حساب جديد",
  dontHaveAnAccount: "ليس عندك حساب؟",
  email: "البريد الالكترونى",
  emailAddress: "البريد الالكترونى",
  emailResetLink: "اعادة تعيين البريد الالكترونى",
  forgotPassword: "نسيت كلمة السر؟",
  ifYouAlreadyHaveAnAccount: "اذا كان عندك حساب",
  optional: "اختيارى",
  OR: "او",
  password: "كلمة السر",
  privacyPolicy: "سياسة الخصوصية",
  resetYourPassword: "اعادة تعيين كلمة السر",
  sign: "تسجيل",
  signIn: "تسجيل الدخول",
  signin: "تسجيل الدخول",
  signOut: "تسجيل الخروج",
  signUp: "افتح حساب جديد",
  signupCode: "رمز التسجيل",
  signUpWithYourEmailAddress: "سجل ببريدك الالكترونى",
  terms: "شروط الاستخدام",
  updateYourPassword: "جدد كلمة السر",
  username: "اسم المستخدم",
  usernameOrEmail: "اسم المستخدم او البريد الالكترونى",
  "with": "مع",
  error: {
    accounts: {
      "User not found": "اسم المستخدم غير موجود",
      "Match failed": "المطابقة فشلت"
    }
  },
  error: {
    emailRequired: "البريد الالكترونى مطلوب",
    minChar: "سبعة حروف هو الحد الادنى لكلمة السر",
    pwOneDigit: "كلمة السر يجب ان تحتوى على رقم واحد على الاقل",
    pwOneLetter: "كلمة السر تحتاج الى حرف اخر",
    signInRequired: "عليك بتسجبل الدخول لفعل ذلك",
    signupCodeIncorrect: "رمز التسجيل غير صحيح",
    signupCodeRequired: "رمز التسجيل مطلوب",
    usernameIsEmail: "اسم المستخدم لا يمكن ان يكون بريد الكترونى",
    usernameRequired: "اسم المستخدم مطلوب"
  }
};

T9n.map("ar", ar);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/mrt:accounts-t9n/t9n/cs.coffee.js                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var cs;

cs = {
  error: {
    accounts: {
      "Email already exists.": "Email již existuje.",
      "Email doesn't match the criteria.": "Email nesplňuje požadavky.",
      "User validation failed": "Validace uživatele selhala",
      "Username already exists.": "Uživatelské jméno již existuje.",
      "You've been logged out by the server. Please log in again.": "Byl jste odhlášen. Prosím přihlašte se znovu.",
      "Your session has expired. Please log in again.": "Vaše připojení vypršelo. Prosím přihlašte se znovu.",
      "Incorrect password": "Chybné heslo",
      "Must be logged in": "Uživatel musí být přihlášen",
      "Need to set a username or email": "Je třeba zadat uživatelské jméno nebo email",
      "Signups forbidden": "Registrace je zakázaná",
      "Token expired": "Token vypršel",
      "Token has invalid email address": "Token má neplatnou emailovou adresu",
      "User has no password set": "Uživatel nemá nastavené heslo",
      "User not found": "Uživatel nenalezen",
      "Verify email link expired": "Odkaz pro ověření emailu vypršel",
      "Verify email link is for unknown address": "Odkaz pro ověření emailu má neznámou adresu"
    }
  }
};

T9n.map("cs", cs);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/mrt:accounts-t9n/t9n/de.coffee.js                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var de;

de = {
  and: "und",
  clickAgree: "Durch die Registrierung akzeptieren Sie unsere",
  configure: "Konfigurieren",
  createAccount: "Konto erzeugen",
  dontHaveAnAccount: "Noch kein Konto?",
  email: "E-Mail",
  emailAddress: "E-Mail Adresse",
  emailResetLink: "Senden",
  forgotPassword: "Passwort vergessen?",
  ifYouAlreadyHaveAnAccount: "Falls Sie ein Konto haben, bitte hier",
  optional: "Optional",
  OR: "ODER",
  password: "Passwort",
  privacyPolicy: "Datenschutzerklärung",
  resetYourPassword: "Passwort zurücksetzen",
  sign: "Anmelden",
  signIn: "Anmelden",
  signin: "anmelden",
  signOut: "Abmelden",
  signUp: "Registrieren",
  signupCode: "Registrierungscode",
  signUpWithYourEmailAddress: "Mit E-Mail registrieren",
  terms: "Geschäftsbedingungen",
  updateYourPassword: "Passwort aktualisieren",
  username: "Benutzername",
  usernameOrEmail: "Benutzername oder E-Mail",
  "with": "mit",
  error: {
    accounts: {
      "Email already exists.": "Die Email gibt es schon.",
      "Email doesn't match the criteria.": "Emails stimmt nicht mit den Kriterien überein.",
      "User validation failed": "Die Benutzerdaten scheinen nicht korrekt",
      "Username already exists.": "Den Benutzer gibt es schon.",
      "You've been logged out by the server. Please log in again.": "Der Server hat Dich ausgeloggt. Bitte melde Dich erneut an.",
      "Your session has expired. Please log in again.": "Deine Sitzung ist abgelaufen. Bitte melde Dich erneut an.",
      "Incorrect password": "Falschen Passwort",
      "Must be logged in": "Da muss man sich aber erst anmelden",
      "Need to set a username or email": "Benutzername oder Email sollte man schon angeben",
      "Signups forbidden": "Anmeldungen sind verboten",
      "Token expired": "Das Token ist abgelaufen",
      "Token has invalid email address": "Für des Token stimmt die Email-Adresse nicht",
      "User has no password set": "Kein Passwort für den Benutzer angegeben",
      "User not found": "Benutzer nicht gefunden",
      "Verify email link expired": "Token zur Verifizierung der Email ist abgelaufen",
      "Verify email link is for unknown address": "Token zur Verifizierung der Email ist für eine unbekannte Adresse"
    }
  },
  error: {
    emailRequired: "E-Mail benötigt.",
    minChar: "Passwort muss mindesten 7 Zeichen lang sein.",
    pwOneDigit: "Passwort muss mindestens eine Ziffer enthalten.",
    pwOneLetter: "Passwort muss mindestens einen Buchstaben enthalten.",
    signInRequired: "Sie müssen sich anmelden.",
    signupCodeIncorrect: "Registrierungscode ungültig.",
    signupCodeRequired: "Registrierungscode benötigt.",
    usernameIsEmail: "Benutzername kann nicht eine E-Mail.",
    usernameRequired: "Benutzername benötigt."
  }
};

T9n.map("de", de);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/mrt:accounts-t9n/t9n/en.coffee.js                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var en;

en = {
  add: "add",
  and: "and",
  back: "back",
  clickAgree: "By clicking Register, you agree to our",
  configure: "Configure",
  createAccount: "Create an Account",
  dontHaveAnAccount: "Don't have an account?",
  email: "Email",
  emailAddress: "Email Address",
  emailResetLink: "Email Reset Link",
  emailSent: "Email Sent!",
  forgotPassword: "Forgot your password?",
  ifYouAlreadyHaveAnAccount: "If you already have an account",
  optional: "Optional",
  OR: "OR",
  password: "Password",
  privacyPolicy: "Privacy Policy",
  remove: "remove",
  resetYourPassword: "Reset your password",
  sign: "Sign",
  signIn: "Sign In",
  signin: "sign in",
  signOut: "Sign Out",
  signUp: "Register",
  signupCode: "Registration Code",
  signUpWithYourEmailAddress: "Register with your email address",
  terms: "Terms of Use",
  updateYourPassword: "Update your password",
  username: "Username",
  usernameOrEmail: "Username or email",
  "with": "with",
  error: {
    accounts: {
      "Email already exists.": "Email already exists.",
      "Email doesn't match the criteria.": "Email doesn't match the criteria.",
      "Invalid login token": "Invalid login token",
      "Login forbidden": "Login forbidden",
      "Service unknown": "Service unknown",
      "Unrecognized options for login request": "Unrecognized options for login request",
      "User validation failed": "User validation failed",
      "Username already exists.": "Username already exists.",
      "You are not logged in.": "You are not logged in.",
      "You've been logged out by the server. Please log in again.": "You've been logged out by the server. Please log in again.",
      "Your session has expired. Please log in again.": "Your session has expired. Please log in again.",
      "No matching login attempt found": "No matching login attempt found",
      "Password is old. Please reset your password.": "Password is old. Please reset your password.",
      "Incorrect password": "Incorrect password",
      "Invalid email": "Invalid email",
      "Must be logged in": "Must be logged in",
      "Need to set a username or email": "Need to set a username or email",
      "old password format": "old password format",
      "Signups forbidden": "Signups forbidden",
      "Token expired": "Token expired",
      "Token has invalid email address": "Token has invalid email address",
      "User has no password set": "User has no password set",
      "User not found": "User not found",
      "Verify email link expired": "Verify email link expired",
      "Verify email link is for unknown address": "Verify email link is for unknown address",
      "Match failed": "Match failed"
    }
  },
  error: {
    emailRequired: "Email is required.",
    minChar: "7 character minimum password.",
    pwOneDigit: "Password must have at least one digit.",
    pwOneLetter: "Password requires 1 letter.",
    signInRequired: "You must be signed in to do that.",
    signupCodeIncorrect: "Registration code is incorrect.",
    signupCodeRequired: "Registration code is required.",
    usernameIsEmail: "Username cannot be an email address.",
    usernameRequired: "Username is required."
  }
};

T9n.map("en", en);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/mrt:accounts-t9n/t9n/es.coffee.js                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var es;

es = {
  and: "y",
  clickAgree: "Si haces clic en Sucribir estas de acuerdo con la",
  configure: "Disposición",
  createAccount: "Crear cuenta",
  dontHaveAnAccount: "No tenés una cuenta?",
  email: "Email",
  emailAddress: "Dirección de Email",
  emailResetLink: "Reiniciar Email",
  forgotPassword: "Contraseña olvidada?",
  ifYouAlreadyHaveAnAccount: "Si ya tenés una cuenta",
  optional: "Opcional",
  OR: "O",
  password: "Contraseña",
  privacyPolicy: "Póliza de Privacidad",
  resetYourPassword: "Resetear tu contraseña",
  sign: "Ingresar",
  signIn: "Entrar",
  signin: "entrar",
  signOut: "Salir",
  signUp: "Suscribir",
  signupCode: "Codigo para suscribir",
  signUpWithYourEmailAddress: "Suscribir con tu email",
  terms: "Terminos de Uso",
  updateYourPassword: "Actualizar tu contraseña",
  username: "Usuario",
  usernameOrEmail: "Usuario o email",
  "with": "con",
  error: {
    accounts: {
      "Email already exists.": "Email ya existe.",
      "Email doesn't match the criteria.": "Email no coincide con los criterios.",
      "User validation failed": "No se ha podido validar el usuario",
      "Username already exists.": "Usuario ya existe.",
      "You've been logged out by the server. Please log in again.": "Has sido desconectado por el servidor. Por favor ingresa otra vez.",
      "Your session has expired. Please log in again.": "Tu session ha expirado. Por favor ingresa otra vez.",
      "Incorrect password": "Contraseña no válida",
      "Must be logged in": "Hay que ingresar",
      "Need to set a username or email": "Tienes que especificar un usuario o un email",
      "Signups forbidden": "Registro prohibido",
      "Token expired": "Token expirado",
      "Token has invalid email address": "Token contiene un Email inválido",
      "User has no password set": "Usuario no tiene contraseña",
      "User not found": "Usuario no encontrado",
      "Verify email link expired": "Enlace para verificar el Email ha expirado",
      "Verify email link is for unknown address": "Enlace para verificar el Email contiene una dirección desconocida"
    }
  },
  error: {
    emailRequired: "Email es necesario.",
    minChar: "7 carácteres mínimo.",
    pwOneDigit: "mínimo un dígito.",
    pwOneLetter: "mínimo una letra.",
    signInRequired: "Debes iniciar sesión para hacer eso.",
    signupCodeIncorrect: "Código para suscribir no coincide.",
    signupCodeRequired: "Código para suscribir es necesario.",
    usernameIsEmail: "Usuario no puede ser Email.",
    usernameRequired: "Usuario es necesario."
  }
};

T9n.map("es", es);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/mrt:accounts-t9n/t9n/fr.coffee.js                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var fr;

fr = {
  and: "et",
  clickAgree: "En cliquant sur S'enregistrer, vous acceptez notre",
  configure: "Configurer",
  createAccount: "Créer un compte",
  dontHaveAnAccount: "Vous n'avez pas de compte ?",
  email: "Email",
  emailAddress: "Adresse Email",
  emailResetLink: "Envoyer le mail de réinitialisation",
  forgotPassword: "Vous avez oublié votre mot de passe ?",
  ifYouAlreadyHaveAnAccount: "Si vous avez déjà un compte",
  optional: "Optionnel",
  OR: "OU",
  password: "Mot de passe",
  privacyPolicy: "Politique de confidentialité",
  resetYourPassword: "Reinitialiser votre mot de passe",
  sign: "S'enregistrer",
  signIn: "Se Connecter",
  signin: "se connecter",
  signOut: "Se Deconnecter",
  signUp: "S'enregistrer",
  signupCode: "Code d'inscription",
  signUpWithYourEmailAddress: "S'enregistrer avec votre adresse email",
  terms: "Conditions d'utilisation",
  updateYourPassword: "Mettre à jour le mot de passe",
  username: "Nom d'utilisateur",
  usernameOrEmail: "Nom d'utilisateur ou email",
  "with": "avec",
  error: {
    accounts: {
      "Email already exists.": "Adresse email déjà utilisée.",
      "Email doesn't match the criteria.": "Adresse email ne correspond pas aux critères.",
      "User validation failed": "Echec de la validation de l'utilisateur",
      "Username already exists.": "Nom d'utilisateur déjà utilisé.",
      "You've been logged out by the server. Please log in again.": "Vous avez été déconnecté par le serveur. Veuillez vous reconnecter.",
      "Your session has expired. Please log in again.": "Votre session a expiré. Veuillez vous reconnecter.",
      "Incorrect password": "Mot de passe incorrect",
      "Must be logged in": "Vous devez être connecté",
      "Need to set a username or email": "Vous devez renseigner un nom d'utilisateur ou une adresse email",
      "Signups forbidden": "La création de compte est interdite",
      "Token expired": "Jeton expiré",
      "Token has invalid email address": "Le jeton contient une adresse email invalide",
      "User has no password set": "L'utilisateur n'a pas de mot de passe",
      "User not found": "Utilisateur inconnu",
      "Verify email link expired": "Lien de vérification d'email expiré",
      "Verify email link is for unknown address": "Le lien de vérification d'email réfère à une adresse inconnue"
    }
  },
  error: {
    emailRequired: "Un email est requis.",
    minChar: "Votre mot de passe doit contenir au minimum 7 caractères.",
    pwOneDigit: "Votre mot de passe doit contenir au moins un chiffre.",
    pwOneLetter: "Votre mot de passe doit contenir au moins une lettre.",
    signInRequired: "Vous devez être connecté pour continuer.",
    signupCodeIncorrect: "Le code d'enregistrement est incorrect.",
    signupCodeRequired: "Un code d'inscription est requis.",
    usernameIsEmail: "Le nom d'utilisateur ne peut être le même que l'adresse email.",
    usernameRequired: "Un nom d'utilisateur est requis."
  }
};

T9n.map("fr", fr);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/mrt:accounts-t9n/t9n/it.coffee.js                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var it;

it = {
  add: "aggiungi",
  and: "e",
  back: "indietro",
  clickAgree: "Cliccando Registrati, accetti la nostra",
  configure: "Configura",
  createAccount: "Crea un Account",
  dontHaveAnAccount: "Non hai un account?",
  email: "Email",
  emailAddress: "Indirizzo Email",
  emailResetLink: "Invia Link di Reset",
  emailSent: "Email Inviata!",
  forgotPassword: "Hai dimenticato la password?",
  ifYouAlreadyHaveAnAccount: "Se hai già un account",
  optional: "Opzionale",
  OR: "OPPURE",
  password: "Password",
  privacyPolicy: "Privacy Policy",
  remove: "rimuovi",
  resetYourPassword: "Reimposta la password",
  sign: "Accedi",
  signIn: "Accedi",
  signin: "accedi",
  signOut: "Esci",
  signUp: "Registrati",
  signupCode: "Codice di Registrazione",
  signUpWithYourEmailAddress: "Registrati con il tuo indirizzo email",
  terms: "Termini di Servizio",
  updateYourPassword: "Aggiorna la password",
  username: "Username",
  usernameOrEmail: "Nome utente o email",
  "with": "con",
  error: {
    accounts: {
      "Email already exists.": "Indirizzo email già esistente.",
      "Email doesn't match the criteria.": "L'indirizzo email non soddisfa i requisiti.",
      "Invalid login token": "Codice di accesso non valido",
      "Login forbidden": "Accesso non consentito",
      "Service unknown": "Servizio sconosciuto",
      "Unrecognized options for login request": "Opzioni per la richiesta di accesso non ricunosciute",
      "User validation failed": "Validazione utente fallita",
      "Username already exists.": "Nome utente già esistente.",
      "You are not logged in.": "Non hai effettuato l'accesso.",
      "You've been logged out by the server. Please log in again.": "Sei stato disconnesso dal server. Per favore accedi di nuovo.",
      "Your session has expired. Please log in again.": "La tua sessione è scaduta. Per favore accedi di nuovo.",
      "No matching login attempt found": "Tentativo di accesso corrispondente non trovato",
      "Password is old. Please reset your password.": "La password è vecchia. Per favore reimposta la tua password.",
      "Incorrect password": "Password non corretta",
      "Invalid email": "Email non valida",
      "Must be logged in": "Devi aver eseguito l'accesso",
      "Need to set a username or email": "È necessario specificare un nome utente o un indirizzo email",
      "old password format": "vecchio formato password",
      "Signups forbidden": "Registrazioni non consentite",
      "Token expired": "Codice scaduto",
      "Token has invalid email address": "Il codice ha un indirizzo email non valido",
      "User has no password set": "L'utente non ha una password impostata",
      "User not found": "Utente non trovato",
      "Verify email link expired": "Link per la verifica dell'email scaduto",
      "Verify email link is for unknown address": "Il link per la verifica dell'email fa riferimento ad un indirizzo sconosciuto",
      "Match failed": "Riscontro fallito"
    }
  },
  error: {
    emailRequired: "L'Email è obbligatoria.",
    minChar: "La Password deve essere di almeno 7 caratteri.",
    pwOneDigit: "La Password deve contenere almeno un numero.",
    pwOneLetter: "La Password deve contenere 1 lettera.",
    signInRequired: "Per fare questo devi accedere.",
    signupCodeIncorrect: "Codice di Registrazione errato.",
    signupCodeRequired: "Il Codice di Registrazione è obbligatorio.",
    usernameIsEmail: "Il Nome Utente non può essere un indirizzo email.",
    usernameRequired: "Il Nome utente è obbligatorio."
  }
};

T9n.map("it", it);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/mrt:accounts-t9n/t9n/pl.coffee.js                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var pl;

pl = {
  and: "i",
  clickAgree: "Klikając na Zarejestruj się zgadzasz się z naszą",
  configure: "Konfiguruj",
  createAccount: "Utwórz konto",
  dontHaveAnAccount: "Nie masz konta?",
  email: "Email",
  emailAddress: "Adres email",
  emailResetLink: "Wyślij email z linkiem do zmiany hasła",
  forgotPassword: "Zapomniałeś hasła?",
  ifYouAlreadyHaveAnAccount: "Jeżeli już masz konto",
  optional: "Nieobowiązkowe",
  OR: "LUB",
  password: "Hasło",
  privacyPolicy: "polityką prywatności",
  resetYourPassword: "Ustaw nowe hasło",
  sign: "Podpisz",
  signIn: "Zaloguj się",
  signin: "zaloguj się",
  signOut: "Wyloguj się",
  signUp: "Zarejestruj się",
  signupCode: "Kod rejestracji",
  signUpWithYourEmailAddress: "Zarejestruj się używając adresu email",
  terms: "warunkami korzystania z serwisu",
  updateYourPassword: "Zaktualizuj swoje hasło",
  username: "Nazwa użytkownika",
  usernameOrEmail: "Nazwa użytkownika lub email",
  "with": "z",
  error: {
    accounts: {
      "Email already exists.": "Adres email już istnieje.",
      "Email doesn't match the criteria.": "Adres email nie spełnia kryteriów.",
      "User validation failed": "Niepoprawna nazwa użytkownika",
      "Username already exists.": "Nazwa użytkownika już istnieje.",
      "You've been logged out by the server. Please log in again.": "Zostałeś wylogowane przez serwer. Zaloguj się ponownie.",
      "Your session has expired. Please log in again.": "Twoja sesja wygasła. Zaloguj się ponownie.",
      "Incorrect password": "Niepoprawne hasło",
      "Must be logged in": "Musisz być zalogowany",
      "Need to set a username or email": "Wymagane ustawienie nazwy użytkownika lub adresu email",
      "Signups forbidden": "Rejestracja zabroniona",
      "Token expired": "Token wygasł",
      "Token has invalid email address": "Token ma niewłaściwy adres email",
      "User has no password set": "Użytkownik nie ma ustawionego hasła",
      "User not found": "Nie znaleziono użytkownika",
      "Verify email link expired": "Link weryfikacyjny wygasł",
      "Verify email link is for unknown address": "Link weryfikacyjny jest dla nieznanego adresu"
    }
  },
  error: {
    emailRequired: "Wymagany jest adres email.",
    minChar: "7 znaków to minimalna długość hasła.",
    pwOneDigit: "Hasło musi zawierać przynajmniej jedną cyfrę.",
    pwOneLetter: "Hasło musi zawierać 1 literę.",
    signInRequired: "Musisz być zalogowany, aby to zrobić.",
    signupCodeIncorrect: "Kod rejestracji jest nieprawidłowy.",
    signupCodeRequired: "Wymagany jest kod rejestracji.",
    usernameIsEmail: "Nazwa użytkownika nie może być adres e-mail.",
    usernameRequired: "Wymagana jest nazwa użytkownika."
  }
};

T9n.map("pl", pl);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/mrt:accounts-t9n/t9n/pt.coffee.js                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var pt;

pt = {
  and: "e",
  clickAgree: "Ao clicar em Entrar, você aceita nosso",
  configure: "Configurar",
  createAccount: "Criar Conta",
  dontHaveAnAccount: "Não tem conta?",
  email: "E-mail",
  emailAddress: "Endereço de e-mail",
  emailResetLink: "Gerar nova senha",
  forgotPassword: "Esqueceu sua senha?",
  ifYouAlreadyHaveAnAccount: "Se você já tem uma conta",
  optional: "Opcional",
  OR: "OU",
  password: "Senha",
  privacyPolicy: "Política de Privacidade",
  resetYourPassword: "Gerar nova senha",
  sign: "Entrar",
  signIn: "Entrar",
  signin: "entrar",
  signOut: "Sair",
  signUp: "Registrar",
  signupCode: "Código de acesso",
  signUpWithYourEmailAddress: "Entre usando seu endereço de e-mail",
  terms: "Termos de Uso",
  updateYourPassword: "Atualizar senha",
  username: "Nome de usuário",
  usernameOrEmail: "Usuario ou e-mail",
  "with": "com",
  error: {
    emailRequired: "E-mail é obrigatório.",
    minChar: "Senha requer um mínimo de 7 caracteres.",
    pwOneDigit: "Senha deve conter pelo menos um digito.",
    pwOneLetter: "Senha deve conter pelo menos uma letra.",
    signInRequired: "Você precisa estar logado para fazer isso.",
    signupCodeIncorrect: "Código de acesso incorreto.",
    signupCodeRequired: "É necessário um código de acesso.",
    usernameIsEmail: "Nome de usuário não pode ser um endereço de e-mail.",
    usernameRequired: "Nome de usuário é obrigatório."
  }
};

T9n.map("pt", pt);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/mrt:accounts-t9n/t9n/ru.coffee.js                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var ru;

ru = {
  and: "и",
  clickAgree: "Нажав на Регистрация вы соглашаетесь с условиями",
  configure: "Конфигурировать",
  createAccount: "Создать аккаунт",
  dontHaveAnAccount: "Нет аккаунта?",
  email: "Email",
  emailAddress: "Email",
  emailResetLink: "Отправить ссылку для сброса",
  forgotPassword: "Забыли пароль?",
  ifYouAlreadyHaveAnAccount: "Если у вас уже есть аккаунт",
  optional: "Необязательно",
  OR: "ИЛИ",
  password: "Пароль",
  privacyPolicy: "Политики безопасности",
  resetYourPassword: "Сбросить пароль",
  sign: "Подпись",
  signIn: "Войти",
  signin: "bойти",
  signOut: "Выйти",
  signUp: "Регистрация",
  signupCode: "Регистрационный код",
  signUpWithYourEmailAddress: "Зарегистрируйтесь с вашим email адресом",
  terms: "Условиями пользования",
  updateYourPassword: "Обновить пароль",
  username: "Имя пользователя",
  usernameOrEmail: "Имя пользователя или email",
  "with": "с",
  error: {
    accounts: {
      "User not found": "Пользователь не найден",
      "Match failed": "Не совпадают"
    }
  },
  error: {
    emailRequired: "Email обязательно.",
    minChar: "Минимальное кол-во символов для пароля 7.",
    pwOneDigit: "В пароле должна быть хотя бы одна цифра.",
    pwOneLetter: "В пароле должна быть хотя бы одна буква.",
    signInRequired: "Необходимо войти для чтобы продолжить.",
    signupCodeIncorrect: "Неправильный регистрационный код.",
    signupCodeRequired: "Необходим регистрациооный код.",
    usernameIsEmail: "Имя пользователя не может быть адресом email.",
    usernameRequired: "Имя пользователя обязательно."
  }
};

T9n.map("ru", ru);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/mrt:accounts-t9n/t9n/sl.coffee.js                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var sl;

sl = {
  and: "in",
  clickAgree: "S klikom na Registracija se strinjaš",
  configure: "Nastavi",
  createAccount: "Nova registracija",
  dontHaveAnAccount: "Nisi registriran(a)?",
  email: "Email",
  emailAddress: "Email naslov",
  emailResetLink: "Pošlji ponastavitveno povezavo",
  forgotPassword: "Pozabljeno geslo?",
  ifYouAlreadyHaveAnAccount: "Če si že registriran(a),",
  optional: "Po želji",
  OR: "ALI",
  password: "Geslo",
  privacyPolicy: "z našimi pogoji uporabe",
  resetYourPassword: "Ponastavi geslo",
  sign: "Prijava",
  signIn: "Prijava",
  signin: "se prijavi",
  signOut: "Odjava",
  signUp: "Registracija",
  signupCode: "Prijavna koda",
  signUpWithYourEmailAddress: "Prijava z email naslovom",
  terms: "Pogoji uporabe",
  updateYourPassword: "Spremeni geslo",
  username: "Uporabniško ime",
  usernameOrEmail: "Uporabniško ime ali email",
  "with": "z",
  error: {
    accounts: {
      "Email already exists.": "Email že obstaja.",
      "Incorrect password": "Napačno geslo",
      "User not found": "Uporabnik ne obstaja",
      "Match failed": "Prijava neuspešna"
    }
  },
  error: {
    emailRequired: "Email je obvezen vnos.",
    minChar: "Geslo mora imeti vsaj sedem znakov.",
    pwOneDigit: "V geslu mora biti vsaj ena številka.",
    pwOneLetter: "V geslu mora biti vsaj ena črka.",
    signInRequired: "Za to moraš biti prijavljen(a).",
    signupCodeIncorrect: "Prijavna koda je napačna.",
    signupCodeRequired: "Prijavna koda je obvezen vnos.",
    usernameIsEmail: "Uporabniško ime ne more biti email naslov.",
    usernameRequired: "Uporabniško ime je obvezen vnos."
  }
};

T9n.map("sl", sl);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/mrt:accounts-t9n/t9n/sv.coffee.js                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var sv;

sv = {
  and: "och",
  clickAgree: "När du väljer att skapa ett konto så godkänner du också vår",
  configure: "Konfigurera",
  createAccount: "Skapa ett konto",
  dontHaveAnAccount: "Har du inget konto?",
  email: "E-postadress",
  emailAddress: "E-postadress",
  emailResetLink: "E-post återställningslänk",
  forgotPassword: "Glömt din e-postadress?",
  ifYouAlreadyHaveAnAccount: "Om du redan har ett konto",
  optional: "Valfri",
  OR: "ELLER",
  password: "Lösenord",
  privacyPolicy: "integritetspolicy",
  resetYourPassword: "Återställ ditt lösenord",
  sign: "Logga",
  signIn: "Logga in",
  signin: "logga in",
  signOut: "Logga ut",
  signUp: "Skapa konto",
  signupCode: "Registreringskod",
  signUpWithYourEmailAddress: "Skapa ett konto med din e-postadress",
  terms: "användarvilkor",
  updateYourPassword: "Uppdatera ditt lösenord",
  username: "Användarnamn",
  usernameOrEmail: "Användarnamn eller e-postadress",
  "with": "med",
  error: {
    accounts: {
      "User not found": "Användaren hittades inte",
      "Match failed": "Matchning misslyckades"
    }
  },
  error: {
    emailRequired: "Det krävs ett lösenord.",
    minChar: "Det krävs minst 7 tecken i ditt lösenord.",
    pwOneDigit: "Lösenordet måste ha minst 1 siffra.",
    pwOneLetter: "Lösenordet måste ha minst 1 bokstav.",
    signInRequired: "Inloggning krävs här.",
    signupCodeIncorrect: "Registreringskoden är felaktig.",
    signupCodeRequired: "Det krävs en registreringskod.",
    usernameIsEmail: "Användarnamnet kan inte vara en e-postadress.",
    usernameRequired: "Det krävs ett användarnamn."
  }
};

T9n.map("sv", sv);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/mrt:accounts-t9n/t9n/vi.coffee.js                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var vi;

vi = {
  add: "thêm",
  and: "và",
  back: "trở lại",
  clickAgree: "Bằng cách nhấn vào Đăng ký, bạn đã đồng ý với",
  configure: "Cấu hình",
  createAccount: "Tạo Tài khoản",
  dontHaveAnAccount: "Chưa có tài khoản?",
  email: "Email",
  emailAddress: "Địa chỉ Email",
  emailResetLink: "Gửi",
  emailSent: "Email đã được gửi đi!",
  forgotPassword: "Quên mật khẩu?",
  ifYouAlreadyHaveAnAccount: "Nếu bạn đã có tài khoản",
  optional: "Tùy chọn",
  OR: "Hoặc",
  password: "Mật khẩu",
  privacyPolicy: "Chính sách bảo mật",
  remove: "xóa",
  resetYourPassword: "Lấy lại mật khẩu",
  sign: "Ký",
  signIn: "Đăng nhập",
  signin: "đăng nhập",
  signOut: "Đăng xuất",
  signUp: "Đăng ký",
  signupCode: "Mã đăng ký",
  signUpWithYourEmailAddress: "Đăng ký với email của bạn",
  terms: "Điều khoản sử dụng",
  updateYourPassword: "Cập nhật mật khẩu",
  username: "Tên đăng nhập",
  usernameOrEmail: "Tên đăng nhập hoặc email",
  "with": "với",
  error: {
    accounts: {
      "Email already exists.": "Email đã tồn tại.",
      "Email doesn't match the criteria.": "Email không phù hợp.",
      "Invalid login token": "Mã đăng nhập không đúng",
      "Login forbidden": "Đăng nhập bị cấm",
      "Service unknown": "Chưa biết Dịch vụ",
      "Unrecognized options for login request": "Tùy chọn không được công nhận đối với yêu cầu đăng nhập",
      "User validation failed": "Xác nhận người dùng thất bại",
      "Username already exists.": "Tên đăng nhập đã tồn tại.",
      "You are not logged in.": "Bạn chưa đăng nhập.",
      "You've been logged out by the server. Please log in again.": "Bạn đã bị đăng xuất bởi máy chủ. Vui lòng đăng nhập lại.",
      "Your session has expired. Please log in again.": "Thời gian đăng nhập đã hết. Vui lòng đăng nhập lại.",
      "No matching login attempt found": "Không tìm thấy đăng nhập phù hợp",
      "Password is old. Please reset your password.": "Mật khẩu đã cũ. Vui lòng lấy lại mật khẩu.",
      "Incorrect password": "Mật khẩu sai",
      "Invalid email": "Email sai",
      "Must be logged in": "Phải đăng nhập",
      "Need to set a username or email": "Phải điền tên đăng nhập hoặc email",
      "old password format": "định dạng mật khẩu cũ",
      "Signups forbidden": "Đăng ký đã bị cấm",
      "Token expired": "Hết phiên đăng nhập",
      "Token has invalid email address": "Phiên đăng nhập chứa địa chỉ email sai",
      "User has no password set": "Người dùng chưa có mật khẩu",
      "User not found": "Không tìm thấy người dùng",
      "Verify email link expired": "Đường dẫn xác nhận email đã hết hạn",
      "Verify email link is for unknown address": "Đường dẫn xác nhận email là cho địa chỉ chưa xác định",
      "Match failed": "Không đúng"
    }
  },
  error: {
    emailRequired: "Email phải có.",
    minChar: "Mật khẩu phải có ít nhất 7 ký tự.",
    pwOneDigit: "Mật khẩu phải có ít nhất 1 chữ số.",
    pwOneLetter: "Mật khẩu phải có 1 ký tự chữ.",
    signInRequired: "Phải đăng nhập.",
    signupCodeIncorrect: "Mã số đăng ký sai.",
    signupCodeRequired: "Phải có mã số đăng ký.",
    usernameIsEmail: "Tên đăng nhập không thể là địa chỉ email.",
    usernameRequired: "Phải có tên đăng nhập."
  }
};

T9n.map("vi", vi);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mrt:accounts-t9n'] = {
  T9n: T9n
};

})();

//# sourceMappingURL=mrt:accounts-t9n.js.map
