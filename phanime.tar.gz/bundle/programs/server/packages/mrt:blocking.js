(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var blocking;

(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/mrt:blocking/server.js                                   //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
(function () {                                                       // 1
  blocking = function (obj, fun) {                                   // 2
    if (!fun) {                                                      // 3
      fun = obj;                                                     // 4
      obj = undefined;                                               // 5
    }                                                                // 6
    var wrapped = Meteor._wrapAsync(fun);                            // 7
    var f = function () {                                            // 8
      if (typeof obj === 'undefined') {                              // 9
        obj = this;                                                  // 10
      }                                                              // 11
      return wrapped.apply(obj, arguments);                          // 12
    };                                                               // 13
    f._blocking = true;                                              // 14
    return f;                                                        // 15
  };                                                                 // 16
})();                                                                // 17
                                                                     // 18
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mrt:blocking'] = {
  blocking: blocking
};

})();

//# sourceMappingURL=mrt:blocking.js.map
