(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['foldor:bootstrap-3'] = {};

})();

//# sourceMappingURL=foldor:bootstrap-3.js.map
