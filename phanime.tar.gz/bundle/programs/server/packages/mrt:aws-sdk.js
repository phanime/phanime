(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var blocking = Package['mrt:blocking'].blocking;

/* Package-scope variables */
var AWS;

(function () {

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/mrt:aws-sdk/server.js                                         //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
AWS = Npm.require('aws-sdk');                                             // 1
                                                                          // 2
var originalDefineMethods = AWS.Service.defineMethods;                    // 3
                                                                          // 4
AWS.Service.defineMethods = function defineMethods(svc) {                 // 5
  originalDefineMethods(svc);                                             // 6
  AWS.util.each(svc.prototype.api.operations, function iterator(method) { // 7
    var syncMethod = method + 'Sync';                                     // 8
    if (!svc.prototype[method]) return;                                   // 9
    if (svc.prototype[syncMethod]) return;                                // 10
    svc.prototype[syncMethod] = blocking(svc.prototype[method]);          // 11
  });                                                                     // 12
};                                                                        // 13
////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mrt:aws-sdk'] = {
  AWS: AWS
};

})();

//# sourceMappingURL=mrt:aws-sdk.js.map
