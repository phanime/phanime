(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var AWS;

(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/mrt:aws-sdk/server.js                                    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
AWS = Npm.require('aws-sdk');                                        // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mrt:aws-sdk'] = {};

})();

//# sourceMappingURL=mrt:aws-sdk.js.map
