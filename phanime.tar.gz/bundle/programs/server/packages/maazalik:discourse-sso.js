(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var discourse_sso;

(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/maazalik:discourse-sso/discourse-sso.js                  //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
discourse_sso = Npm.require('discourse-sso');                        // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['maazalik:discourse-sso'] = {
  discourse_sso: discourse_sso
};

})();

//# sourceMappingURL=maazalik:discourse-sso.js.map
