(function(){Kadira.connect('aGXCBonX4kvpzcmRd', '3b984cc3-12bf-4b31-9646-34b77aefd799');

})();
