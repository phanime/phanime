(function(){HTTP.methods({
	'api/v1/test': {
		get: function(data) {
			return 'test';
		}
	}
});

})();
