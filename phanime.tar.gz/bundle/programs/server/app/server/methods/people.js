(function(){Meteor.methods({
	createPerson: function(doc) {
		console.log(doc);
	}
});

})();
