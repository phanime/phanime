(function(){Meteor.methods({
    createCharacter: function(doc) {
        console.log(doc);
    }
});

})();
