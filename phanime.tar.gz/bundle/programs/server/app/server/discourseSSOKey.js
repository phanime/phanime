(function(){privateSiteSettings = {
	discourseSSOKey: '6hkLiMrwyC7sB4JPm1Vu',
};

})();
