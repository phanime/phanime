(function(){Episodes = new Meteor.Collection("episodes");

})();
