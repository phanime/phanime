(function(){StaffMembers = new Meteor.Collection("staffMembers");

})();
