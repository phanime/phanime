(function(){Studios = new Meteor.Collection('studios');

StudiosSchema = new SimpleSchema({
	producerLogo: {
		type: String,
		label: "Producer Logo",
		optional: true,
	},
	name: {
		type: String,
		label: "Name"
	}
});

})();
