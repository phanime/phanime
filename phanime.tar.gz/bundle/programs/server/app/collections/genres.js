(function(){Genres = new Meteor.Collection("genres");

})();
