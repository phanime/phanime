(function(){Activity = new Meteor.Collection('activity');


// // Interacting with activities 
// Activity.create = function() {
	
// }


})();
