(function(){Castings = new Meteor.Collection("castings");

})();
